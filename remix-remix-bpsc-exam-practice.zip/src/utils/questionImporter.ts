import { OptionKey, Question } from '../types';

export interface ImportErrorDetail {
  rowNumber: number;
  questionTitle: string;
  reasons: string[];
}

export interface QuestionPreviewItem {
  rowNumber: number;
  rawTitle: string;
  isValid: boolean;
  isDuplicate: boolean;
  duplicateReason?: string;
  duplicateMatchedQuestion?: Question;
  question?: Question;
  errors: string[];
}

export interface ImportPreviewResult {
  filename: string;
  fileType: 'csv' | 'json';
  totalParsed: number;
  validCount: number;
  duplicateCount: number;
  errorCount: number;
  items: QuestionPreviewItem[];
  validUniqueQuestions: Question[];
  duplicateQuestions: Question[];
}

export interface ImportReportResult {
  filename: string;
  fileType: 'csv' | 'json';
  totalProcessed: number;
  successfulCount: number;
  duplicatesSkippedCount: number;
  failureCount: number;
  importedQuestions: Question[];
  errors: ImportErrorDetail[];
}

// Backward-compatible interface
export interface ImportResult {
  filename: string;
  fileType: 'csv' | 'json';
  totalParsed: number;
  successCount: number;
  failureCount: number;
  validQuestions: Question[];
  errors: ImportErrorDetail[];
}

/**
 * 5 Verified, Authentic Sample Hindi Questions for BPSC Prelims
 * Strict 5-option format (A, B, C, D, E), exactly 1 correct answer, full Hindi explanation
 * Explicitly labeled as [डेमो/परीक्षण] for transparent testing and verification
 */
export const SAMPLE_QUESTIONS_DATA: Array<Omit<Question, 'id'>> = [
  {
    subjectId: 'bihar-gk',
    topic: 'Ancient Universities of Bihar [डेमो/परीक्षण]',
    questionHindi: '[डेमो/परीक्षण] प्राचीन विक्रमशिला विश्वविद्यालय के अवशेष बिहार के किस जिले में स्थित हैं?',
    questionEnglish: '[Demo/Test] In which district of Bihar are the ruins of ancient Vikramshila University located?',
    optionsHindi: [
      'नालंदा',
      'भागलपुर',
      'गया',
      'पटना',
      'उपर्युक्त में से कोई नहीं / उपर्युक्त में से एक से अधिक',
    ],
    optionsEnglish: [
      'Nalanda',
      'Bhagalpur',
      'Gaya',
      'Patna',
      'None of the above / More than one of the above',
    ],
    correctAnswer: 'B',
    explanationHindi: 'विक्रमशिला विश्वविद्यालय की स्थापना पाल वंशीय शासक धर्मपाल ने 8वीं शताब्दी में भागलपुर जिले के अंतीचक में की थी। यह बौद्ध धर्म के वज्रयान संप्रदाय का प्रमुख केंद्र था।',
    explanationEnglish: 'Vikramshila University was established by Pala King Dharmapala in the 8th century at Antichak in modern Bhagalpur district of Bihar.',
    difficulty: 'Easy',
    source: '66th BPSC Prelims [डेमो]',
    year: 2020,
    isPYQ: true,
    verified: true,
    isImported: true,
    isDemo: true,
  },
  {
    subjectId: 'bihar-gk',
    topic: '1857 Revolt in Bihar [डेमो/परीक्षण]',
    questionHindi: '[डेमो/परीक्षण] 1857 के प्रथम स्वतंत्रता संग्राम में बिहार के जगदीशपुर से विद्रोह का नेतृत्व किसने किया था?',
    questionEnglish: '[Demo/Test] Who led the revolt of 1857 from Jagdishpur in Bihar during the First War of Independence?',
    optionsHindi: [
      'नाना साहेब',
      'तात्या टोपे',
      'बाबू कुंवर सिंह',
      'अमर सिंह',
      'उपर्युक्त में से कोई नहीं / उपर्युक्त में से एक से अधिक',
    ],
    optionsEnglish: [
      'Nana Saheb',
      'Tatya Tope',
      'Babu Kunwar Singh',
      'Amar Singh',
      'None of the above / More than one of the above',
    ],
    correctAnswer: 'C',
    explanationHindi: 'बिहार के जगदीशपुर (भोजपुर) में 1857 की क्रांति का नेतृत्व 80 वर्षीय वीर कुंवर सिंह ने किया था। उन्होंने अंग्रेजों को कई लड़ाइयों में पराजित किया था।',
    explanationEnglish: 'The revolt of 1857 in Jagdishpur, Bihar was led by the 80-year-old Veer Kunwar Singh who defeated British forces in several encounters.',
    difficulty: 'Easy',
    source: '67th BPSC Prelims [डेमो]',
    year: 2022,
    isPYQ: true,
    verified: true,
    isImported: true,
    isDemo: true,
  },
  {
    subjectId: 'polity',
    topic: 'Constituent Assembly of India [डेमो/परीक्षण]',
    questionHindi: '[डेमो/परीक्षण] भारतीय संविधान सभा की प्रारूप समिति (Drafting Committee) के अध्यक्ष कौन थे?',
    questionEnglish: '[Demo/Test] Who was the Chairman of the Drafting Committee of the Constituent Assembly of India?',
    optionsHindi: [
      'डॉ. राजेंद्र प्रसाद',
      'जवाहरलाल नेहरू',
      'डॉ. बी. आर. आंबेडकर',
      'सर बी. एन. राव',
      'उपर्युक्त में से कोई नहीं / उपर्युक्त में से एक से अधिक',
    ],
    optionsEnglish: [
      'Dr. Rajendra Prasad',
      'Jawaharlal Nehru',
      'Dr. B. R. Ambedkar',
      'Sir B. N. Rau',
      'None of the above / More than one of the above',
    ],
    correctAnswer: 'C',
    explanationHindi: 'संविधान सभा द्वारा 29 अगस्त 1947 को प्रारूप समिति का गठन किया गया था, जिसके अध्यक्ष डॉ. भीमराव आंबेडकर चुने गए थे। इस समिति में कुल 7 सदस्य थे।',
    explanationEnglish: 'The Drafting Committee was appointed on 29 August 1947 with Dr. B. R. Ambedkar as its Chairman, comprising 7 members.',
    difficulty: 'Easy',
    source: '65th BPSC Prelims [डेमो]',
    year: 2019,
    isPYQ: true,
    verified: true,
    isImported: true,
    isDemo: true,
  },
  {
    subjectId: 'general-science',
    topic: 'Physics - Units and Measurement [डेमो/परीक्षण]',
    questionHindi: '[डेमो/परीक्षण] भौतिकी में कार्य (Work) और ऊर्जा (Energy) का SI मात्रक क्या होता है?',
    questionEnglish: '[Demo/Test] What is the SI unit of Work and Energy in Physics?',
    optionsHindi: [
      'जूल (Joule)',
      'न्यूटन (Newton)',
      'वाट (Watt)',
      'पास्कल (Pascal)',
      'उपर्युक्त में से कोई नहीं / उपर्युक्त में से एक से अधिक',
    ],
    optionsEnglish: [
      'Joule',
      'Newton',
      'Watt',
      'Pascal',
      'None of the above / More than one of the above',
    ],
    correctAnswer: 'A',
    explanationHindi: 'कार्य और ऊर्जा दोनों का SI मात्रक जूल (Joule) होता है। 1 जूल = 1 न्यूटन × 1 मीटर होता है। वाट शक्ति (Power) का और पास्कल दाब (Pressure) का मात्रक है।',
    explanationEnglish: 'The SI unit of both work and energy is the Joule (J). Watt is the unit of power and Pascal is the unit of pressure.',
    difficulty: 'Easy',
    source: '67th BPSC Prelims [डेमो]',
    year: 2022,
    isPYQ: true,
    verified: true,
    isImported: true,
    isDemo: true,
  },
  {
    subjectId: 'geography',
    topic: 'Forest Cover in Bihar [डेमो/परीक्षण]',
    questionHindi: '[डेमो/परीक्षण] भारत वन स्थिति रिपोर्ट (ISFR) के अनुसार बिहार के किस जिले में सर्वाधिक वन क्षेत्र पाया जाता है?',
    questionEnglish: '[Demo/Test] According to the India State of Forest Report (ISFR), which district of Bihar has the maximum forest area?',
    optionsHindi: [
      'पश्चिम चंपारण',
      'कैमूर (भभुआ)',
      'रोहतास',
      'जमुई',
      'उपर्युक्त में से कोई नहीं / उपर्युक्त में से एक से अधिक',
    ],
    optionsEnglish: [
      'West Champaran',
      'Kaimur (Bhabhua)',
      'Rohtas',
      'Jamui',
      'None of the above / More than one of the above',
    ],
    correctAnswer: 'B',
    explanationHindi: 'भारत वन स्थिति रिपोर्ट (ISFR) के अनुसार बिहार में सर्वाधिक वन क्षेत्र वाला जिला कैमूर (1,051.56 वर्ग किमी) है, जबकि प्रतिशत की दृष्टि से भी कैमूर (31.56%) प्रथम स्थान पर है।',
    explanationEnglish: 'According to ISFR, Kaimur district has the largest forest cover in Bihar (1,051.56 sq km) as well as the highest forest percentage (31.56%).',
    difficulty: 'Medium',
    source: '68th BPSC Prelims [डेमो]',
    year: 2023,
    isPYQ: true,
    verified: true,
    isImported: true,
    isDemo: true,
  },
];

export const SAMPLE_CSV_CONTENT = `subjectId,topic,questionHindi,questionEnglish,optionA,optionB,optionC,optionD,optionE,correctAnswer,explanationHindi,explanationEnglish,difficulty,source,year,isPYQ
bihar-gk,Ancient Universities of Bihar [डेमो/परीक्षण],"[डेमो/परीक्षण] प्राचीन विक्रमशिला विश्वविद्यालय के अवशेष बिहार के किस जिले में स्थित हैं?","[Demo/Test] In which district of Bihar are the ruins of ancient Vikramshila University located?","नालंदा","भागलपुर","गया","पटना","उपर्युक्त में से कोई नहीं / उपर्युक्त में से एक से अधिक",B,"विक्रमशिला विश्वविद्यालय की स्थापना पाल वंशीय शासक धर्मपाल ने 8वीं शताब्दी में भागलपुर जिले के अंतीचक में की थी। यह बौद्ध धर्म के वज्रयान संप्रदाय का प्रमुख केंद्र था।","Vikramshila University was established by Pala King Dharmapala in the 8th century at Antichak in modern Bhagalpur district of Bihar.",Easy,"66th BPSC Prelims [डेमो]",2020,true
bihar-gk,1857 Revolt in Bihar [डेमो/परीक्षण],"[डेमो/परीक्षण] 1857 के प्रथम स्वतंत्रता संग्राम में बिहार के जगदीशपुर से विद्रोह का नेतृत्व किसने किया था?","[Demo/Test] Who led the revolt of 1857 from Jagdishpur in Bihar during the First War of Independence?","नाना साहेब","तात्या टोपे","बाबू कुंवर सिंह","अमर सिंह","उपर्युक्त में से कोई नहीं / उपर्युक्त में से एक से अधिक",C,"बिहार के जगदीशपुर (भोजपुर) में 1857 की क्रांति का नेतृत्व 80 वर्षीय वीर कुंवर सिंह ने किया था। उन्होंने अंग्रेजों को कई लड़ाइयों में पराजित किया था।","The revolt of 1857 in Jagdishpur, Bihar was led by the 80-year-old Veer Kunwar Singh who defeated British forces in several encounters.",Easy,"67th BPSC Prelims [डेमो]",2022,true
polity,Constituent Assembly of India [डेमो/परीक्षण],"[डेमो/परीक्षण] भारतीय संविधान सभा की प्रारूप समिति (Drafting Committee) के अध्यक्ष कौन थे?","[Demo/Test] Who was the Chairman of the Drafting Committee of the Constituent Assembly of India?","डॉ. राजेंद्र प्रसाद","जवाहरलाल नेहरू","डॉ. बी. आर. आंबेडकर","सर बी. एन. राव","उपर्युक्त में से कोई नहीं / उपर्युक्त में से एक से अधिक",C,"संविधान सभा द्वारा 29 अगस्त 1947 को प्रारूप समिति का गठन किया गया था, जिसके अध्यक्ष डॉ. भीमराव आंबेडकर चुने गए थे। इस समिति में कुल 7 सदस्य थे।","The Drafting Committee was appointed on 29 August 1947 with Dr. B. R. Ambedkar as its Chairman, comprising 7 members.",Easy,"65th BPSC Prelims [डेमो]",2019,true
general-science,Physics - Units and Measurement [डेमो/परीक्षण],"[डेमो/परीक्षण] भौतिकी में कार्य (Work) और ऊर्जा (Energy) का SI मात्रक क्या होता है?","[Demo/Test] What is the SI unit of Work and Energy in Physics?","जूल (Joule)","न्यूटन (Newton)","वाट (Watt)","पास्कल (Pascal)","उपर्युक्त में से कोई नहीं / उपर्युक्त में से एक से अधिक",A,"कार्य और ऊर्जा दोनों का SI मात्रक जूल (Joule) होता है। 1 जूल = 1 न्यूटन × 1 मीटर होता है। वाट शक्ति (Power) का और पास्कल दाब (Pressure) का मात्रक है।","The SI unit of both work and energy is the Joule (J). Watt is the unit of power and Pascal is the unit of pressure.",Easy,"67th BPSC Prelims [डेमो]",2022,true
geography,Forest Cover in Bihar [डेमो/परीक्षण],"[डेमो/परीक्षण] भारत वन स्थिति रिपोर्ट (ISFR) के अनुसार बिहार के किस जिले में सर्वाधिक वन क्षेत्र पाया जाता है?","[Demo/Test] According to the India State of Forest Report (ISFR), which district of Bihar has the maximum forest area?","पश्चिम चंपारण","कैमूर (भभुआ)","रोहतास","जमुई","उपर्युक्त में से कोई नहीं / उपर्युक्त में से एक से अधिक",B,"भारत वन स्थिति रिपोर्ट (ISFR) के अनुसार बिहार में सर्वाधिक वन क्षेत्र वाला जिला कैमूर (1,051.56 वर्ग किमी) है, जबकि प्रतिशत की दृष्टि से भी कैमूर (31.56%) प्रथम स्थान पर है।","According to ISFR, Kaimur district has the largest forest cover in Bihar (1,051.56 sq km) as well as the highest forest percentage (31.56%).",Medium,"68th BPSC Prelims [डेमो]",2023,true`;

export const SAMPLE_JSON_CONTENT = JSON.stringify(SAMPLE_QUESTIONS_DATA, null, 2);

/**
 * Robust CSV parser that correctly handles escaped quotes, internal commas, and line breaks.
 */
export function parseCSVToRows(csvText: string): string[][] {
  const rows: string[][] = [];
  let currentRow: string[] = [];
  let currentField = '';
  let inQuotes = false;

  for (let i = 0; i < csvText.length; i++) {
    const char = csvText[i];
    const nextChar = csvText[i + 1];

    if (char === '"') {
      if (inQuotes && nextChar === '"') {
        currentField += '"';
        i++; // skip escaped quote
      } else {
        inQuotes = !inQuotes;
      }
    } else if (char === ',' && !inQuotes) {
      currentRow.push(currentField.trim());
      currentField = '';
    } else if ((char === '\r' || char === '\n') && !inQuotes) {
      if (char === '\r' && nextChar === '\n') {
        i++;
      }
      currentRow.push(currentField.trim());
      if (currentRow.some((f) => f.length > 0)) {
        rows.push(currentRow);
      }
      currentRow = [];
      currentField = '';
    } else {
      currentField += char;
    }
  }

  if (currentField.length > 0 || currentRow.length > 0) {
    currentRow.push(currentField.trim());
    if (currentRow.some((f) => f.length > 0)) {
      rows.push(currentRow);
    }
  }

  return rows;
}

/**
 * Normalizes Hindi question text for reliable duplicate detection
 */
export function normalizeHindiText(text: string): string {
  return text
    .trim()
    .replace(/[\u200B-\u200D\uFEFF]/g, '')
    .replace(/[।.,?!;:'"“”‘’]/g, '')
    .replace(/\s+/g, ' ')
    .toLowerCase();
}

/**
 * Normalizes user-supplied subject names/IDs to standard system subject IDs
 */
export function normalizeSubjectId(rawSubject: any): string {
  if (!rawSubject || typeof rawSubject !== 'string') return 'bihar-gk';
  const clean = rawSubject.trim().toLowerCase();

  if (clean === 'bihar-gk' || clean.includes('bihar') || clean.includes('बिहार')) return 'bihar-gk';
  if (clean === 'national-movement' || clean.includes('movement') || clean.includes('आंदोलन')) return 'national-movement';
  if (clean === 'indian-history' || clean === 'history' || clean.includes('history') || clean.includes('इतिहास')) return 'indian-history';
  if (clean === 'geography' || clean.includes('geography') || clean.includes('भूगोल')) return 'geography';
  if (clean === 'polity' || clean.includes('polity') || clean.includes('constitution') || clean.includes('संविधान') || clean.includes('राजव्यवस्था')) return 'polity';
  if (clean === 'economy' || clean.includes('economy') || clean.includes('अर्थव्यवस्था') || clean.includes('बजट')) return 'economy';
  if (clean === 'general-science' || clean === 'science' || clean.includes('science') || clean.includes('विज्ञान') || clean.includes('भौतिकी') || clean.includes('रसायन') || clean.includes('जीव')) return 'general-science';
  if (clean === 'environment' || clean.includes('environment') || clean.includes('पर्यावरण')) return 'environment';
  if (clean === 'current-affairs' || clean.includes('current') || clean.includes('समसामयिकी') || clean.includes('करेंट')) return 'current-affairs';
  if (clean === 'general-hindi' || clean === 'hindi' || clean.includes('hindi') || clean.includes('हिन्दी')) return 'general-hindi';
  if (clean === 'maths-reasoning' || clean === 'maths' || clean.includes('math') || clean.includes('reasoning') || clean.includes('गणित') || clean.includes('तर्कशक्ति')) return 'maths-reasoning';

  return 'bihar-gk';
}

/**
 * Validates a single question candidate strictly against BPSC rules:
 * 1. questionHindi required non-empty
 * 2. Exactly 5 options (A-E) non-empty
 * 3. Exactly one correct answer in ['A', 'B', 'C', 'D', 'E']
 * 4. explanationHindi required non-empty
 */
export function validateQuestionCandidate(
  q: any,
  rowNumber: number
): { isValid: boolean; question?: Question; errors: string[] } {
  const errors: string[] = [];

  // 1. Validate questionHindi
  const questionHindi = typeof q.questionHindi === 'string' ? q.questionHindi.trim() : '';
  if (!questionHindi) {
    errors.push('हिन्दी में प्रश्न (questionHindi) अनिवार्य है');
  }

  // 2. Validate exactly 5 options (A, B, C, D, E)
  let optionsHindi: string[] = [];
  if (Array.isArray(q.optionsHindi)) {
    optionsHindi = q.optionsHindi.map((opt: any) => String(opt ?? '').trim());
  } else if (
    q.optionA !== undefined ||
    q.optionB !== undefined ||
    q.optionC !== undefined ||
    q.optionD !== undefined ||
    q.optionE !== undefined
  ) {
    optionsHindi = [
      String(q.optionA ?? '').trim(),
      String(q.optionB ?? '').trim(),
      String(q.optionC ?? '').trim(),
      String(q.optionD ?? '').trim(),
      String(q.optionE ?? '').trim(),
    ];
  }

  if (optionsHindi.length !== 5) {
    errors.push(`प्रश्न में ठीक 5 विकल्प (A-E) होने चाहिए (वर्तमान विकल्प: ${optionsHindi.length})`);
  } else {
    const letters = ['A', 'B', 'C', 'D', 'E'];
    for (let i = 0; i < 5; i++) {
      if (!optionsHindi[i]) {
        errors.push(`विकल्प ${letters[i]} रिक्त है`);
      }
    }
  }

  // 3. Validate correct answer (must be A, B, C, D, or E)
  const rawAnswer = String(q.correctAnswer ?? '').trim().toUpperCase();
  const validOptionKeys: OptionKey[] = ['A', 'B', 'C', 'D', 'E'];
  if (!validOptionKeys.includes(rawAnswer as OptionKey)) {
    errors.push(`सही उत्तर केवल 'A', 'B', 'C', 'D' या 'E' होना चाहिए (प्राप्त मान: "${q.correctAnswer ?? ''}")`);
  }

  // 4. Validate explanationHindi
  const explanationHindi = typeof q.explanationHindi === 'string' ? q.explanationHindi.trim() : '';
  if (!explanationHindi) {
    errors.push('हिन्दी में विस्तृत व्याख्या (explanationHindi) अनिवार्य है');
  }

  if (errors.length > 0) {
    return { isValid: false, errors };
  }

  // Options English fallback
  let optionsEnglish: string[] = [];
  if (Array.isArray(q.optionsEnglish) && q.optionsEnglish.length === 5) {
    optionsEnglish = q.optionsEnglish.map((opt: any) => String(opt ?? '').trim());
  } else {
    optionsEnglish = [
      optionsHindi[0],
      optionsHindi[1],
      optionsHindi[2],
      optionsHindi[3],
      'None of the above / More than one of the above',
    ];
  }

  const isDemo = Boolean(q.isDemo) || 
    questionHindi.includes('डेमो') || 
    questionHindi.includes('परीक्षण') || 
    (q.topic && (String(q.topic).includes('डेमो') || String(q.topic).includes('परीक्षण')));

  const validated: Question = {
    id: q.id && String(q.id).trim().length > 0 ? String(q.id) : `imp-${Date.now()}-${rowNumber}-${Math.random().toString(36).substr(2, 4)}`,
    subjectId: normalizeSubjectId(q.subjectId),
    topic: q.topic ? String(q.topic).trim() : 'General Studies',
    questionHindi,
    questionEnglish: q.questionEnglish ? String(q.questionEnglish).trim() : questionHindi,
    optionsHindi: [optionsHindi[0], optionsHindi[1], optionsHindi[2], optionsHindi[3], optionsHindi[4]],
    optionsEnglish: [optionsEnglish[0], optionsEnglish[1], optionsEnglish[2], optionsEnglish[3], optionsEnglish[4]],
    correctAnswer: rawAnswer as OptionKey,
    explanationHindi,
    explanationEnglish: q.explanationEnglish ? String(q.explanationEnglish).trim() : explanationHindi,
    difficulty: ['Easy', 'Medium', 'Hard'].includes(q.difficulty) ? q.difficulty : 'Medium',
    source: q.source ? String(q.source).trim() : (isDemo ? 'BPSC Demo/Test Set' : 'Bulk Import'),
    year: q.year ? Number(q.year) || undefined : undefined,
    isPYQ: Boolean(q.isPYQ),
    isAIGenerated: Boolean(q.isAIGenerated),
    verified: q.verified !== false,
    isImported: true,
    importedAt: q.importedAt || new Date().toISOString(),
    isDemo,
    createdAt: q.createdAt || new Date().toISOString(),
  };

  return { isValid: true, question: validated, errors: [] };
}

/**
 * Parses raw text (CSV or JSON) into candidate objects with row numbers
 */
export function extractCandidateRows(
  rawText: string,
  filename: string
): { fileType: 'csv' | 'json'; candidates: Array<{ rowNumber: number; item: any; rawTitle: string }>; parseError?: string } {
  const isJson = filename.toLowerCase().endsWith('.json') || rawText.trim().startsWith('[');
  const fileType: 'csv' | 'json' = isJson ? 'json' : 'csv';

  if (fileType === 'json') {
    let parsed: any;
    try {
      parsed = JSON.parse(rawText);
    } catch (err: any) {
      return { fileType, candidates: [], parseError: `अमान्य JSON प्रारूप (Invalid JSON): ${err?.message || 'Syntax error'}` };
    }

    if (!Array.isArray(parsed)) {
      return { fileType, candidates: [], parseError: 'JSON फाइल में प्रश्नों की एक सूची (Array) होनी चाहिए: [...]' };
    }

    const candidates = parsed.map((item, idx) => ({
      rowNumber: idx + 1,
      item,
      rawTitle: item?.questionHindi || `Question #${idx + 1}`,
    }));

    return { fileType, candidates };
  } else {
    // CSV Parsing
    const rows = parseCSVToRows(rawText);
    if (rows.length <= 1) {
      return { fileType, candidates: [], parseError: 'CSV फाइल रिक्त है या केवल हेडर पंक्ति मौजूद है' };
    }

    const header = rows[0].map((h) => h.trim().toLowerCase());
    const dataRows = rows.slice(1);

    const getColIndex = (names: string[]): number => {
      for (const name of names) {
        const idx = header.indexOf(name.toLowerCase());
        if (idx !== -1) return idx;
      }
      return -1;
    };

    const subjIdx = getColIndex(['subjectid', 'subject', 'विषय']);
    const topicIdx = getColIndex(['topic', 'विषय-वस्तु', 'अध्याय']);
    const qHiIdx = getColIndex(['questionhindi', 'question', 'प्रश्न', 'hindi_question']);
    const qEnIdx = getColIndex(['questionenglish', 'english_question', 'प्रश्न_अंग्रेजी']);
    const optAIdx = getColIndex(['optiona', 'a', 'विकल्प_a', 'option_a']);
    const optBIdx = getColIndex(['optionb', 'b', 'विकल्प_b', 'option_b']);
    const optCIdx = getColIndex(['optionc', 'c', 'विकल्प_c', 'option_c']);
    const optDIdx = getColIndex(['optiond', 'd', 'विकल्प_d', 'option_d']);
    const optEIdx = getColIndex(['optione', 'e', 'विकल्प_e', 'option_e']);
    const ansIdx = getColIndex(['correctanswer', 'answer', 'उत्तर', 'correct']);
    const explHiIdx = getColIndex(['explanationhindi', 'explanation', 'व्याख्या', 'hindi_explanation']);
    const explEnIdx = getColIndex(['explanationenglish', 'english_explanation', 'व्याख्या_अंग्रेजी']);
    const diffIdx = getColIndex(['difficulty', 'कठिनाई']);
    const srcIdx = getColIndex(['source', 'स्रोत']);
    const yearIdx = getColIndex(['year', 'वर्ष']);
    const pyqIdx = getColIndex(['ispyq', 'pyq']);

    const candidates = dataRows.map((row, index) => {
      const rowNumber = index + 2; // +1 for 1-based, +1 for header
      const item: any = {
        subjectId: subjIdx !== -1 ? row[subjIdx] : row[0],
        topic: topicIdx !== -1 ? row[topicIdx] : row[1],
        questionHindi: qHiIdx !== -1 ? row[qHiIdx] : row[2],
        questionEnglish: qEnIdx !== -1 ? row[qEnIdx] : row[3],
        optionA: optAIdx !== -1 ? row[optAIdx] : row[4],
        optionB: optBIdx !== -1 ? row[optBIdx] : row[5],
        optionC: optCIdx !== -1 ? row[optCIdx] : row[6],
        optionD: optDIdx !== -1 ? row[optDIdx] : row[7],
        optionE: optEIdx !== -1 ? row[optEIdx] : row[8],
        correctAnswer: ansIdx !== -1 ? row[ansIdx] : row[9],
        explanationHindi: explHiIdx !== -1 ? row[explHiIdx] : row[10],
        explanationEnglish: explEnIdx !== -1 ? row[explEnIdx] : row[11],
        difficulty: diffIdx !== -1 ? row[diffIdx] : row[12],
        source: srcIdx !== -1 ? row[srcIdx] : row[13],
        year: yearIdx !== -1 ? row[yearIdx] : row[14],
        isPYQ: pyqIdx !== -1 ? row[pyqIdx] : row[15],
      };

      return {
        rowNumber,
        item,
        rawTitle: item.questionHindi || `CSV Row #${rowNumber}`,
      };
    });

    return { fileType, candidates };
  }
}

/**
 * Generates structured PREVIEW data before committing to database,
 * performing full 5-option validation and duplicate detection against existing questions.
 */
export function generateImportPreview(
  rawText: string,
  filename: string,
  existingQuestions: Question[] = []
): ImportPreviewResult {
  const { fileType, candidates, parseError } = extractCandidateRows(rawText, filename);

  if (parseError) {
    return {
      filename,
      fileType,
      totalParsed: 0,
      validCount: 0,
      duplicateCount: 0,
      errorCount: 1,
      items: [
        {
          rowNumber: 1,
          rawTitle: 'फाइल पार्सिंग त्रुटि',
          isValid: false,
          isDuplicate: false,
          errors: [parseError],
        },
      ],
      validUniqueQuestions: [],
      duplicateQuestions: [],
    };
  }

  // Pre-index existing questions for duplicate lookup
  const existingIdSet = new Set(existingQuestions.map((q) => q.id));
  const existingNormalizedTextMap = new Map<string, Question>();
  existingQuestions.forEach((q) => {
    const norm = normalizeHindiText(q.questionHindi);
    if (norm) existingNormalizedTextMap.set(norm, q);
  });

  // Track intra-batch duplicates as well
  const seenBatchNormalizedText = new Set<string>();

  const items: QuestionPreviewItem[] = [];
  const validUniqueQuestions: Question[] = [];
  const duplicateQuestions: Question[] = [];

  for (const { rowNumber, item, rawTitle } of candidates) {
    const { isValid, question, errors } = validateQuestionCandidate(item, rowNumber);

    if (!isValid || !question) {
      items.push({
        rowNumber,
        rawTitle: String(rawTitle).slice(0, 70),
        isValid: false,
        isDuplicate: false,
        errors,
      });
      continue;
    }

    // Check duplicate
    const norm = normalizeHindiText(question.questionHindi);
    let isDuplicate = false;
    let duplicateReason: string | undefined = undefined;
    let duplicateMatchedQuestion: Question | undefined = undefined;

    if (item.id && existingIdSet.has(item.id)) {
      isDuplicate = true;
      duplicateReason = `समान ID (${item.id}) वाला प्रश्न पहले से प्रश्न बैंक में मौजूद है।`;
      duplicateMatchedQuestion = existingQuestions.find((q) => q.id === item.id);
    } else if (norm && existingNormalizedTextMap.has(norm)) {
      isDuplicate = true;
      duplicateReason = 'समान हिन्दी प्रश्न पहले से प्रश्न बैंक में मौजूद है (Duplicate of existing question in bank)।';
      duplicateMatchedQuestion = existingNormalizedTextMap.get(norm);
    } else if (norm && seenBatchNormalizedText.has(norm)) {
      isDuplicate = true;
      duplicateReason = 'इस आयात फाइल में यह प्रश्न पहले भी आ चुका है (Duplicate within file)।';
    }

    if (isDuplicate) {
      duplicateQuestions.push(question);
      items.push({
        rowNumber,
        rawTitle: question.questionHindi.slice(0, 70),
        isValid: true,
        isDuplicate: true,
        duplicateReason,
        duplicateMatchedQuestion,
        question,
        errors: [],
      });
    } else {
      if (norm) seenBatchNormalizedText.add(norm);
      validUniqueQuestions.push(question);
      items.push({
        rowNumber,
        rawTitle: question.questionHindi.slice(0, 70),
        isValid: true,
        isDuplicate: false,
        question,
        errors: [],
      });
    }
  }

  const validCount = validUniqueQuestions.length;
  const duplicateCount = duplicateQuestions.length;
  const errorCount = items.filter((i) => !i.isValid).length;

  return {
    filename,
    fileType,
    totalParsed: candidates.length,
    validCount,
    duplicateCount,
    errorCount,
    items,
    validUniqueQuestions,
    duplicateQuestions,
  };
}

/**
 * Parses and validates raw CSV or JSON text and generates a structured import result report.
 * (Direct parser kept for full backwards compatibility)
 */
export function parseAndValidateImport(
  rawText: string,
  filename: string
): ImportResult {
  const preview = generateImportPreview(rawText, filename, []);
  
  const validQuestions = preview.items
    .filter((i) => i.isValid && i.question)
    .map((i) => i.question!);

  const errors: ImportErrorDetail[] = preview.items
    .filter((i) => !i.isValid)
    .map((i) => ({
      rowNumber: i.rowNumber,
      questionTitle: i.rawTitle,
      reasons: i.errors,
    }));

  return {
    filename,
    fileType: preview.fileType,
    totalParsed: preview.totalParsed,
    successCount: validQuestions.length,
    failureCount: errors.length,
    validQuestions,
    errors,
  };
}
