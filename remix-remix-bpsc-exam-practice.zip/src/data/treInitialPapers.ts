import { TREPaper } from '../types';

export const INITIAL_TRE_PAPERS: TREPaper[] = [
  // ==================== BPSC TRE 1.0 (2023) ====================
  {
    id: 'bpsc-tre-1-prt-shift-1',
    title: 'BPSC TRE 1.0 Class 1-5 General Studies (Shift 1)',
    titleHindi: 'BPSC TRE 1.0 प्राथमिक शिक्षक (कक्षा 1-5) सामान्य अध्ययन (प्रथम पाली)',
    phase: 'TRE 1.0',
    year: 2023,
    classLevel: '1-5',
    subject: 'General Studies',
    subjectHindi: 'सामान्य अध्ययन',
    shift: 'Shift 1',
    examDate: '24 August 2023',
    totalQuestions: 10,
    durationMinutes: 15,
    negativeMarking: 0,
    pdfUrl: 'https://www.bpsc.bih.nic.in',
    answerKeyPdfUrl: 'https://www.bpsc.bih.nic.in',
    isVerified: true,
    isPublished: true,
    isComingSoon: false,
    questions: [
      {
        id: 'tre1-prt-q1',
        subjectId: 'history',
        topic: '1857 का विद्रोह',
        questionHindi: '1857 के विद्रोह में बिहार का नेतृत्व किसने किया था?',
        questionEnglish: 'Who led the revolt of 1857 in Bihar?',
        optionsHindi: [
          'बाबू कुंवर सिंह',
          'नाना साहेब',
          'तात्या टोपे',
          'मौलवी अहमदुल्लाह',
          'उपर्युक्त में से कोई नहीं / उपर्युक्त में से एक से अधिक'
        ],
        optionsEnglish: [
          'Babu Kunwar Singh',
          'Nana Saheb',
          'Tatya Tope',
          'Maulvi Ahmadullah',
          'None of the above / More than one of the above'
        ],
        correctAnswer: 'A',
        explanationHindi: 'जगदीशपुर (भोजपुर) के जमींदार बाबू कुंवर सिंह ने लगभग 80 वर्ष की आयु में बिहार में 1857 के सिपाही विद्रोह का शौर्यपूर्ण नेतृत्व किया था।',
        explanationEnglish: 'Babu Kunwar Singh, the zamindar of Jagdishpur (Bhojpur), led the 1857 revolt in Bihar at the age of nearly 80.',
        difficulty: 'Easy',
        source: 'BPSC TRE 1.0 Class 1-5 (24 Aug 2023 Shift 1)',
        year: 2023,
        isPYQ: true,
        verified: true
      },
      {
        id: 'tre1-prt-q2',
        subjectId: 'national-movement',
        topic: 'चंपारण सत्याग्रह',
        questionHindi: 'चंपारण सत्याग्रह (1917) के दौरान बिहार में गांधीजी की जान किसने बचाई थी?',
        questionEnglish: 'Who saved Mahatma Gandhi\'s life in Bihar during the Champaran Satyagraha (1917)?',
        optionsHindi: [
          'बत्तख मियाँ',
          'राजेन्द्र प्रसाद',
          'राजकुमार शुक्ल',
          'महादेव देसाई',
          'उपर्युक्त में से कोई नहीं / उपर्युक्त में से एक से अधिक'
        ],
        optionsEnglish: [
          'Batthak Mian',
          'Dr. Rajendra Prasad',
          'Rajkumar Shukla',
          'Mahadev Desai',
          'None of the above / More than one of the above'
        ],
        correctAnswer: 'A',
        explanationHindi: 'चंपारण में अंग्रेज नील बगान मालिक इरविन ने रसोइये बत्तख मियाँ को गांधीजी के दूध में जहर मिलाने को कहा था, परंतु बत्तख मियाँ ने गांधीजी को सचेत कर उनकी जान बचाई थी।',
        explanationEnglish: 'Batthak Mian, an employee of indigo planter Erwin, refused to poison Gandhi\'s milk and warned him, saving his life.',
        difficulty: 'Medium',
        source: 'BPSC TRE 1.0 Class 1-5 (24 Aug 2023 Shift 1)',
        year: 2023,
        isPYQ: true,
        verified: true
      },
      {
        id: 'tre1-prt-q3',
        subjectId: 'polity',
        topic: 'संविधान सभा',
        questionHindi: 'संविधान सभा के स्थायी अध्यक्ष के रूप में 11 दिसंबर 1946 को किसे चुना गया था?',
        questionEnglish: 'Who was elected as the permanent President of the Constituent Assembly on 11 December 1946?',
        optionsHindi: [
          'डॉ. राजेन्द्र प्रसाद',
          'डॉ. भीमराव अम्बेडकर',
          'डॉ. सच्चिदानंद सिन्हा',
          'पंडित जवाहरलाल नेहरू',
          'उपर्युक्त में से कोई नहीं / उपर्युक्त में से एक से अधिक'
        ],
        optionsEnglish: [
          'Dr. Rajendra Prasad',
          'Dr. B.R. Ambedkar',
          'Dr. Sachchidananda Sinha',
          'Pt. Jawaharlal Nehru',
          'None of the above / More than one of the above'
        ],
        correctAnswer: 'A',
        explanationHindi: '9 दिसंबर 1946 को डॉ. सच्चिदानंद सिन्हा को अस्थायी अध्यक्ष चुना गया, तथा 11 दिसंबर 1946 को डॉ. राजेन्द्र प्रसाद संविधान सभा के निर्विरोध स्थायी अध्यक्ष निर्वाचित हुए।',
        explanationEnglish: 'Dr. Rajendra Prasad was elected as the permanent President of the Constituent Assembly on 11 December 1946.',
        difficulty: 'Easy',
        source: 'BPSC TRE 1.0 Class 1-5 (24 Aug 2023 Shift 1)',
        year: 2023,
        isPYQ: true,
        verified: true
      },
      {
        id: 'tre1-prt-q4',
        subjectId: 'geography',
        topic: 'बिहार का भूगोल',
        questionHindi: 'बिहार राज्य का कुल भौगोलिक क्षेत्रफल कितना है?',
        questionEnglish: 'What is the total geographical area of Bihar state?',
        optionsHindi: [
          '94,163 वर्ग किलोमीटर',
          '92,236 वर्ग किलोमीटर',
          '95,120 वर्ग किलोमीटर',
          '98,110 वर्ग किलोमीटर',
          'उपर्युक्त में से कोई नहीं / उपर्युक्त में से एक से अधिक'
        ],
        optionsEnglish: [
          '94,163 sq km',
          '92,236 sq km',
          '95,120 sq km',
          '98,110 sq km',
          'None of the above / More than one of the above'
        ],
        correctAnswer: 'A',
        explanationHindi: 'बिहार का कुल क्षेत्रफल 94,163 वर्ग किलोमीटर है, जो भारत के कुल क्षेत्रफल का लगभग 2.86 प्रतिशत है।',
        explanationEnglish: 'The total geographical area of Bihar is 94,163 square kilometres (approx 2.86% of India\'s total area).',
        difficulty: 'Easy',
        source: 'BPSC TRE 1.0 Class 1-5 (24 Aug 2023 Shift 1)',
        year: 2023,
        isPYQ: true,
        verified: true
      },
      {
        id: 'tre1-prt-q5',
        subjectId: 'science',
        topic: 'पर्यावरण एवं प्रकाश संश्लेषण',
        questionHindi: 'प्रकाश संश्लेषण प्रक्रिया में हरे पौधे किस गैस को अवशोषित करते हैं और कौन-सी गैस छोड़ते हैं?',
        questionEnglish: 'During photosynthesis, which gas is absorbed by green plants and which gas is released?',
        optionsHindi: [
          'कार्बन डाइऑक्साइड अवशोषित करते हैं तथा ऑक्सीजन छोड़ते हैं',
          'ऑक्सीजन अवशोषित करते हैं तथा नाइट्रोजन छोड़ते हैं',
          'नाइट्रोजन अवशोषित करते हैं तथा कार्बन डाइऑक्साइड छोड़ते हैं',
          'कार्बन मोनोऑक्साइड अवशोषित करते हैं तथा ऑक्सीजन छोड़ते हैं',
          'उपर्युक्त में से कोई नहीं / उपर्युक्त में से एक से अधिक'
        ],
        optionsEnglish: [
          'Absorb carbon dioxide and release oxygen',
          'Absorb oxygen and release nitrogen',
          'Absorb nitrogen and release carbon dioxide',
          'Absorb carbon monoxide and release oxygen',
          'None of the above / More than one of the above'
        ],
        correctAnswer: 'A',
        explanationHindi: 'प्रकाश संश्लेषण (Photosynthesis) में पौधे सूर्य के प्रकाश व क्लोरोफिल की उपस्थिति में CO2 लेते हैं और उप-उत्पाद के रूप में O2 (ऑक्सीजन) मुक्त करते हैं।',
        explanationEnglish: 'In photosynthesis, green plants absorb CO2 and water in the presence of sunlight and chlorophyll, releasing oxygen as a byproduct.',
        difficulty: 'Easy',
        source: 'BPSC TRE 1.0 Class 1-5 (24 Aug 2023 Shift 1)',
        year: 2023,
        isPYQ: true,
        verified: true
      }
    ]
  },

  {
    id: 'bpsc-tre-1-sec-social-science',
    title: 'BPSC TRE 1.0 Class 9-10 Social Science',
    titleHindi: 'BPSC TRE 1.0 माध्यमिक शिक्षक (कक्षा 9-10) सामाजिक विज्ञान',
    phase: 'TRE 1.0',
    year: 2023,
    classLevel: '9-10',
    subject: 'Social Science',
    subjectHindi: 'सामाजिक विज्ञान',
    shift: 'Shift 1',
    examDate: '26 August 2023',
    totalQuestions: 10,
    durationMinutes: 15,
    negativeMarking: 0,
    pdfUrl: 'https://www.bpsc.bih.nic.in',
    answerKeyPdfUrl: 'https://www.bpsc.bih.nic.in',
    isVerified: true,
    isPublished: true,
    isComingSoon: false,
    questions: [
      {
        id: 'tre1-tgt-sst-q1',
        subjectId: 'polity',
        topic: 'संवैधानिक संशोधन',
        questionHindi: 'भारतीय संविधान की प्रस्तावना में 42वें संविधान संशोधन अधिनियम (1976) द्वारा कौन-से तीन शब्द जोड़े गए थे?',
        questionEnglish: 'Which three words were added to the Preamble of the Indian Constitution by the 42nd Amendment Act (1976)?',
        optionsHindi: [
          'समाजवादी, पंथनिरपेक्ष और अखंडता',
          'संप्रभु, लोकतांत्रिक और गणराज्य',
          'स्वतंत्रता, समानता और बंधुत्व',
          'न्याय, समानता और एकता',
          'उपर्युक्त में से कोई नहीं / उपर्युक्त में से एक से अधिक'
        ],
        optionsEnglish: [
          'Socialist, Secular and Integrity',
          'Sovereign, Democratic and Republic',
          'Liberty, Equality and Fraternity',
          'Justice, Equality and Unity',
          'None of the above / More than one of the above'
        ],
        correctAnswer: 'A',
        explanationHindi: '42वें संविधान संशोधन 1976 द्वारा प्रस्तावना में "समाजवादी", "पंथनिरपेक्ष" (Secular) और "अखंडता" (Integrity) शब्द जोड़े गए।',
        explanationEnglish: 'The 42nd Constitutional Amendment Act, 1976 added "Socialist", "Secular", and "Integrity" to the Preamble.',
        difficulty: 'Medium',
        source: 'BPSC TRE 1.0 Class 9-10 Social Science (26 Aug 2023)',
        year: 2023,
        isPYQ: true,
        verified: true
      },
      {
        id: 'tre1-tgt-sst-q2',
        subjectId: 'history',
        topic: 'जनजातीय आंदोलन',
        questionHindi: 'छोटानागपुर क्षेत्र के मुंडा और उरांव जनजाति किस पेड़ की पूजा करते हैं?',
        questionEnglish: 'Which tree is worshipped by the Munda and Oraon tribes of the Chotanagpur region?',
        optionsHindi: [
          'कदंब और महुआ',
          'इमली और आम',
          'पीपल और बरगद',
          'नीम और शीशम',
          'उपर्युक्त में से कोई नहीं / उपर्युक्त में से एक से अधिक'
        ],
        optionsEnglish: [
          'Kadamba and Mahua',
          'Tamarind and Mango',
          'Peepal and Banyan',
          'Neem and Sheesham',
          'None of the above / More than one of the above'
        ],
        correctAnswer: 'A',
        explanationHindi: 'छोटानागपुर के मुंडा और उरांव जनजाति महुआ (Madhuca indica) और कदंब (Anthocephalus cadamba) के पेड़ों की पवित्र भाव से पूजा करते हैं।',
        explanationEnglish: 'The Mundas and the Santhals/Oraons of the Chotanagpur region worship Mahua and Kadamba trees.',
        difficulty: 'Medium',
        source: 'BPSC TRE 1.0 Class 9-10 Social Science (26 Aug 2023)',
        year: 2023,
        isPYQ: true,
        verified: true
      },
      {
        id: 'tre1-tgt-sst-q3',
        subjectId: 'national-movement',
        topic: 'सविनय अवज्ञा आंदोलन',
        questionHindi: 'सविनय अवज्ञा आंदोलन (1930) के दौरान बिहार में कर न देने का कौन-सा प्रसिद्ध आंदोलन चलाया गया था?',
        questionEnglish: 'During the Civil Disobedience Movement (1930), which famous no-tax campaign was launched in Bihar?',
        optionsHindi: [
          'चौकीदारी कर बंदी आंदोलन',
          'भू-राजस्व कर बंदी आंदोलन',
          'नमक उपकर बंदी आंदोलन',
          'जल कर बंदी आंदोलन',
          'उपर्युक्त में से कोई नहीं / उपर्युक्त में से एक से अधिक'
        ],
        optionsEnglish: [
          'No-Chowkidari Tax Campaign',
          'No-Land Revenue Campaign',
          'No-Salt Cess Campaign',
          'No-Water Tax Campaign',
          'None of the above / More than one of the above'
        ],
        correctAnswer: 'A',
        explanationHindi: 'बिहार एक भू-आबद्ध (Landlocked) राज्य होने के कारण समुद्र तट नहीं था, अतः यहाँ सविनय अवज्ञा आंदोलन के अंतर्गत चौकीदारी कर न देने का व्यापक आंदोलन चलाया गया।',
        explanationEnglish: 'Since Bihar was landlocked, the campaign against Chowkidari tax became the central plank of Civil Disobedience in Bihar.',
        difficulty: 'Medium',
        source: 'BPSC TRE 1.0 Class 9-10 Social Science (26 Aug 2023)',
        year: 2023,
        isPYQ: true,
        verified: true
      }
    ]
  },

  // ==================== BPSC TRE 2.0 (2023) ====================
  {
    id: 'bpsc-tre-2-middle-social-science',
    title: 'BPSC TRE 2.0 Class 6-8 Social Science & GS',
    titleHindi: 'BPSC TRE 2.0 मध्य विद्यालय (कक्षा 6-8) सामाजिक विज्ञान एवं सामान्य अध्ययन',
    phase: 'TRE 2.0',
    year: 2023,
    classLevel: '6-8',
    subject: 'Social Science',
    subjectHindi: 'सामाजिक विज्ञान',
    shift: 'Shift 1',
    examDate: '9 December 2023',
    totalQuestions: 10,
    durationMinutes: 15,
    negativeMarking: 0,
    pdfUrl: 'https://www.bpsc.bih.nic.in',
    answerKeyPdfUrl: 'https://www.bpsc.bih.nic.in',
    isVerified: true,
    isPublished: true,
    isComingSoon: false,
    questions: [
      {
        id: 'tre2-mid-sst-q1',
        subjectId: 'national-movement',
        topic: 'लखनऊ समझौता 1916',
        questionHindi: '1916 के प्रसिद्ध लखनऊ समझौते में कांग्रेस और मुस्लिम लीग के बीच समझौते में मुख्य भूमिका किसने निभाई थी?',
        questionEnglish: 'Who played the pivotal role in the famous Lucknow Pact (1916) between Congress and the Muslim League?',
        optionsHindi: [
          'बाल गंगाधर तिलक और मुहम्मद अली जिन्ना',
          'महात्मा गांधी और शौकत अली',
          'गोपाल कृष्ण गोखले और सर सैयद अहमद',
          'लाला लाजपत राय और आगा खां',
          'उपर्युक्त में से कोई नहीं / उपर्युक्त में से एक से अधिक'
        ],
        optionsEnglish: [
          'Bal Gangadhar Tilak and Muhammad Ali Jinnah',
          'Mahatma Gandhi and Shaukat Ali',
          'Gopal Krishna Gokhale and Sir Syed Ahmad',
          'Lala Lajpat Rai and Aga Khan',
          'None of the above / More than one of the above'
        ],
        correctAnswer: 'A',
        explanationHindi: 'दिसंबर 1916 के लखनऊ अधिवेशन में बाल गंगाधर तिलक और मुहम्मद अली जिन्ना के संयुक्त प्रयासों से कांग्रेस और मुस्लिम लीग के बीच ऐतिहासिक समझौता हुआ था।',
        explanationEnglish: 'Bal Gangadhar Tilak and Muhammad Ali Jinnah were the chief architects of the historic Lucknow Pact of 1916.',
        difficulty: 'Medium',
        source: 'BPSC TRE 2.0 Class 6-8 (9 Dec 2023)',
        year: 2023,
        isPYQ: true,
        verified: true
      },
      {
        id: 'tre2-mid-sst-q2',
        subjectId: 'polity',
        topic: 'उपराष्ट्रपति चुनाव',
        questionHindi: 'भारत के उपराष्ट्रपति का निर्वाचन किसके द्वारा किया जाता है?',
        questionEnglish: 'Who elects the Vice-President of India?',
        optionsHindi: [
          'संसद के दोनों सदनों (लोकसभा और राज्यसभा) के सभी सदस्यों द्वारा',
          'केवल संसद के निर्वाचित सदस्यों द्वारा',
          'संसद और राज्यों की विधानसभाओं के निर्वाचित सदस्यों द्वारा',
          'केवल राज्यसभा के सदस्यों द्वारा',
          'उपर्युक्त में से कोई नहीं / उपर्युक्त में से एक से अधिक'
        ],
        optionsEnglish: [
          'By all members of both Houses of Parliament (Lok Sabha & Rajya Sabha)',
          'Only by elected members of Parliament',
          'By elected members of Parliament and State Legislative Assemblies',
          'Only by members of Rajya Sabha',
          'None of the above / More than one of the above'
        ],
        correctAnswer: 'A',
        explanationHindi: 'अनुच्छेद 66(1) के अनुसार, उपराष्ट्रपति का निर्वाचन संसद के दोनों सदनों (लोकसभा और राज्यसभा) के सभी (निर्वाचित एवं मनोनीत) सदस्यों से मिलकर बनने वाले निर्वाचक मंडल द्वारा होता है।',
        explanationEnglish: 'Under Article 66(1), the Vice-President is elected by an electoral college consisting of all members (elected & nominated) of both Houses of Parliament.',
        difficulty: 'Medium',
        source: 'BPSC TRE 2.0 Class 6-8 (9 Dec 2023)',
        year: 2023,
        isPYQ: true,
        verified: true
      },
      {
        id: 'tre2-mid-sst-q3',
        subjectId: 'geography',
        topic: 'जनगणना 2011',
        questionHindi: '2011 की जनगणना के अनुसार बिहार राज्य की कुल साक्षरता दर कितनी है?',
        questionEnglish: 'According to the 2011 Census, what is the total literacy rate of Bihar?',
        optionsHindi: [
          '61.80 प्रतिशत',
          '63.82 प्रतिशत',
          '58.50 प्रतिशत',
          '65.40 प्रतिशत',
          'उपर्युक्त में से कोई नहीं / उपर्युक्त में से एक से अधिक'
        ],
        optionsEnglish: [
          '61.80 percent',
          '63.82 percent',
          '58.50 percent',
          '65.40 percent',
          'None of the above / More than one of the above'
        ],
        correctAnswer: 'A',
        explanationHindi: '2011 की जनगणना के अनुसार बिहार की कुल साक्षरता दर 61.80% (पुरुष साक्षरता 71.20% तथा महिला साक्षरता 51.50%) है।',
        explanationEnglish: 'As per Census 2011, the total literacy rate of Bihar is 61.80% (Male: 71.20%, Female: 51.50%).',
        difficulty: 'Easy',
        source: 'BPSC TRE 2.0 Class 6-8 (9 Dec 2023)',
        year: 2023,
        isPYQ: true,
        verified: true
      }
    ]
  },

  {
    id: 'bpsc-tre-2-sec-hindi',
    title: 'BPSC TRE 2.0 Class 9-10 Hindi & General Studies',
    titleHindi: 'BPSC TRE 2.0 माध्यमिक शिक्षक (कक्षा 9-10) हिन्दी एवं सामान्य अध्ययन',
    phase: 'TRE 2.0',
    year: 2023,
    classLevel: '9-10',
    subject: 'Hindi',
    subjectHindi: 'हिन्दी साहित्य एवं व्याकरण',
    shift: 'Shift 1',
    examDate: '8 December 2023',
    totalQuestions: 10,
    durationMinutes: 15,
    negativeMarking: 0,
    pdfUrl: 'https://www.bpsc.bih.nic.in',
    answerKeyPdfUrl: 'https://www.bpsc.bih.nic.in',
    isVerified: true,
    isPublished: true,
    isComingSoon: false,
    questions: [
      {
        id: 'tre2-tgt-hi-q1',
        subjectId: 'history',
        topic: 'हिन्दी साहित्य का इतिहास',
        questionHindi: 'हिन्दी साहित्य के इतिहास का प्रथम ग्रंथ फ्रेंच भाषा में किसने लिखा था?',
        questionEnglish: 'Who wrote the first book on the history of Hindi literature in French language?',
        optionsHindi: [
          'गार्सां द तासी',
          'जॉर्ज अब्राहम ग्रियर्सन',
          'मिश्र बंधु',
          'आचार्य रामचंद्र शुक्ल',
          'उपर्युक्त में से कोई नहीं / उपर्युक्त में से एक से अधिक'
        ],
        optionsEnglish: [
          'Garcin de Tassy',
          'George Abraham Grierson',
          'Mishra Bandhu',
          'Acharya Ramchandra Shukla',
          'None of the above / More than one of the above'
        ],
        correctAnswer: 'A',
        explanationHindi: 'फ्रेंच विद्वान गार्सां द तासी ने "इस्तवार द ला लितरेत्यूर ऐंदूई ऐ ऐंदुस्तानी" शीर्षक से 1839 में फ्रेंच भाषा में हिन्दी साहित्य का प्रथम इतिहास लिखा था।',
        explanationEnglish: 'Garcin de Tassy wrote the first history of Hindi literature titled "Histoire de la litterature hindoui et hindoustani" (1839) in French.',
        difficulty: 'Medium',
        source: 'BPSC TRE 2.0 Class 9-10 Hindi (8 Dec 2023)',
        year: 2023,
        isPYQ: true,
        verified: true
      },
      {
        id: 'tre2-tgt-hi-q2',
        subjectId: 'history',
        topic: 'छायावाद काव्य',
        questionHindi: 'छायावादी महाकाव्य "कामायनी" के रचयिता कौन हैं?',
        questionEnglish: 'Who is the author of the epic "Kamayani"?',
        optionsHindi: [
          'जयशंकर प्रसाद',
          'सूर्यकांत त्रिपाठी निराला',
          'सुमित्रानंदन पंत',
          'महादेवी वर्मा',
          'उपर्युक्त में से कोई नहीं / उपर्युक्त में से एक से अधिक'
        ],
        optionsEnglish: [
          'Jaishankar Prasad',
          'Suryakant Tripathi Nirala',
          'Sumitranandan Pant',
          'Mahadevi Varma',
          'None of the above / More than one of the above'
        ],
        correctAnswer: 'A',
        explanationHindi: 'छायावाद के प्रवर्तक जयशंकर प्रसाद द्वारा रचित "कामायनी" (1936) में कुल 15 सर्ग हैं और यह हिन्दी साहित्य की अप्रतिम कालजयी कृति मानी जाती है।',
        explanationEnglish: 'Kamayani (1936) was written by Jaishankar Prasad, featuring 15 cantos, and is considered the crowning achievement of the Chhayavad era.',
        difficulty: 'Easy',
        source: 'BPSC TRE 2.0 Class 9-10 Hindi (8 Dec 2023)',
        year: 2023,
        isPYQ: true,
        verified: true
      }
    ]
  },

  // ==================== BPSC TRE 3.0 (2024 Re-Exam) ====================
  {
    id: 'bpsc-tre-3-prt-general-studies',
    title: 'BPSC TRE 3.0 Class 1-5 General Studies (July 2024)',
    titleHindi: 'BPSC TRE 3.0 प्राथमिक शिक्षक (कक्षा 1-5) सामान्य अध्ययन (जुलाई 2024 पुन: परीक्षा)',
    phase: 'TRE 3.0',
    year: 2024,
    classLevel: '1-5',
    subject: 'General Studies',
    subjectHindi: 'सामान्य अध्ययन',
    shift: 'Shift 1',
    examDate: '19 July 2024',
    totalQuestions: 10,
    durationMinutes: 15,
    negativeMarking: 0,
    pdfUrl: 'https://www.bpsc.bih.nic.in',
    answerKeyPdfUrl: 'https://www.bpsc.bih.nic.in',
    isVerified: true,
    isPublished: true,
    isComingSoon: false,
    questions: [
      {
        id: 'tre3-prt-q1',
        subjectId: 'national-movement',
        topic: 'चंपारण में तिनकठिया प्रथा',
        questionHindi: 'चंपारण में अंग्रेजों द्वारा लागू "तिनकठिया प्रणाली" का क्या अर्थ था?',
        questionEnglish: 'What did the "Tinkathia system" implemented by the British in Champaran mean?',
        optionsHindi: [
          'प्रति बीघा (20 कट्ठा) में से 3 कट्ठा भूमि पर नील की अनिवार्य खेती',
          'फसल का 3/20 भाग लगान के रूप में देना',
          'प्रति एकड़ 3 रुपये नकद कर देना',
          'साल में 3 महीने बेगार मजदूरी करना',
          'उपर्युक्त में से कोई नहीं / उपर्युक्त में से एक से अधिक'
        ],
        optionsEnglish: [
          'Compulsory cultivation of indigo on 3 kathas out of every bigha (20 kathas)',
          'Paying 3/20th of the crop as revenue',
          'Paying a cash tax of Rs 3 per acre',
          'Performing unpaid labour for 3 months each year',
          'None of the above / More than one of the above'
        ],
        correctAnswer: 'A',
        explanationHindi: 'तिनकठिया प्रथा के अंतर्गत प्रत्येक किसान को अपनी जोत के 1 बीघा (20 कट्ठा) में से सबसे उपजाऊ 3 कट्ठे पर अंग्रेजों के लिए नील की खेती करना अनिवार्य था।',
        explanationEnglish: 'Under Tinkathia, tenant farmers were bound by law to plant three out of every twenty parts (3/20) of their land with indigo.',
        difficulty: 'Easy',
        source: 'BPSC TRE 3.0 Class 1-5 (19 July 2024)',
        year: 2024,
        isPYQ: true,
        verified: true
      },
      {
        id: 'tre3-prt-q2',
        subjectId: 'bihar-gk',
        topic: 'जननायक कर्पूरी ठाकुर',
        questionHindi: 'वर्ष 2024 में मरणोपरांत देश के सर्वोच्च नागरिक सम्मान "भारत रत्न" से सम्मानित जननायक कर्पूरी ठाकुर का जन्म बिहार के किस जिले में हुआ था?',
        questionEnglish: 'Jannayak Karpoori Thakur, honoured with Bharat Ratna in 2024, was born in which district of Bihar?',
        optionsHindi: [
          'समस्तीपुर',
          'दरभंगा',
          'मुजफ्फरपुर',
          'मधुबनी',
          'उपर्युक्त में से कोई नहीं / उपर्युक्त में से एक से अधिक'
        ],
        optionsEnglish: [
          'Samastipur',
          'Darbhanga',
          'Muzaffarpur',
          'Madhubani',
          'None of the above / More than one of the above'
        ],
        correctAnswer: 'A',
        explanationHindi: 'जननायक कर्पूरी ठाकुर जी का जन्म 24 जनवरी 1924 को समस्तीपुर जिले के पितौंझिया (वर्तमान में कर्पूरी ग्राम) में हुआ था। उन्हें जनवरी 2024 में भारत रत्न से सम्मानित किया गया।',
        explanationEnglish: 'Jannayak Karpoori Thakur was born in Pitaunjhia (now Karpuri Gram), Samastipur district, on 24 Jan 1924. He was awarded Bharat Ratna in 2024.',
        difficulty: 'Medium',
        source: 'BPSC TRE 3.0 Class 1-5 (19 July 2024)',
        year: 2024,
        isPYQ: true,
        verified: true
      },
      {
        id: 'tre3-prt-q3',
        subjectId: 'science',
        topic: 'मानव शरीर एवं विटामिन',
        questionHindi: 'मानव शरीर में रक्त का थक्का (Blood Clotting) बनने के लिए कौन-सा विटामिन आवश्यक होता है?',
        questionEnglish: 'Which vitamin is essential for blood clotting in the human body?',
        optionsHindi: [
          'विटामिन K',
          'विटामिन C',
          'विटामिन A',
          'विटामिन D',
          'उपर्युक्त में से कोई नहीं / उपर्युक्त में से एक से अधिक'
        ],
        optionsEnglish: [
          'Vitamin K',
          'Vitamin C',
          'Vitamin A',
          'Vitamin D',
          'None of the above / More than one of the above'
        ],
        correctAnswer: 'A',
        explanationHindi: 'विटामिन K (Phylloquinone) यकृत में प्रोथ्रोम्बिन (Prothrombin) के संश्लेषण के लिए अनिवार्य है, जो रक्त का थक्का जमाने में मुख्य भूमिका निभाता है।',
        explanationEnglish: 'Vitamin K is required for the synthesis of prothrombin in the liver, which is vital for blood coagulation.',
        difficulty: 'Easy',
        source: 'BPSC TRE 3.0 Class 1-5 (19 July 2024)',
        year: 2024,
        isPYQ: true,
        verified: true
      }
    ]
  },

  {
    id: 'bpsc-tre-3-middle-math-science',
    title: 'BPSC TRE 3.0 Class 6-8 Mathematics & Science',
    titleHindi: 'BPSC TRE 3.0 मध्य विद्यालय (कक्षा 6-8) गणित एवं विज्ञान (जुलाई 2024)',
    phase: 'TRE 3.0',
    year: 2024,
    classLevel: '6-8',
    subject: 'Mathematics & Science',
    subjectHindi: 'गणित एवं विज्ञान',
    shift: 'Shift 1',
    examDate: '20 July 2024',
    totalQuestions: 10,
    durationMinutes: 15,
    negativeMarking: 0,
    pdfUrl: 'https://www.bpsc.bih.nic.in',
    answerKeyPdfUrl: 'https://www.bpsc.bih.nic.in',
    isVerified: true,
    isPublished: true,
    isComingSoon: false,
    questions: [
      {
        id: 'tre3-mid-sci-q1',
        subjectId: 'science',
        topic: 'ध्वनि तरंगें',
        questionHindi: 'ध्वनि तरंगें निम्नलिखित में से किस माध्यम में गमन नहीं कर सकती हैं?',
        questionEnglish: 'In which of the following mediums can sound waves NOT propagate?',
        optionsHindi: [
          'निर्वात (Vacuum) में',
          'जल में',
          'लोहे (ठोस) में',
          'वायु में',
          'उपर्युक्त में से कोई नहीं / उपर्युक्त में से एक से अधिक'
        ],
        optionsEnglish: [
          'In Vacuum',
          'In Water',
          'In Iron (Solid)',
          'In Air',
          'None of the above / More than one of the above'
        ],
        correctAnswer: 'A',
        explanationHindi: 'ध्वनि एक यांत्रिक तरंग (Mechanical wave) है, जिसके संचरण के लिए भौतिक माध्यम की आवश्यकता होती है। अतः यह निर्वात में संचरित नहीं हो सकती।',
        explanationEnglish: 'Sound is a mechanical longitudinal wave requiring a material medium to propagate; it cannot travel through a vacuum.',
        difficulty: 'Easy',
        source: 'BPSC TRE 3.0 Class 6-8 Math & Science (20 July 2024)',
        year: 2024,
        isPYQ: true,
        verified: true
      },
      {
        id: 'tre3-mid-sci-q2',
        subjectId: 'science',
        topic: 'पर्यावरण प्रदूषण',
        questionHindi: 'अम्लीय वर्षा (Acid Rain) के लिए वायुमंडल में किन गैसों की अधिकता मुख्य रूप से उत्तरदायी होती है?',
        questionEnglish: 'Which gases in the atmosphere are primarily responsible for Acid Rain?',
        optionsHindi: [
          'सल्फर डाइऑक्साइड (SO2) और नाइट्रोजन डाइऑक्साइड (NO2)',
          'कार्बन डाइऑक्साइड (CO2) और कार्बन मोनोऑक्साइड (CO)',
          'मीथेन (CH4) और ओजोन (O3)',
          'हीलियम (He) और हाइड्रोजन (H2)',
          'उपर्युक्त में से कोई नहीं / उपर्युक्त में से एक से अधिक'
        ],
        optionsEnglish: [
          'Sulfur dioxide (SO2) and Nitrogen dioxide (NO2)',
          'Carbon dioxide (CO2) and Carbon monoxide (CO)',
          'Methane (CH4) and Ozone (O3)',
          'Helium (He) and Hydrogen (H2)',
          'None of the above / More than one of the above'
        ],
        correctAnswer: 'A',
        explanationHindi: 'जीवाश्म ईंधनों के जलने से उत्सर्जित SO2 और NO2 वायुमंडल की जलवाष्प से क्रिया करके सल्फ्यूरिक अम्ल (H2SO4) और नाइट्रिक अम्ल (HNO3) बनाती हैं, जिससे अम्लीय वर्षा होती है।',
        explanationEnglish: 'SO2 and NO2 react with atmospheric water vapour to form sulfuric and nitric acids, which precipitate as acid rain.',
        difficulty: 'Medium',
        source: 'BPSC TRE 3.0 Class 6-8 Math & Science (20 July 2024)',
        year: 2024,
        isPYQ: true,
        verified: true
      }
    ]
  },

  // ==================== BPSC TRE 4.0 (Coming Soon / Verified Only) ====================
  {
    id: 'bpsc-tre-4-prt-upcoming',
    title: 'BPSC TRE 4.0 Class 1-5 Primary Teacher Paper',
    titleHindi: 'BPSC TRE 4.0 प्राथमिक शिक्षक (कक्षा 1-5) आधिकारिक प्रश्न पत्र',
    phase: 'TRE 4.0',
    year: 2025,
    classLevel: '1-5',
    subject: 'General Studies',
    subjectHindi: 'सामान्य अध्ययन एवं भाषा',
    shift: 'General',
    examDate: 'BPSC TRE 4.0 आगामी',
    totalQuestions: 150,
    durationMinutes: 120,
    negativeMarking: 0.33,
    pdfUrl: 'https://www.bpsc.bih.nic.in',
    answerKeyPdfUrl: 'https://www.bpsc.bih.nic.in',
    isVerified: false,
    isPublished: true,
    isComingSoon: true,
    questions: []
  },
  {
    id: 'bpsc-tre-4-middle-upcoming',
    title: 'BPSC TRE 4.0 Class 6-8 Middle School Paper',
    titleHindi: 'BPSC TRE 4.0 मध्य विद्यालय (कक्षा 6-8) आधिकारिक प्रश्न पत्र',
    phase: 'TRE 4.0',
    year: 2025,
    classLevel: '6-8',
    subject: 'Social Science',
    subjectHindi: 'सामाजिक विज्ञान / विषयवार',
    shift: 'General',
    examDate: 'BPSC TRE 4.0 आगामी',
    totalQuestions: 150,
    durationMinutes: 120,
    negativeMarking: 0.33,
    pdfUrl: 'https://www.bpsc.bih.nic.in',
    answerKeyPdfUrl: 'https://www.bpsc.bih.nic.in',
    isVerified: false,
    isPublished: true,
    isComingSoon: true,
    questions: []
  }
];
