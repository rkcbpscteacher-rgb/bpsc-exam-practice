import { Question } from '../types';
import { BIHAR_GK_QUESTIONS } from './questions/biharGkQuestions';
import { HISTORY_QUESTIONS } from './questions/historyQuestions';
import { GEOGRAPHY_QUESTIONS } from './questions/geographyQuestions';
import { POLITY_QUESTIONS } from './questions/polityQuestions';
import { ECONOMY_QUESTIONS } from './questions/economyQuestions';
import { SCIENCE_QUESTIONS } from './questions/scienceQuestions';
import { ENVIRONMENT_QUESTIONS } from './questions/environmentQuestions';
import { MATHS_REASONING_QUESTIONS } from './questions/mathsReasoningQuestions';
import { CURRENT_AFFAIRS_QUESTIONS } from './questions/currentAffairsQuestions';
import { HINDI_QUESTIONS } from './questions/hindiQuestions';

export const INITIAL_QUESTIONS: Question[] = [
  ...BIHAR_GK_QUESTIONS,
  ...HISTORY_QUESTIONS,
  ...GEOGRAPHY_QUESTIONS,
  ...POLITY_QUESTIONS,
  ...ECONOMY_QUESTIONS,
  ...SCIENCE_QUESTIONS,
  ...ENVIRONMENT_QUESTIONS,
  ...MATHS_REASONING_QUESTIONS,
  ...CURRENT_AFFAIRS_QUESTIONS,
  ...HINDI_QUESTIONS,
];
