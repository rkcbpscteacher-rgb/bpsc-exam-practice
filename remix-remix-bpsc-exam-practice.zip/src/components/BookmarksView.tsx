import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { useQuestions } from '../context/QuestionContext';
import { useUser } from '../context/UserContext';
import { useTest } from '../context/TestContext';
import { OptionKey } from '../types';
import { 
  Bookmark, 
  Play, 
  Trash2, 
  Edit3, 
  Save, 
  FileText, 
  BookOpenCheck,
  CheckCircle2
} from 'lucide-react';

export const BookmarksView: React.FC = () => {
  const { t, language } = useLanguage();
  const { questions } = useQuestions();
  const { profile, toggleBookmark, saveQuestionNote, getQuestionNote } = useUser();
  const { startTest } = useTest();

  const [expandedSolutions, setExpandedSolutions] = useState<Record<string, boolean>>({});
  const [editingNotes, setEditingNotes] = useState<Record<string, string>>({});
  const [activeEditingId, setActiveEditingId] = useState<string | null>(null);

  const bookmarkedQuestions = profile.bookmarks
    .map((id) => questions.find((q) => q.id === id))
    .filter((q): q is NonNullable<typeof q> => !!q);

  const handlePracticeBookmarks = () => {
    if (bookmarkedQuestions.length === 0) return;
    startTest(
      {
        questionCount: bookmarkedQuestions.length,
        subjects: [],
        mode: 'practice',
        negativeMarking: 0,
        timeLimitMinutes: 0,
        shuffleQuestions: true,
        shuffleOptions: false,
      },
      bookmarkedQuestions,
      `${language === 'hi' ? 'बुकमार्क प्रश्न अभ्यास' : 'Bookmarked Questions Drill'}`
    );
  };

  const toggleSolution = (id: string) => {
    setExpandedSolutions((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const startEditNote = (qId: string) => {
    setActiveEditingId(qId);
    setEditingNotes((prev) => ({ ...prev, [qId]: getQuestionNote(qId) }));
  };

  const handleSaveNote = (qId: string) => {
    saveQuestionNote(qId, editingNotes[qId] || '');
    setActiveEditingId(null);
  };

  const optionLetters: OptionKey[] = ['A', 'B', 'C', 'D', 'E'];

  return (
    <div className="space-y-6 pb-12">
      {/* Banner */}
      <div className="bg-gradient-to-r from-red-800 to-rose-700 text-white rounded-3xl p-5 sm:p-7 shadow-lg flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/10 text-rose-100 text-xs font-bold mb-2">
            <Bookmark className="w-3.5 h-3.5 fill-rose-200 text-rose-200" />
            <span>{language === 'hi' ? 'सहेजे गए प्रश्न' : 'Important Questions'}</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black">
            {t('bookmarksTitle')}
          </h2>
          <p className="text-xs sm:text-sm text-rose-100 max-w-xl mt-1">
            {language === 'hi'
              ? 'कठिन या उच्च प्रासंगिकता वाले प्रश्नों को व्यक्तिगत नोट्स के साथ संजो कर रखें।'
              : 'Review your saved high-yield questions along with your custom study notes.'}
          </p>
        </div>

        {bookmarkedQuestions.length > 0 && (
          <button
            onClick={handlePracticeBookmarks}
            className="px-5 py-2.5 bg-white hover:bg-rose-50 text-red-900 font-extrabold rounded-xl text-xs sm:text-sm shadow-md flex items-center gap-2 transition-all active:scale-98 shrink-0"
          >
            <Play className="w-4 h-4 fill-red-900" />
            <span>{t('practiceBookmarks')} ({bookmarkedQuestions.length})</span>
          </button>
        )}
      </div>

      {bookmarkedQuestions.length === 0 ? (
        <div className="bg-white rounded-3xl border border-slate-200 p-8 sm:p-12 text-center max-w-md mx-auto shadow-xs">
          <div className="w-16 h-16 rounded-full bg-amber-50 text-amber-500 mx-auto flex items-center justify-center mb-4">
            <Bookmark className="w-8 h-8" />
          </div>
          <h3 className="font-extrabold text-base sm:text-lg text-slate-900 mb-2">
            {language === 'hi' ? 'कोई प्रश्न बुकमार्क नहीं है' : 'No Bookmarks Yet'}
          </h3>
          <p className="text-xs sm:text-sm text-slate-500 leading-relaxed">
            {t('noBookmarks')}
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          <div className="text-xs font-bold text-slate-600 px-1">
            {bookmarkedQuestions.length} {language === 'hi' ? 'बुकमार्क प्रश्न उपलब्ध' : 'bookmarked questions'}
          </div>

          {bookmarkedQuestions.map((q, idx) => {
            const isExpanded = expandedSolutions[q.id];
            const isEditing = activeEditingId === q.id;
            const currentNote = getQuestionNote(q.id);

            return (
              <div
                key={q.id}
                className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 shadow-2xs space-y-3"
              >
                {/* Header */}
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-red-700 text-white text-xs font-bold flex items-center justify-center shrink-0">
                      {idx + 1}
                    </span>
                    <span className="text-xs font-bold px-2 py-0.5 rounded-md bg-slate-100 text-slate-700">
                      {q.topic}
                    </span>
                    {q.isPYQ && (
                      <span className="text-xs font-semibold px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-800 border border-emerald-200">
                        {q.source}
                      </span>
                    )}
                  </div>

                  <button
                    onClick={() => toggleBookmark(q.id)}
                    className="p-1.5 rounded-lg text-amber-500 hover:text-red-700 transition-colors"
                    title="Remove Bookmark"
                  >
                    <Bookmark className="w-4 h-4 fill-amber-500" />
                  </button>
                </div>

                {/* Question */}
                <p className="font-bold text-slate-900 text-sm sm:text-base leading-relaxed">
                  {q.questionHindi}
                </p>
                {q.questionEnglish && (
                  <p className="text-xs text-slate-500 italic">
                    {q.questionEnglish}
                  </p>
                )}

                {/* 5 Options */}
                <div className="space-y-1.5 pt-1">
                  {optionLetters.map((letter, optIdx) => {
                    const optHindi = q.optionsHindi[optIdx];
                    const isCorrect = letter === q.correctAnswer;

                    return (
                      <div
                        key={letter}
                        className={`p-2.5 rounded-xl border text-xs sm:text-sm flex items-start gap-2.5 ${
                          isExpanded && isCorrect
                            ? 'bg-emerald-50 border-emerald-400 text-emerald-950 font-semibold'
                            : 'bg-slate-50 border-slate-200 text-slate-700'
                        }`}
                      >
                        <span
                          className={`w-5 h-5 rounded border font-bold text-[11px] flex items-center justify-center shrink-0 mt-0.5 ${
                            isExpanded && isCorrect
                              ? 'bg-emerald-600 text-white border-emerald-600'
                              : 'bg-white text-slate-700 border-slate-300'
                          }`}
                        >
                          {letter}
                        </span>
                        <span className="flex-1 min-w-0 break-words font-devanagari">{optHindi}</span>
                      </div>
                    );
                  })}
                </div>

                {/* Personal Study Note */}
                <div className="p-3 bg-amber-50/60 rounded-xl border border-amber-200/70 text-xs">
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-amber-900 flex items-center gap-1">
                      <Edit3 className="w-3.5 h-3.5" />
                      <span>{t('personalNote')}</span>
                    </span>

                    {!isEditing && (
                      <button
                        onClick={() => startEditNote(q.id)}
                        className="text-[11px] font-bold text-amber-800 hover:underline"
                      >
                        {currentNote ? (language === 'hi' ? 'संपादित करें' : 'Edit') : (language === 'hi' ? '+ नोट जोड़ें' : '+ Add Note')}
                      </button>
                    )}
                  </div>

                  {isEditing ? (
                    <div className="space-y-2 mt-2">
                      <textarea
                        rows={2}
                        value={editingNotes[q.id] || ''}
                        onChange={(e) =>
                          setEditingNotes({ ...editingNotes, [q.id]: e.target.value })
                        }
                        placeholder={t('addNote')}
                        className="w-full p-2 bg-white border border-amber-300 rounded-lg text-xs text-slate-800 focus:outline-hidden focus:ring-1 focus:ring-amber-500"
                      />
                      <div className="flex justify-end gap-2">
                        <button
                          onClick={() => setActiveEditingId(null)}
                          className="px-2.5 py-1 text-xs text-slate-500 hover:text-slate-700"
                        >
                          {t('cancel')}
                        </button>
                        <button
                          onClick={() => handleSaveNote(q.id)}
                          className="px-3 py-1 bg-amber-700 text-white rounded-md text-xs font-bold hover:bg-amber-800 flex items-center gap-1"
                        >
                          <Save className="w-3 h-3" />
                          <span>{t('saveNote')}</span>
                        </button>
                      </div>
                    </div>
                  ) : currentNote ? (
                    <p className="text-amber-950 whitespace-pre-wrap font-medium">{currentNote}</p>
                  ) : (
                    <p className="text-amber-700/60 italic">{language === 'hi' ? 'कोई निजी नोट नहीं लिखा गया।' : 'No custom note attached.'}</p>
                  )}
                </div>

                {/* Bottom Row */}
                <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                  <button
                    type="button"
                    onClick={() => toggleSolution(q.id)}
                    className="text-xs font-bold text-red-700 hover:text-red-800 flex items-center gap-1"
                  >
                    <FileText className="w-3.5 h-3.5" />
                    <span>
                      {isExpanded
                        ? language === 'hi' ? 'व्याख्या छिपाएं' : 'Hide Solution'
                        : language === 'hi' ? 'उत्तर एवं व्याख्या देखें' : 'View Solution'}
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      startTest(
                        {
                          questionCount: 1,
                          subjects: [q.subjectId],
                          mode: 'practice',
                          negativeMarking: 0,
                          timeLimitMinutes: 0,
                          shuffleQuestions: false,
                          shuffleOptions: false,
                        },
                        [q],
                        q.topic
                      );
                    }}
                    className="px-3 py-1.5 bg-slate-900 text-white rounded-lg text-xs font-bold hover:bg-slate-800 transition-colors"
                  >
                    {language === 'hi' ? 'हल करें' : 'Practice'}
                  </button>
                </div>

                {/* Solution Box */}
                {isExpanded && (
                  <div className="p-3.5 rounded-xl bg-amber-50/80 border border-amber-200 text-xs sm:text-sm text-amber-950 font-devanagari leading-relaxed animate-in fade-in duration-150">
                    <div className="font-bold text-amber-900 mb-1">
                      {language === 'hi' ? `सही विकल्प: (${q.correctAnswer})` : `Correct Option: (${q.correctAnswer})`}
                    </div>
                    <p>{q.explanationHindi}</p>
                    {q.explanationEnglish && (
                      <p className="text-xs text-amber-800/80 italic pt-1.5 mt-1.5 border-t border-amber-200/50">
                        {q.explanationEnglish}
                      </p>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
