import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { useTest } from '../context/TestContext';
import { useUser } from '../context/UserContext';
import { BPSC_SUBJECTS } from '../data/subjects';
import { OptionKey, Question, TestResult } from '../types';
import { 
  Trophy, 
  CheckCircle2, 
  XCircle, 
  HelpCircle, 
  Clock, 
  RotateCcw, 
  ArrowLeft, 
  Bookmark, 
  ChevronDown, 
  ChevronUp, 
  ShieldCheck, 
  Share2, 
  Sparkles, 
  FileText, 
  BarChart3, 
  Percent,
  Flame
} from 'lucide-react';

interface TestResultsProps {
  result: TestResult;
  onBackToHome: () => void;
}

export const TestResults: React.FC<TestResultsProps> = ({ result, onBackToHome }) => {
  const { t, language } = useLanguage();
  const { startTest } = useTest();
  const { profile, isBookmarked, toggleBookmark, saveQuestionNote, getQuestionNote } = useUser();

  const [activeFilter, setActiveFilter] = useState<'all' | 'correct' | 'incorrect' | 'unanswered' | 'bookmarked'>('all');
  const [selectedSubjectFilter, setSelectedSubjectFilter] = useState<string>('all');
  const [expandedNotes, setExpandedNotes] = useState<Record<string, boolean>>({});

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}m ${secs}s`;
  };

  // Find incorrect questions for retry
  const incorrectQuestions = result.questions.filter((q) => {
    const ans = result.answers[q.id];
    return ans && ans.selectedOption !== null && ans.isCorrect === false;
  });

  const handleRetryMistakes = () => {
    if (incorrectQuestions.length === 0) return;
    startTest(
      {
        questionCount: incorrectQuestions.length,
        subjects: [],
        mode: 'practice', // Practice mode for revision
        negativeMarking: result.negativeMarking,
        timeLimitMinutes: 0,
        shuffleQuestions: true,
        shuffleOptions: false,
      },
      incorrectQuestions,
      `${language === 'hi' ? 'गलत प्रश्नों का सुधार' : 'Mistakes Retest'}`
    );
  };

  const handleRetakeFullTest = () => {
    startTest(
      {
        questionCount: result.totalQuestions,
        subjects: [],
        mode: result.mode,
        negativeMarking: result.negativeMarking,
        timeLimitMinutes: Math.round(result.totalQuestions * 1.2),
        shuffleQuestions: true,
        shuffleOptions: true,
      },
      result.questions,
      result.testTitle
    );
  };

  // Filtered question list for review
  const filteredQuestions = result.questions.filter((q) => {
    const ans = result.answers[q.id];
    const isSelected = ans && ans.selectedOption !== null;
    const isRight = ans && ans.isCorrect;
    const isBook = isBookmarked(q.id);

    if (selectedSubjectFilter !== 'all' && q.subjectId !== selectedSubjectFilter) {
      return false;
    }

    if (activeFilter === 'correct') return isRight;
    if (activeFilter === 'incorrect') return isSelected && !isRight;
    if (activeFilter === 'unanswered') return !isSelected;
    if (activeFilter === 'bookmarked') return isBook;
    return true;
  });

  const optionLetters: OptionKey[] = ['A', 'B', 'C', 'D', 'E'];

  // Performance Evaluation Message
  let performanceBadge = {
    title: language === 'hi' ? 'उत्कृष्ट प्रदर्शन' : 'Outstanding Performance',
    desc: language === 'hi' ? 'आपकी तैयारी बहुत मजबूत है, निरंतर अभ्यास जारी रखें।' : 'Excellent mastery of BPSC concepts.',
    color: 'bg-emerald-50 text-emerald-800 border-emerald-200',
  };
  if (result.percentage < 40) {
    performanceBadge = {
      title: language === 'hi' ? 'सुधार की आवश्यकता' : 'Needs Practice',
      desc: language === 'hi' ? 'गलत प्रश्नों की व्याख्या का ध्यानपूर्वक अध्ययन करें।' : 'Review incorrect solutions closely to strengthen fundamentals.',
      color: 'bg-amber-50 text-amber-800 border-amber-200',
    };
  } else if (result.percentage < 65) {
    performanceBadge = {
      title: language === 'hi' ? 'संतोषजनक प्रदर्शन' : 'Good Progress',
      desc: language === 'hi' ? 'कट-ऑफ के करीब हैं, कमजोर विषयों पर अधिक ध्यान दें।' : 'Approaching competitive BPSC cutoff score.',
      color: 'bg-blue-50 text-blue-800 border-blue-200',
    };
  }

  return (
    <div className="min-h-screen bg-slate-50 py-6 sm:py-10 px-3 sm:px-6">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Navigation & Header */}
        <div className="flex items-center justify-between">
          <button
            onClick={onBackToHome}
            className="flex items-center gap-1.5 text-xs sm:text-sm font-bold text-slate-600 hover:text-slate-900 bg-white border border-slate-200 px-3 py-1.5 rounded-xl transition-colors shadow-2xs"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>{t('backToHome')}</span>
          </button>

          <span className="text-xs text-slate-500 font-medium">
            {new Date(result.completedAt).toLocaleDateString(language === 'hi' ? 'hi-IN' : 'en-US', {
              day: 'numeric',
              month: 'short',
              year: 'numeric',
              hour: '2-digit',
              minute: '2-digit',
            })}
          </span>
        </div>

        {/* Scorecard Hero Card */}
        <div className="bg-white rounded-3xl border border-slate-200 shadow-md p-5 sm:p-8 overflow-hidden relative">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-6 pb-6 border-b border-slate-100">
            {/* Left: Score circle */}
            <div className="flex flex-col min-[440px]:flex-row items-center min-[440px]:items-start text-center min-[440px]:text-left gap-4 sm:gap-5 w-full sm:w-auto">
              <div className="relative w-24 h-24 sm:w-28 sm:h-28 rounded-full bg-radial from-red-600 to-red-800 text-white flex flex-col items-center justify-center shadow-lg shadow-red-900/20 shrink-0">
                <span className="text-2xl sm:text-3xl font-black leading-none">{result.score}</span>
                <span className="text-[11px] font-semibold text-red-100 mt-1">/ {result.maxScore} Marks</span>
              </div>

              <div className="min-w-0">
                <span className={`inline-block text-xs font-bold px-2.5 py-0.5 rounded-full border mb-1.5 ${performanceBadge.color}`}>
                  {performanceBadge.title}
                </span>
                <h2 className="text-lg sm:text-2xl font-black text-slate-900">
                  {result.testTitle}
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  {performanceBadge.desc}
                </p>
              </div>
            </div>

            {/* Right: Quick action buttons */}
            <div className="flex flex-col min-[390px]:flex-row sm:flex-col gap-2 w-full sm:w-auto shrink-0">
              {incorrectQuestions.length > 0 && (
                <button
                  onClick={handleRetryMistakes}
                  className="w-full sm:w-auto px-4 py-2.5 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs sm:text-sm font-bold shadow-md shadow-amber-600/20 flex items-center justify-center gap-1.5 transition-colors min-h-[44px] cursor-pointer"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>{t('retryMistakes')} ({incorrectQuestions.length})</span>
                </button>
              )}

              <button
                onClick={handleRetakeFullTest}
                className="w-full sm:w-auto px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-1.5 transition-colors min-h-[44px] cursor-pointer"
              >
                <span>{t('retakeTest')}</span>
              </button>
            </div>
          </div>

          {/* Stats Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 pt-6 text-center">
            <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100">
              <div className="text-xs text-slate-500 font-semibold mb-1 flex items-center justify-center gap-1">
                <Percent className="w-3.5 h-3.5 text-slate-400" />
                <span>{t('accuracy')}</span>
              </div>
              <div className="text-xl font-black text-slate-900">{result.percentage}%</div>
            </div>

            <div className="p-3 rounded-2xl bg-emerald-50/70 border border-emerald-100">
              <div className="text-xs text-emerald-800 font-semibold mb-1 flex items-center justify-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                <span>{t('correct')}</span>
              </div>
              <div className="text-xl font-black text-emerald-700">+{result.correct}</div>
            </div>

            <div className="p-3 rounded-2xl bg-red-50/70 border border-red-100">
              <div className="text-xs text-red-800 font-semibold mb-1 flex items-center justify-center gap-1">
                <XCircle className="w-3.5 h-3.5 text-red-600" />
                <span>{t('incorrect')}</span>
              </div>
              <div className="text-xl font-black text-red-700">
                -{result.incorrect}
                {result.negativeMarking > 0 && (
                  <span className="text-[10px] block font-mono text-red-500 font-normal">
                    (-{(result.incorrect * result.negativeMarking).toFixed(2)} neg)
                  </span>
                )}
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100">
              <div className="text-xs text-slate-500 font-semibold mb-1 flex items-center justify-center gap-1">
                <HelpCircle className="w-3.5 h-3.5 text-slate-400" />
                <span>{t('unattempted')}</span>
              </div>
              <div className="text-xl font-black text-slate-700">{result.unanswered}</div>
            </div>

            <div className="col-span-2 sm:col-span-1 p-3 rounded-2xl bg-slate-50 border border-slate-100">
              <div className="text-xs text-slate-500 font-semibold mb-1 flex items-center justify-center gap-1">
                <Clock className="w-3.5 h-3.5 text-slate-400" />
                <span>{t('timeSpent')}</span>
              </div>
              <div className="text-lg font-black text-slate-900">{formatTime(result.timeTakenSeconds)}</div>
            </div>
          </div>
        </div>

        {/* Daily Streak Achievement Banner */}
        <div className="bg-gradient-to-r from-amber-500 via-amber-600 to-orange-600 rounded-2xl text-white p-4 shadow-md flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-md flex items-center justify-center shrink-0">
              <Flame className="w-6 h-6 fill-white text-white animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-sm sm:text-base">
                  {language === 'hi' 
                    ? `दैनिक स्ट्रीक सक्रिय: ${profile.studyStreakDays} दिन लगातार!` 
                    : `Daily Streak Active: ${profile.studyStreakDays} Days Streak!`}
                </span>
                <span className="px-2 py-0.5 rounded-full bg-white/20 text-[10px] font-bold">
                  {language === 'hi' ? 'आज का क्विज पूर्ण ✓' : 'Today Recorded ✓'}
                </span>
              </div>
              <p className="text-xs text-amber-100 mt-0.5">
                {language === 'hi'
                  ? 'आपने आज का अभ्यास सफलतापूर्वक पूर्ण कर अपनी लगातार स्ट्रीक को सुरक्षित कर लिया है।'
                  : 'You have successfully logged today\'s quiz practice and preserved your streak.'}
              </p>
            </div>
          </div>

          <div className="hidden sm:block text-right shrink-0">
            <span className="text-[11px] opacity-80 block">{language === 'hi' ? 'सर्वश्रेष्ठ रिकॉर्ड' : 'Personal Best'}</span>
            <span className="font-black text-sm">{profile.longestStreakDays} {language === 'hi' ? 'दिन' : 'days'}</span>
          </div>
        </div>

        {/* Subject Breakdown Card */}
        {Object.keys(result.subjectBreakdown).length > 1 && (
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs">
            <h3 className="font-bold text-sm sm:text-base text-slate-900 mb-3 flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-red-700" />
              <span>{t('subjectWisePerformance')}</span>
            </h3>

            <div className="space-y-3">
              {Object.entries(result.subjectBreakdown).map(([subjId, data]) => {
                const subj = BPSC_SUBJECTS.find((s) => s.id === subjId);
                const name = language === 'hi' ? subj?.nameHindi : subj?.nameEnglish;
                const subjAcc = data.total > 0 ? Math.round((data.correct / data.total) * 100) : 0;

                return (
                  <div key={subjId} className="p-3 rounded-xl bg-slate-50 border border-slate-100">
                    <div className="flex items-center justify-between text-xs font-bold text-slate-800 mb-1.5">
                      <span>{name || subjId}</span>
                      <span className="font-mono text-slate-600">
                        {data.correct}/{data.total} ({subjAcc}%)
                      </span>
                    </div>

                    <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden flex">
                      <div
                        className="bg-emerald-500 h-full"
                        style={{ width: `${(data.correct / data.total) * 100}%` }}
                      />
                      <div
                        className="bg-red-400 h-full"
                        style={{ width: `${(data.incorrect / data.total) * 100}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Question Solutions & Review Section */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 mb-4 border-b border-slate-100">
            <div>
              <h3 className="font-extrabold text-base sm:text-lg text-slate-900">
                {t('reviewQuestions')}
              </h3>
              <p className="text-xs text-slate-500">
                {language === 'hi' 
                  ? 'प्रत्येक 5-विकल्प प्रश्न का सही उत्तर व मानक व्याख्या'
                  : 'Detailed solutions with authoritative references for each question'}
              </p>
            </div>

            {/* Filter Pills */}
            <div className="flex flex-wrap items-center gap-1.5 text-xs font-bold">
              <button
                onClick={() => setActiveFilter('all')}
                className={`px-2.5 py-1 rounded-lg border transition-all ${
                  activeFilter === 'all'
                    ? 'bg-slate-900 text-white border-slate-900'
                    : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                }`}
              >
                {t('filterAll')} ({result.totalQuestions})
              </button>
              <button
                onClick={() => setActiveFilter('correct')}
                className={`px-2.5 py-1 rounded-lg border transition-all ${
                  activeFilter === 'correct'
                    ? 'bg-emerald-600 text-white border-emerald-600'
                    : 'bg-white text-emerald-700 border-emerald-200 hover:bg-emerald-50'
                }`}
              >
                {t('filterCorrect')} ({result.correct})
              </button>
              <button
                onClick={() => setActiveFilter('incorrect')}
                className={`px-2.5 py-1 rounded-lg border transition-all ${
                  activeFilter === 'incorrect'
                    ? 'bg-red-600 text-white border-red-600'
                    : 'bg-white text-red-700 border-red-200 hover:bg-red-50'
                }`}
              >
                {t('filterIncorrect')} ({result.incorrect})
              </button>
              <button
                onClick={() => setActiveFilter('unanswered')}
                className={`px-2.5 py-1 rounded-lg border transition-all ${
                  activeFilter === 'unanswered'
                    ? 'bg-amber-600 text-white border-amber-600'
                    : 'bg-white text-amber-700 border-amber-200 hover:bg-amber-50'
                }`}
              >
                {t('filterUnanswered')} ({result.unanswered})
              </button>
            </div>
          </div>

          {/* List of reviewed questions */}
          <div className="space-y-6">
            {filteredQuestions.length === 0 ? (
              <div className="text-center py-10 text-slate-400 text-sm">
                {language === 'hi' ? 'इस फ़िल्टर में कोई प्रश्न नहीं है।' : 'No questions matched this filter.'}
              </div>
            ) : (
              filteredQuestions.map((q, idx) => {
                const ans = result.answers[q.id];
                const selectedOpt = ans?.selectedOption ?? null;
                const isCorrect = ans?.isCorrect ?? false;
                const bookmarked = isBookmarked(q.id);
                const note = getQuestionNote(q.id);

                return (
                  <div
                    key={q.id}
                    className="p-4 sm:p-5 rounded-2xl border border-slate-200 bg-white hover:border-slate-300 transition-colors"
                  >
                    {/* Question Header */}
                    <div className="flex items-start justify-between gap-2 mb-3">
                      <div className="flex items-center gap-2">
                        <span className="w-6 h-6 rounded-full bg-slate-900 text-white text-xs font-bold flex items-center justify-center shrink-0">
                          {idx + 1}
                        </span>
                        <span className="text-xs font-bold px-2 py-0.5 rounded-md bg-slate-100 text-slate-700">
                          {q.topic}
                        </span>
                        {q.isDemo && (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-amber-100 text-amber-900 border border-amber-300 flex items-center gap-1">
                            <Sparkles className="w-3 h-3 text-amber-700" />
                            <span>[डेमो/परीक्षण]</span>
                          </span>
                        )}
                        {q.isImported && !q.isDemo && (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-indigo-100 text-indigo-900 border border-indigo-300 flex items-center gap-1">
                            <CheckCircle2 className="w-3 h-3 text-indigo-700" />
                            <span>आयातित</span>
                          </span>
                        )}
                        {q.isPYQ && (
                          <span className="text-xs font-semibold px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-800 border border-emerald-200 flex items-center gap-1">
                            <ShieldCheck className="w-3 h-3 text-emerald-600" />
                            <span>{q.source}</span>
                          </span>
                        )}
                      </div>

                      {/* Bookmark button */}
                      <button
                        onClick={() => toggleBookmark(q.id)}
                        className={`p-1.5 rounded-lg border transition-colors ${
                          bookmarked
                            ? 'bg-amber-50 text-amber-600 border-amber-300'
                            : 'bg-white text-slate-400 hover:text-slate-700 border-slate-200'
                        }`}
                        title="Bookmark"
                      >
                        <Bookmark className={`w-3.5 h-3.5 ${bookmarked ? 'fill-amber-500' : ''}`} />
                      </button>
                    </div>

                    {/* Question Text */}
                    <p className="font-bold text-slate-900 text-sm sm:text-base leading-relaxed mb-1">
                      {q.questionHindi}
                    </p>
                    {q.questionEnglish && (
                      <p className="text-xs text-slate-500 italic mb-4">
                        {q.questionEnglish}
                      </p>
                    )}

                    {/* 5 Options Review */}
                    <div className="space-y-2 mb-4">
                      {optionLetters.map((letter, optIdx) => {
                        const optHindi = q.optionsHindi[optIdx];
                        const isThisSelected = selectedOpt === letter;
                        const isThisCorrect = letter === q.correctAnswer;

                        let style = 'border-slate-200 bg-slate-50 text-slate-700';
                        let badge = 'bg-slate-200 text-slate-700 border-slate-300';

                        if (isThisCorrect) {
                          style = 'border-emerald-500 bg-emerald-50/80 text-emerald-950 font-semibold ring-1 ring-emerald-500';
                          badge = 'bg-emerald-600 text-white border-emerald-600';
                        } else if (isThisSelected && !isThisCorrect) {
                          style = 'border-red-500 bg-red-50/80 text-red-950 font-medium ring-1 ring-red-500';
                          badge = 'bg-red-600 text-white border-red-600';
                        }

                        return (
                          <div
                            key={letter}
                            className={`p-2.5 sm:p-3 rounded-xl border text-xs sm:text-sm flex items-start gap-2 sm:gap-2.5 ${style}`}
                          >
                            <span
                              className={`w-6 h-6 rounded-md border font-bold text-xs flex items-center justify-center shrink-0 mt-0.5 ${badge}`}
                            >
                              {letter}
                            </span>
                            <div className="flex-1 min-w-0 break-words">
                              <span className="break-words font-devanagari">{optHindi}</span>
                            </div>
                            {isThisCorrect && (
                              <span className="text-[11px] font-bold text-emerald-700 shrink-0 self-center">
                                ✓ {language === 'hi' ? 'सही उत्तर' : 'Correct'}
                              </span>
                            )}
                            {isThisSelected && !isThisCorrect && (
                              <span className="text-[11px] font-bold text-red-700 shrink-0 self-center">
                                ✗ {language === 'hi' ? 'आपका चयन' : 'Your Choice'}
                              </span>
                            )}
                          </div>
                        );
                      })}
                    </div>

                    {/* Status verdict pill */}
                    <div className="flex items-center gap-2 mb-3 text-xs font-semibold">
                      {selectedOpt === null ? (
                        <span className="text-slate-500 bg-slate-100 px-2.5 py-0.5 rounded-full">
                          {language === 'hi' ? 'छोड़ दिया गया (Unanswered)' : 'Unanswered'}
                        </span>
                      ) : isCorrect ? (
                        <span className="text-emerald-700 bg-emerald-50 border border-emerald-200 px-2.5 py-0.5 rounded-full flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>{language === 'hi' ? 'सही उत्तर (+1)' : 'Correct (+1)'}</span>
                        </span>
                      ) : (
                        <span className="text-red-700 bg-red-50 border border-red-200 px-2.5 py-0.5 rounded-full flex items-center gap-1">
                          <XCircle className="w-3.5 h-3.5" />
                          <span>
                            {language === 'hi' ? 'गलत उत्तर' : 'Incorrect'}
                            {result.negativeMarking > 0 && ` (-${result.negativeMarking})`}
                          </span>
                        </span>
                      )}
                    </div>

                    {/* Solution & Explanation */}
                    <div className="p-3.5 rounded-xl bg-amber-50/70 border border-amber-200 text-xs sm:text-sm text-amber-950 leading-relaxed font-devanagari">
                      <div className="font-bold text-amber-900 mb-1 flex items-center gap-1.5">
                        <FileText className="w-4 h-4 text-amber-700" />
                        <span>{t('explanationTitle')}</span>
                      </div>
                      <p>{q.explanationHindi}</p>
                      {q.explanationEnglish && (
                        <p className="text-xs text-amber-800/80 italic pt-1.5 mt-1.5 border-t border-amber-200/50">
                          {q.explanationEnglish}
                        </p>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
