import React, { useState, useEffect } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { useQuestions } from '../context/QuestionContext';
import { useUser } from '../context/UserContext';
import { BPSC_SUBJECTS } from '../data/subjects';
import { OptionKey, Question, AdminSystemStats, MockTestTemplate, TREPaper, TREPhase, TREClassLevel, TREShift } from '../types';
import { 
  X, 
  Plus, 
  Trash2, 
  Edit, 
  Upload, 
  Download, 
  RotateCcw, 
  Search, 
  CheckCircle2, 
  AlertTriangle,
  ShieldCheck,
  FileText,
  FileCode,
  Sparkles,
  HelpCircle,
  Database,
  ArrowRight,
  Eye,
  Check,
  Filter,
  Users,
  BarChart3,
  Layers,
  Sliders,
  LogOut,
  Calendar,
  Clock
} from 'lucide-react';
import {
  ImportErrorDetail,
  ImportPreviewResult,
  ImportReportResult,
  QuestionPreviewItem,
  SAMPLE_CSV_CONTENT,
  SAMPLE_JSON_CONTENT,
  SAMPLE_QUESTIONS_DATA,
  generateImportPreview,
} from '../utils/questionImporter';

interface AdminQuestionBankProps {
  isOpen?: boolean;
  onClose?: () => void;
  isStandalonePage?: boolean;
  initialTab?: 'overview' | 'browse' | 'import' | 'create' | 'mock-builder' | 'tre-admin';
}

export const AdminQuestionBank: React.FC<AdminQuestionBankProps> = ({ 
  isOpen = true, 
  onClose,
  isStandalonePage = false,
  initialTab = 'import'
}) => {
  const { t, language } = useLanguage();
  const { questions, addQuestion, updateQuestion, deleteQuestion, bulkImportQuestions, resetToDefault } = useQuestions();
  const { token, logout, currentUser } = useUser();

  // Admin Sub-tabs: 'overview' | 'browse' | 'import' | 'create' | 'mock-builder' | 'tre-admin'
  const [activeAdminTab, setActiveAdminTab] = useState<'overview' | 'browse' | 'import' | 'create' | 'mock-builder' | 'tre-admin'>(initialTab);

  useEffect(() => {
    if (initialTab) {
      setActiveAdminTab(initialTab);
    }
  }, [initialTab]);

  // Admin System Data
  const [adminStats, setAdminStats] = useState<AdminSystemStats | null>(null);
  const [studentsList, setStudentsList] = useState<any[]>([]);
  const [trePapersList, setTrePapersList] = useState<TREPaper[]>([]);
  const [mockTestsList, setMockTestsList] = useState<MockTestTemplate[]>([]);
  const [loadingAdminData, setLoadingAdminData] = useState(false);

  // TRE Paper Builder & Admin Form State
  const [treTitle, setTreTitle] = useState('');
  const [treTitleHi, setTreTitleHi] = useState('');
  const [trePhase, setTrePhase] = useState<TREPhase>('TRE 1.0');
  const [treYear, setTreYear] = useState(2024);
  const [treClassLevel, setTreClassLevel] = useState<TREClassLevel>('1-5');
  const [treSubject, setTreSubject] = useState('General Studies');
  const [treSubjectHi, setTreSubjectHi] = useState('सामान्य अध्ययन');
  const [treShift, setTreShift] = useState<TREShift>('Shift 1');
  const [treExamDate, setTreExamDate] = useState('');
  const [treDuration, setTreDuration] = useState(15);
  const [treNegative, setTreNegative] = useState(0);
  const [trePdfUrl, setTrePdfUrl] = useState('https://www.bpsc.bih.nic.in');
  const [treAnswerKeyUrl, setTreAnswerKeyUrl] = useState('https://www.bpsc.bih.nic.in');
  const [treIsPublished, setTreIsPublished] = useState(true);
  const [treIsComingSoon, setTreIsComingSoon] = useState(false);
  const [trePaperQuestions, setTrePaperQuestions] = useState<Question[]>([]);
  const [treSuccessMsg, setTreSuccessMsg] = useState<string | null>(null);
  const [treErrorMsg, setTreErrorMsg] = useState<string | null>(null);

  // Question builder fields inside paper form
  const [pqHi, setPqHi] = useState('');
  const [pqEn, setPqEn] = useState('');
  const [pqOptA, setPqOptA] = useState('');
  const [pqOptB, setPqOptB] = useState('');
  const [pqOptC, setPqOptC] = useState('');
  const [pqOptD, setPqOptD] = useState('');
  const [pqOptE, setPqOptE] = useState('उपर्युक्त में से कोई नहीं / उपर्युक्त में से एक से अधिक');
  const [pqCorrect, setPqCorrect] = useState<OptionKey>('A');
  const [pqExpHi, setPqExpHi] = useState('');
  const [pqTopic, setPqTopic] = useState('BPSC TRE Paper MCQ');

  // Previewing paper in admin
  const [previewingTREPaper, setPreviewingTREPaper] = useState<TREPaper | null>(null);

  // Mock Test Builder Form State
  const [newMockTitle, setNewMockTitle] = useState('');
  const [newMockTitleHi, setNewMockTitleHi] = useState('');
  const [newMockDesc, setNewMockDesc] = useState('');
  const [newMockQuestionCount, setNewMockQuestionCount] = useState(25);
  const [newMockTimeMinutes, setNewMockTimeMinutes] = useState(30);
  const [newMockNegative, setNewMockNegative] = useState(0.25);
  const [newMockSubjects, setNewMockSubjects] = useState<string[]>(['bihar-gk', 'history']);
  const [newMockFullLength, setNewMockFullLength] = useState(false);
  const [mockSuccessMsg, setMockSuccessMsg] = useState<string | null>(null);

  const loadAdminData = async () => {
    setLoadingAdminData(true);
    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    const savedToken = token || localStorage.getItem('bpsc_auth_token_v1');
    if (savedToken) {
      headers['Authorization'] = `Bearer ${savedToken}`;
    }

    try {
      const [statsRes, studentsRes, mocksRes, treRes] = await Promise.all([
        fetch('/api/admin/stats', { headers }),
        fetch('/api/admin/students', { headers }),
        fetch('/api/mock-tests'),
        fetch('/api/tre-papers'),
      ]);

      if (statsRes.ok) {
        const stats = await statsRes.json();
        setAdminStats(stats);
      }
      if (studentsRes.ok) {
        const students = await studentsRes.json();
        setStudentsList(students);
      }
      if (mocksRes.ok) {
        const mocks = await mocksRes.json();
        setMockTestsList(mocks);
      }
      if (treRes.ok) {
        const papers = await treRes.json();
        setTrePapersList(papers);
      }
    } catch (err) {
      console.warn('Error fetching admin data:', err);
    } finally {
      setLoadingAdminData(false);
    }
  };

  useEffect(() => {
    loadAdminData();
  }, [token, activeAdminTab]);

  const handleAddQuestionToTREForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!pqHi.trim() || !pqOptA.trim() || !pqOptB.trim()) {
      setTreErrorMsg(language === 'hi' ? 'प्रश्न और विकल्प A, B अनिवार्य हैं' : 'Question and Options A, B are required');
      return;
    }

    const newQ: Question = {
      id: `tre-custom-q-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      subjectId: 'general-studies',
      topic: pqTopic.trim() || 'General Studies',
      questionHindi: pqHi.trim(),
      questionEnglish: pqEn.trim() || pqHi.trim(),
      optionsHindi: [
        pqOptA.trim(),
        pqOptB.trim(),
        pqOptC.trim() || 'विकल्प C',
        pqOptD.trim() || 'विकल्प D',
        pqOptE.trim() || 'उपर्युक्त में से कोई नहीं / उपर्युक्त में से एक से अधिक',
      ],
      optionsEnglish: [
        pqOptA.trim(),
        pqOptB.trim(),
        pqOptC.trim() || 'Option C',
        pqOptD.trim() || 'Option D',
        'None of the above / More than one of the above',
      ],
      correctAnswer: pqCorrect,
      explanationHindi: pqExpHi.trim() || 'BPSC आधिकारिक उत्तर कुंजी अनुसार प्रामाणिक व्याख्या।',
      explanationEnglish: pqExpHi.trim() || 'Verified as per official BPSC Answer Key.',
      difficulty: 'Medium',
      source: `${trePhase} Class ${treClassLevel} (${treYear})`,
      year: treYear,
      isPYQ: true,
      verified: true,
    };

    setTrePaperQuestions((prev) => [...prev, newQ]);
    setPqHi('');
    setPqEn('');
    setPqOptA('');
    setPqOptB('');
    setPqOptC('');
    setPqOptD('');
    setPqOptE('उपर्युक्त में से कोई नहीं / उपर्युक्त में से एक से अधिक');
    setPqCorrect('A');
    setPqExpHi('');
    setTreErrorMsg(null);
  };

  const handleCreateTREPaper = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!treTitle.trim()) {
      setTreErrorMsg(language === 'hi' ? 'पेपर का शीर्षक आवश्यक है' : 'Paper title is required');
      return;
    }

    const savedToken = token || localStorage.getItem('bpsc_auth_token_v1');
    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    if (savedToken) {
      headers['Authorization'] = `Bearer ${savedToken}`;
    }

    try {
      const res = await fetch('/api/tre-papers', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          title: treTitle.trim(),
          titleHindi: treTitleHi.trim() || treTitle.trim(),
          phase: trePhase,
          year: treYear,
          classLevel: treClassLevel,
          subject: treSubject,
          subjectHindi: treSubjectHi,
          shift: treShift,
          examDate: treExamDate || new Date().toISOString().split('T')[0],
          totalQuestions: trePaperQuestions.length,
          durationMinutes: treDuration,
          negativeMarking: treNegative,
          pdfUrl: trePdfUrl.trim(),
          answerKeyPdfUrl: treAnswerKeyUrl.trim(),
          isVerified: true,
          isPublished: treIsPublished,
          isComingSoon: treIsComingSoon,
          questions: trePaperQuestions,
        }),
      });

      if (res.ok) {
        const created = await res.json();
        setTrePapersList((prev) => [created, ...prev]);
        setTreTitle('');
        setTreTitleHi('');
        setTrePaperQuestions([]);
        setTreSuccessMsg(language === 'hi' ? 'TRE प्रश्न पत्र सफलतापूर्वक प्रकाशित/सहेजा गया!' : 'TRE Paper created and published successfully!');
        setTimeout(() => setTreSuccessMsg(null), 3500);
      } else {
        const err = await res.json();
        setTreErrorMsg(err.error || 'Failed to save paper');
      }
    } catch (err) {
      console.error(err);
      setTreErrorMsg('Network error while saving TRE paper');
    }
  };

  const handleTogglePublishTREPaper = async (paper: TREPaper) => {
    const savedToken = token || localStorage.getItem('bpsc_auth_token_v1');
    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    if (savedToken) {
      headers['Authorization'] = `Bearer ${savedToken}`;
    }

    try {
      const res = await fetch(`/api/tre-papers/${paper.id}`, {
        method: 'PUT',
        headers,
        body: JSON.stringify({ isPublished: !paper.isPublished }),
      });
      if (res.ok) {
        const updated = await res.json();
        setTrePapersList((prev) => prev.map((p) => (p.id === paper.id ? updated : p)));
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleDeleteTREPaper = async (paperId: string) => {
    const savedToken = token || localStorage.getItem('bpsc_auth_token_v1');
    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    if (savedToken) {
      headers['Authorization'] = `Bearer ${savedToken}`;
    }

    try {
      await fetch(`/api/tre-papers/${paperId}`, {
        method: 'DELETE',
        headers,
      });
      setTrePapersList((prev) => prev.filter((p) => p.id !== paperId));
    } catch (err) {
      console.error(err);
    }
  };

  const handleCreateMockTest = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMockTitle.trim()) return;

    const savedToken = token || localStorage.getItem('bpsc_auth_token_v1');
    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    if (savedToken) {
      headers['Authorization'] = `Bearer ${savedToken}`;
    }

    try {
      const res = await fetch('/api/mock-tests', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          title: newMockTitle.trim(),
          titleHindi: newMockTitleHi.trim() || newMockTitle.trim(),
          description: newMockDesc.trim(),
          subjectIds: newMockSubjects,
          questionCount: newMockQuestionCount,
          timeLimitMinutes: newMockTimeMinutes,
          negativeMarking: newMockNegative,
          totalMarks: newMockQuestionCount,
          isFullLength: newMockFullLength,
        }),
      });

      if (res.ok) {
        const created = await res.json();
        setMockTestsList((prev) => [created, ...prev]);
        setNewMockTitle('');
        setNewMockTitleHi('');
        setNewMockDesc('');
        setMockSuccessMsg(language === 'hi' ? 'मॉक टेस्ट सफलतापूर्वक बनाया गया!' : 'Mock test created successfully!');
        setTimeout(() => setMockSuccessMsg(null), 3000);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleDeleteMockTest = async (mockId: string) => {
    const savedToken = token || localStorage.getItem('bpsc_auth_token_v1');
    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    if (savedToken) {
      headers['Authorization'] = `Bearer ${savedToken}`;
    }

    try {
      await fetch(`/api/mock-tests/${mockId}`, {
        method: 'DELETE',
        headers,
      });
      setMockTestsList((prev) => prev.filter((m) => m.id !== mockId));
    } catch (err) {
      console.error(err);
    }
  };

  const [search, setSearch] = useState('');
  const [selectedSubject, setSelectedSubject] = useState('all');
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>('all');
  const [selectedOrigin, setSelectedOrigin] = useState<'all' | 'original' | 'imported' | 'demo'>('all');
  const [editingQuestion, setEditingQuestion] = useState<Question | null>(null);

  // Form error & confirmations
  const [formError, setFormError] = useState<string | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  // Import states & reports
  const [previewData, setPreviewData] = useState<ImportPreviewResult | null>(null);
  const [skipDuplicates, setSkipDuplicates] = useState<boolean>(true);
  const [previewFilter, setPreviewFilter] = useState<'all' | 'valid' | 'duplicates' | 'errors'>('all');
  const [importReport, setImportReport] = useState<ImportReportResult | null>(null);
  const [isProcessingImport, setIsProcessingImport] = useState(false);

  // Form State for Add / Edit
  const [formSubjectId, setFormSubjectId] = useState('bihar-gk');
  const [formTopic, setFormTopic] = useState('');
  const [formQuestionHi, setFormQuestionHi] = useState('');
  const [formQuestionEn, setFormQuestionEn] = useState('');
  const [formOptionsHi, setFormOptionsHi] = useState<[string, string, string, string, string]>([
    '', '', '', '', 'उपर्युक्त में से कोई नहीं / उपर्युक्त में से एक से अधिक'
  ]);
  const [formOptionsEn, setFormOptionsEn] = useState<[string, string, string, string, string]>([
    '', '', '', '', 'None of the above / More than one of the above'
  ]);
  const [formCorrectAnswer, setFormCorrectAnswer] = useState<OptionKey>('A');
  const [formExplanationHi, setFormExplanationHi] = useState('');
  const [formExplanationEn, setFormExplanationEn] = useState('');
  const [formDifficulty, setFormDifficulty] = useState<'Easy' | 'Medium' | 'Hard'>('Medium');
  const [formSource, setFormSource] = useState('BPSC Model Set');
  const [formYear, setFormYear] = useState<number>(2024);
  const [formIsPYQ, setFormIsPYQ] = useState(false);
  const [formIsAIGenerated, setFormIsAIGenerated] = useState(false);
  const [formVerified, setFormVerified] = useState(true);

  if (!isOpen && !isStandalonePage) return null;

  const handleOpenAdd = () => {
    setEditingQuestion(null);
    setFormError(null);
    setFormSubjectId('bihar-gk');
    setFormTopic('');
    setFormQuestionHi('');
    setFormQuestionEn('');
    setFormOptionsHi(['', '', '', '', 'उपर्युक्त में से कोई नहीं / उपर्युक्त में से एक से अधिक']);
    setFormOptionsEn(['', '', '', '', 'None of the above / More than one of the above']);
    setFormCorrectAnswer('A');
    setFormExplanationHi('');
    setFormExplanationEn('');
    setFormDifficulty('Medium');
    setFormSource('BPSC Practice Bank');
    setFormYear(2024);
    setFormIsPYQ(false);
    setFormIsAIGenerated(false);
    setFormVerified(true);
    setActiveAdminTab('create');
  };

  const handleOpenEdit = (q: Question) => {
    setEditingQuestion(q);
    setFormError(null);
    setFormSubjectId(q.subjectId);
    setFormTopic(q.topic);
    setFormQuestionHi(q.questionHindi);
    setFormQuestionEn(q.questionEnglish);
    setFormOptionsHi([...q.optionsHindi]);
    setFormOptionsEn([...q.optionsEnglish]);
    setFormCorrectAnswer(q.correctAnswer);
    setFormExplanationHi(q.explanationHindi);
    setFormExplanationEn(q.explanationEnglish);
    setFormDifficulty(q.difficulty);
    setFormSource(q.source);
    setFormYear(q.year || 2024);
    setFormIsPYQ(q.isPYQ);
    setFormIsAIGenerated(q.isAIGenerated || false);
    setFormVerified(q.verified !== false);
    setActiveAdminTab('create');
  };

  const handleSaveForm = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (!formQuestionHi.trim()) {
      setFormError(language === 'hi' ? 'कृपया हिन्दी में प्रश्न दर्ज करें।' : 'Please enter the question in Hindi.');
      return;
    }

    // Ensure all 5 options have text
    for (let i = 0; i < 5; i++) {
      if (!formOptionsHi[i]?.trim()) {
        const optLetter = ['A', 'B', 'C', 'D', 'E'][i];
        setFormError(language === 'hi' ? `कृपया विकल्प ${optLetter} का विवरण दर्ज करें।` : `Please enter text for Option ${optLetter}.`);
        return;
      }
    }

    if (!formExplanationHi.trim()) {
      setFormError(language === 'hi' ? 'कृपया हिन्दी में विस्तृत व्याख्या दर्ज करें।' : 'Please enter the detailed explanation in Hindi.');
      return;
    }

    const payload = {
      subjectId: formSubjectId,
      topic: formTopic.trim() || 'General Practice',
      questionHindi: formQuestionHi.trim(),
      questionEnglish: formQuestionEn.trim() || formQuestionHi.trim(),
      optionsHindi: formOptionsHi,
      optionsEnglish: formOptionsEn,
      correctAnswer: formCorrectAnswer,
      explanationHindi: formExplanationHi.trim(),
      explanationEnglish: formExplanationEn.trim() || formExplanationHi.trim(),
      difficulty: formDifficulty,
      source: formSource.trim() || 'BPSC Question Bank',
      year: formYear,
      isPYQ: formIsPYQ,
      isAIGenerated: formIsAIGenerated,
      verified: formVerified,
    };

    if (editingQuestion) {
      await updateQuestion(editingQuestion.id, payload);
    } else {
      await addQuestion(payload);
    }

    setEditingQuestion(null);
    setActiveAdminTab('browse');
  };

  // CSV/JSON File Upload Handler - Generates Preview First with Duplicate Detection
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsProcessingImport(true);
    setImportReport(null);
    const reader = new FileReader();

    reader.onload = async (evt) => {
      try {
        const text = evt.target?.result as string;
        const preview = generateImportPreview(text, file.name, questions);
        setPreviewData(preview);
        setPreviewFilter('all');
        e.target.value = ''; // Reset file input
      } catch (err: any) {
        setImportReport({
          filename: file.name,
          fileType: file.name.endsWith('.json') ? 'json' : 'csv',
          totalProcessed: 0,
          successfulCount: 0,
          duplicatesSkippedCount: 0,
          failureCount: 1,
          importedQuestions: [],
          errors: [
            {
              rowNumber: 1,
              questionTitle: 'फाइल पढ़ने में त्रुटि (File Read Error)',
              reasons: [err?.message || 'फाइल पढ़ने में अप्रत्याशित समस्या हुई'],
            },
          ],
        });
      } finally {
        setIsProcessingImport(false);
      }
    };

    reader.readAsText(file, 'utf-8');
  };

  // Load 5 Verified Authentic Sample Questions into Preview for Inspection & Testing
  const handleLoadSamplePreview = () => {
    setIsProcessingImport(true);
    setImportReport(null);
    try {
      const preview = generateImportPreview(SAMPLE_JSON_CONTENT, 'sample_5_bpsc_demo_questions.json', questions);
      setPreviewData(preview);
      setPreviewFilter('all');
    } finally {
      setIsProcessingImport(false);
    }
  };

  // Confirm and Commit the imported questions from preview to question bank
  const handleConfirmImport = async () => {
    if (!previewData) return;

    setIsProcessingImport(true);
    try {
      // Determine questions to import based on duplicate preference
      const questionsToImport = skipDuplicates
        ? previewData.validUniqueQuestions
        : [...previewData.validUniqueQuestions, ...previewData.duplicateQuestions];

      if (questionsToImport.length > 0) {
        await bulkImportQuestions(questionsToImport);
      }

      const invalidErrors: ImportErrorDetail[] = previewData.items
        .filter((item) => !item.isValid)
        .map((item) => ({
          rowNumber: item.rowNumber,
          questionTitle: item.rawTitle,
          reasons: item.errors,
        }));

      const report: ImportReportResult = {
        filename: previewData.filename,
        fileType: previewData.fileType,
        totalProcessed: previewData.totalParsed,
        successfulCount: questionsToImport.length,
        duplicatesSkippedCount: skipDuplicates ? previewData.duplicateCount : 0,
        failureCount: previewData.errorCount,
        importedQuestions: questionsToImport,
        errors: invalidErrors,
      };

      setImportReport(report);
      setPreviewData(null);
    } finally {
      setIsProcessingImport(false);
    }
  };

  // Download Sample CSV Template
  const handleDownloadSampleCSV = () => {
    const blob = new Blob([SAMPLE_CSV_CONTENT], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'bpsc_questions_sample_template.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  // Download Sample JSON Template
  const handleDownloadSampleJSON = () => {
    const blob = new Blob([SAMPLE_JSON_CONTENT], { type: 'application/json;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'bpsc_questions_sample_template.json');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  // Export Entire Question Bank to JSON
  const handleExportJSON = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(questions, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `bpsc_question_bank_all_${new Date().toISOString().split('T')[0]}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  // Filtered Questions List for Browse Tab
  const filteredList = questions.filter((q) => {
    if (selectedSubject !== 'all' && q.subjectId !== selectedSubject) return false;
    if (selectedDifficulty !== 'all' && q.difficulty !== selectedDifficulty) return false;
    if (selectedOrigin === 'original' && q.isImported) return false;
    if (selectedOrigin === 'imported' && !q.isImported) return false;
    if (selectedOrigin === 'demo' && !q.isDemo) return false;
    if (search.trim()) {
      const match =
        q.questionHindi.toLowerCase().includes(search.toLowerCase()) ||
        q.questionEnglish.toLowerCase().includes(search.toLowerCase()) ||
        q.topic.toLowerCase().includes(search.toLowerCase()) ||
        q.source.toLowerCase().includes(search.toLowerCase());
      if (!match) return false;
    }
    return true;
  });

  const content = (
    <div className={`bg-white rounded-2xl shadow-xl border border-slate-200 overflow-hidden flex flex-col ${
      isStandalonePage ? 'w-full min-h-[80vh]' : 'w-full max-w-4xl max-h-[92vh] my-auto'
    }`}>
      {/* Header */}
      <div className="bg-slate-900 text-white p-3 sm:p-5 flex items-center justify-between shrink-0 gap-2">
        <div className="flex items-center gap-2 sm:gap-2.5 min-w-0">
          <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-red-700 flex items-center justify-center text-white shadow-sm shrink-0">
            <ShieldCheck className="w-5 h-5 sm:w-6 sm:h-6 text-amber-300" />
          </div>
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-1.5 sm:gap-2">
              <h2 className="text-sm sm:text-lg font-bold truncate">
                {language === 'hi' ? 'बीपीएससी परीक्षा नियंत्रक' : 'BPSC Assessment Controller'}
              </h2>
              <span className="hidden min-[380px]:inline px-2 py-0.5 rounded-full bg-red-900 text-red-200 text-[9px] sm:text-[10px] font-extrabold uppercase tracking-wider border border-red-700 shrink-0">
                ADMIN
              </span>
            </div>
            <p className="text-[10px] sm:text-xs text-slate-300 mt-0.5 truncate">
              {currentUser?.email || 'admin@bpsc.exam'} • {language === 'hi' ? 'सर्वर प्रमाणीकरण' : 'Server Auth Active'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              logout();
              if (onClose) onClose();
            }}
            className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
            title="Admin Logout"
          >
            <LogOut className="w-3.5 h-3.5 text-red-300" />
            <span className="hidden sm:inline">{language === 'hi' ? 'लॉगआउट' : 'Logout'}</span>
          </button>

          {onClose && (
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
              title="Close"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>
      </div>

      {/* Sub-Navigation Tabs */}
      <div className="bg-slate-100 border-b border-slate-200 px-2 sm:px-6 pt-2 flex items-center justify-between gap-2 overflow-x-auto shrink-0 scrollbar-none">
        <div className="flex items-center gap-1 sm:gap-2 min-w-max pb-1.5">
          {/* TAB: Overview & Students */}
          <button
            onClick={() => setActiveAdminTab('overview')}
            className={`px-3 sm:px-3.5 py-2 font-bold text-xs sm:text-sm rounded-t-xl transition-all border-b-2 flex items-center gap-1.5 cursor-pointer min-h-[40px] ${
              activeAdminTab === 'overview'
                ? 'bg-white text-red-700 border-red-700 shadow-2xs'
                : 'text-slate-600 hover:text-slate-900 border-transparent hover:bg-slate-200/60'
            }`}
          >
            <BarChart3 className="w-4 h-4 text-red-700" />
            <span>{language === 'hi' ? 'डैशबोर्ड व छात्र' : 'Overview & Students'}</span>
          </button>

          {/* TAB: Browse Questions */}
          <button
            onClick={() => setActiveAdminTab('browse')}
            className={`px-3 sm:px-3.5 py-2 font-bold text-xs sm:text-sm rounded-t-xl transition-all border-b-2 flex items-center gap-1.5 cursor-pointer ${
              activeAdminTab === 'browse'
                ? 'bg-white text-red-700 border-red-700 shadow-2xs'
                : 'text-slate-600 hover:text-slate-900 border-transparent hover:bg-slate-200/60'
            }`}
          >
            <Search className="w-4 h-4" />
            <span>{language === 'hi' ? 'प्रश्न बैंक' : 'Questions'}</span>
            <span className="ml-1 px-1.5 py-0.2 rounded-full bg-slate-200 text-slate-700 text-[10px]">
              {questions.length}
            </span>
          </button>

          {/* TAB: Bulk Import (CSV / JSON) */}
          <button
            onClick={() => setActiveAdminTab('import')}
            className={`px-3 sm:px-3.5 py-2 font-bold text-xs sm:text-sm rounded-t-xl transition-all border-b-2 flex items-center gap-1.5 cursor-pointer ${
              activeAdminTab === 'import'
                ? 'bg-white text-red-700 border-red-700 shadow-2xs'
                : 'text-slate-600 hover:text-slate-900 border-transparent hover:bg-slate-200/60'
            }`}
          >
            <Upload className="w-4 h-4" />
            <span>{language === 'hi' ? 'बल्क आयात (CSV/JSON)' : 'Bulk Import'}</span>
          </button>

          {/* TAB: Mock Test Builder */}
          <button
            onClick={() => setActiveAdminTab('mock-builder')}
            className={`px-3 sm:px-3.5 py-2 font-bold text-xs sm:text-sm rounded-t-xl transition-all border-b-2 flex items-center gap-1.5 cursor-pointer ${
              activeAdminTab === 'mock-builder'
                ? 'bg-white text-red-700 border-red-700 shadow-2xs'
                : 'text-slate-600 hover:text-slate-900 border-transparent hover:bg-slate-200/60'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>{language === 'hi' ? 'मॉक टेस्ट निर्माता' : 'Mock Builder'}</span>
          </button>

          {/* TAB: Create / Edit Question */}
          <button
            onClick={handleOpenAdd}
            className={`px-3 sm:px-3.5 py-2 font-bold text-xs sm:text-sm rounded-t-xl transition-all border-b-2 flex items-center gap-1.5 cursor-pointer ${
              activeAdminTab === 'create'
                ? 'bg-white text-red-700 border-red-700 shadow-2xs'
                : 'text-slate-600 hover:text-slate-900 border-transparent hover:bg-slate-200/60'
            }`}
          >
            <Plus className="w-4 h-4" />
            <span>{editingQuestion ? (language === 'hi' ? 'संपादित करें' : 'Edit') : (language === 'hi' ? 'नया प्रश्न' : 'Create')}</span>
          </button>
        </div>

        {/* Global Export & Reset Actions */}
        <div className="flex items-center gap-2 pb-1.5 shrink-0">
          <button
            onClick={handleExportJSON}
            className="px-2.5 py-1.5 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 rounded-lg text-xs font-bold flex items-center gap-1 shadow-2xs"
            title="Download full database as JSON"
          >
            <Download className="w-3.5 h-3.5 text-slate-500" />
            <span className="hidden sm:inline">{language === 'hi' ? 'संपूर्ण बैंक निर्यात' : 'Export JSON'}</span>
          </button>

          {showResetConfirm ? (
            <div className="flex items-center gap-1.5 bg-red-50 border border-red-200 px-2 py-1 rounded-lg text-xs">
              <span className="text-red-800 font-bold">
                {language === 'hi' ? 'रीसेट करें?' : 'Reset?'}
              </span>
              <button
                type="button"
                onClick={() => {
                  resetToDefault();
                  setShowResetConfirm(false);
                }}
                className="px-2 py-0.5 bg-red-700 text-white font-bold rounded hover:bg-red-800 text-[11px]"
              >
                {language === 'hi' ? 'हाँ' : 'Yes'}
              </button>
              <button
                type="button"
                onClick={() => setShowResetConfirm(false)}
                className="px-1.5 py-0.5 text-slate-600 hover:text-slate-900 text-[11px]"
              >
                ✕
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => setShowResetConfirm(true)}
              className="text-xs font-semibold text-slate-500 hover:text-red-700 flex items-center gap-1 px-2 py-1"
              title="Reset to 200 standard BPSC sample questions"
            >
              <RotateCcw className="w-3 h-3" />
              <span className="hidden sm:inline">{t('resetToDefault')}</span>
            </button>
          )}
        </div>
      </div>

      {/* Main Tab Content */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-6">
        {/* TAB 0: ADMIN OVERVIEW & STUDENTS */}
        {activeAdminTab === 'overview' && (
          <div className="space-y-6 max-w-5xl mx-auto">
            {/* Top Header Card */}
            <div className="bg-gradient-to-r from-slate-900 via-red-950 to-slate-900 text-white rounded-2xl p-5 sm:p-6 shadow-md border border-slate-800">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div>
                  <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-red-600 text-white text-[11px] font-bold mb-2">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>{language === 'hi' ? 'प्रशासक नियंत्रण केंद्र' : 'Admin Assessment Controller'}</span>
                  </div>
                  <h3 className="text-xl sm:text-2xl font-black">
                    {language === 'hi' ? 'परीक्षा प्रणाली अवलोकन' : 'BPSC Assessment Overview'}
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-xl">
                    {language === 'hi'
                      ? 'पंजीकृत छात्रों की संख्या, टेस्ट का प्रदर्शन, प्रश्न बैंक सांख्यिकी एवं नए अभ्यास सेट का प्रबंधन करें।'
                      : 'Monitor student registrations, test attempt metrics, question bank health, and manage official mock exams.'}
                  </p>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    onClick={() => setActiveAdminTab('create')}
                    className="px-3.5 py-2 bg-red-700 hover:bg-red-800 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-sm transition-all"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>{language === 'hi' ? 'नया प्रश्न जोड़ें' : 'Add Question'}</span>
                  </button>
                  <button
                    onClick={() => setActiveAdminTab('import')}
                    className="px-3.5 py-2 bg-white/10 hover:bg-white/20 border border-white/20 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>{language === 'hi' ? 'बल्क आयात' : 'Bulk Import'}</span>
                  </button>
                  <button
                    onClick={() => setActiveAdminTab('mock-builder')}
                    className="px-3.5 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all"
                  >
                    <Layers className="w-3.5 h-3.5" />
                    <span>{language === 'hi' ? 'नया टेस्ट बनाएं' : 'Create Test'}</span>
                  </button>
                </div>
              </div>
            </div>

            {/* 5 System Metric Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
              <div className="p-3.5 rounded-xl border border-slate-200 bg-white shadow-2xs">
                <div className="flex items-center justify-between text-slate-500 mb-1.5">
                  <span className="text-xs font-bold">{language === 'hi' ? 'कुल प्रश्न बैंक' : 'Total Questions'}</span>
                  <div className="w-7 h-7 rounded-lg bg-red-50 text-red-700 flex items-center justify-center">
                    <Database className="w-3.5 h-3.5" />
                  </div>
                </div>
                <div className="text-xl sm:text-2xl font-black text-slate-900">
                  {questions.length}
                </div>
                <div className="text-[10px] font-semibold text-emerald-700 mt-1 flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" />
                  <span>5-विकल्प (A-E) मानक</span>
                </div>
              </div>

              <div className="p-3.5 rounded-xl border border-indigo-200 bg-indigo-50/40 shadow-2xs">
                <div className="flex items-center justify-between text-slate-500 mb-1.5">
                  <span className="text-xs font-bold text-indigo-950">{language === 'hi' ? 'नए आयातित प्रश्न' : 'Imported Questions'}</span>
                  <div className="w-7 h-7 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center">
                    <Upload className="w-3.5 h-3.5" />
                  </div>
                </div>
                <div className="text-xl sm:text-2xl font-black text-indigo-700">
                  {questions.filter((q) => q.isImported).length}
                </div>
                <div className="text-[10px] font-semibold text-indigo-600 mt-1">
                  {language === 'hi' ? 'सफलतापूर्वक सहेजे गए' : 'Saved in DB'}
                </div>
              </div>

              <div className="p-3.5 rounded-xl border border-amber-200 bg-amber-50/40 shadow-2xs">
                <div className="flex items-center justify-between text-slate-500 mb-1.5">
                  <span className="text-xs font-bold text-amber-950">{language === 'hi' ? 'डेमो / टेस्ट प्रश्न' : 'Demo / Test Qs'}</span>
                  <div className="w-7 h-7 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center">
                    <Sparkles className="w-3.5 h-3.5" />
                  </div>
                </div>
                <div className="text-xl sm:text-2xl font-black text-amber-700">
                  {questions.filter((q) => q.isDemo).length}
                </div>
                <div className="text-[10px] font-semibold text-amber-800 mt-1">
                  <span>[डेमो/परीक्षण] चिह्नित</span>
                </div>
              </div>

              <div className="p-3.5 rounded-xl border border-slate-200 bg-white shadow-2xs">
                <div className="flex items-center justify-between text-slate-500 mb-1.5">
                  <span className="text-xs font-bold">{language === 'hi' ? 'पंजीकृत छात्र' : 'Registered Students'}</span>
                  <div className="w-7 h-7 rounded-lg bg-blue-50 text-blue-700 flex items-center justify-center">
                    <Users className="w-3.5 h-3.5" />
                  </div>
                </div>
                <div className="text-xl sm:text-2xl font-black text-slate-900">
                  {adminStats?.totalStudents ?? studentsList.length ?? 0}
                </div>
                <div className="text-[10px] font-semibold text-blue-700 mt-1 flex items-center gap-1">
                  <span>सत्यापित खाते</span>
                </div>
              </div>

              <div className="p-3.5 rounded-xl border border-slate-200 bg-white shadow-2xs col-span-2 sm:col-span-1">
                <div className="flex items-center justify-between text-slate-500 mb-1.5">
                  <span className="text-xs font-bold">{language === 'hi' ? 'मॉक टेस्ट सेट' : 'Mock Tests'}</span>
                  <div className="w-7 h-7 rounded-lg bg-purple-50 text-purple-700 flex items-center justify-center">
                    <Layers className="w-3.5 h-3.5" />
                  </div>
                </div>
                <div className="text-xl sm:text-2xl font-black text-slate-900">
                  {mockTestsList.length}
                </div>
                <div className="text-[10px] font-semibold text-purple-700 mt-1">
                  <span>सक्रिय टेस्ट</span>
                </div>
              </div>
            </div>

            {/* Data Storage & Persistence Information Banner */}
            <div className="bg-slate-900 text-white rounded-2xl p-4 sm:p-5 border border-slate-800 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <Database className="w-4 h-4 text-emerald-400 shrink-0" />
                  <h4 className="font-extrabold text-sm sm:text-base text-white">
                    {language === 'hi' ? 'डेटा संग्रहण एवं सुरक्षा स्थिति (Data Persistence Status)' : 'Data Persistence Architecture'}
                  </h4>
                  <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold">
                    SURVIVES REFRESH
                  </span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed max-w-2xl">
                  {language === 'hi'
                    ? 'सभी प्रश्न सर्वर फ़ाइल (/data/questions.json) में स्थायी रूप से सहेजे जाते हैं तथा ब्राउज़र के स्थानीय कैश (localStorage: bpsc_question_bank_v2) में भी सुरक्षित रहते हैं। पेज Refresh या Server Reboot करने पर भी कोई प्रश्न नहीं मिटता।'
                    : 'Questions persist server-side in /data/questions.json and client-side in localStorage (bpsc_question_bank_v2). Safe against page reloads and server restarts.'}
                </p>
              </div>

              <div className="flex items-center gap-2 text-xs font-mono shrink-0">
                <span className="px-2.5 py-1 rounded-lg bg-slate-800 border border-slate-700 text-slate-300">
                  /data/questions.json ({questions.length} Qs)
                </span>
              </div>
            </div>

            {/* Subject-wise Questions Breakdown Table */}
            <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
              <div className="p-4 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <h4 className="font-bold text-slate-900 text-sm sm:text-base flex items-center gap-2">
                    <BarChart3 className="w-4 h-4 text-red-700" />
                    <span>{language === 'hi' ? 'विषयवार प्रश्न विवरण व सांख्यिकी' : 'Subject-wise Question Bank Breakdown'}</span>
                  </h4>
                  <p className="text-xs text-slate-500">
                    {language === 'hi' ? 'प्रत्येक विषय में कुल, मूल, आयातित एवं डेमो प्रश्नों की स्थिति' : 'Total, original, imported, and demo questions count per subject'}
                  </p>
                </div>
                <span className="px-2.5 py-1 rounded-full bg-slate-100 text-slate-700 text-xs font-bold self-start sm:self-auto">
                  11 BPSC Subjects
                </span>
              </div>

              <div className="overflow-x-auto w-full">
                <table className="min-w-[560px] w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold uppercase tracking-wider text-[10px]">
                      <th className="p-3">#</th>
                      <th className="p-3">{language === 'hi' ? 'विषय का नाम' : 'Subject'}</th>
                      <th className="p-3 text-center">{language === 'hi' ? 'कुल प्रश्न' : 'Total Qs'}</th>
                      <th className="p-3 text-center">{language === 'hi' ? 'मूल प्रश्न' : 'Original'}</th>
                      <th className="p-3 text-center">{language === 'hi' ? 'नए आयातित' : 'Imported'}</th>
                      <th className="p-3 text-center">{language === 'hi' ? 'डेमो प्रश्न' : 'Demo'}</th>
                      <th className="p-3 text-right">{language === 'hi' ? 'क्रिया' : 'Action'}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {BPSC_SUBJECTS.map((subj, idx) => {
                      const subjQuestions = questions.filter((q) => q.subjectId === subj.id);
                      const totalCount = subjQuestions.length;
                      const importedCount = subjQuestions.filter((q) => q.isImported).length;
                      const demoCount = subjQuestions.filter((q) => q.isDemo).length;
                      const originalCount = totalCount - importedCount;

                      return (
                        <tr key={subj.id} className="hover:bg-slate-50/80 transition-colors">
                          <td className="p-3 text-slate-400 font-mono text-[11px]">{idx + 1}</td>
                          <td className="p-3">
                            <div className="font-bold text-slate-900">
                              {language === 'hi' ? subj.nameHindi : subj.nameEnglish}
                            </div>
                            <div className="text-[10px] text-slate-400">
                              ID: {subj.id}
                            </div>
                          </td>
                          <td className="p-3 text-center font-black text-slate-900 text-sm">
                            {totalCount}
                          </td>
                          <td className="p-3 text-center font-semibold text-slate-600">
                            {originalCount}
                          </td>
                          <td className="p-3 text-center">
                            {importedCount > 0 ? (
                              <span className="px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-800 font-bold text-[11px]">
                                +{importedCount}
                              </span>
                            ) : (
                              <span className="text-slate-400 text-[11px]">0</span>
                            )}
                          </td>
                          <td className="p-3 text-center">
                            {demoCount > 0 ? (
                              <span className="px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 font-bold text-[11px]">
                                {demoCount}
                              </span>
                            ) : (
                              <span className="text-slate-400 text-[11px]">0</span>
                            )}
                          </td>
                          <td className="p-3 text-right">
                            <button
                              onClick={() => {
                                setSelectedSubject(subj.id);
                                setActiveAdminTab('browse');
                              }}
                              className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-[11px] transition-colors cursor-pointer"
                            >
                              {language === 'hi' ? 'देखें' : 'View'}
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Students List Section */}
            <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
              <div className="p-4 border-b border-slate-200 flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-slate-900 text-sm sm:text-base flex items-center gap-2">
                    <Users className="w-4 h-4 text-blue-700" />
                    <span>{language === 'hi' ? 'पंजीकृत छात्र सूची' : 'Registered Students Directory'}</span>
                  </h4>
                  <p className="text-xs text-slate-500">
                    {language === 'hi' ? 'छात्रों की परीक्षा तैयारी व प्रदर्शन का विवरण' : 'Student details, target exam, and attempt performance'}
                  </p>
                </div>
                <span className="px-2.5 py-1 rounded-full bg-slate-100 text-slate-700 text-xs font-bold">
                  {studentsList.length} {language === 'hi' ? 'छात्र' : 'Students'}
                </span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold uppercase tracking-wider text-[10px]">
                      <th className="p-3">#</th>
                      <th className="p-3">{language === 'hi' ? 'छात्र का नाम व ईमेल' : 'Student Name & Email'}</th>
                      <th className="p-3">{language === 'hi' ? 'लक्ष्य परीक्षा' : 'Target Exam'}</th>
                      <th className="p-3 text-center">{language === 'hi' ? 'भूमिका' : 'Role'}</th>
                      <th className="p-3 text-center">{language === 'hi' ? 'दिए गए टेस्ट' : 'Tests'}</th>
                      <th className="p-3 text-center">{language === 'hi' ? 'सटीकता' : 'Accuracy'}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {studentsList.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="p-6 text-center text-slate-500 text-xs">
                          {language === 'hi' ? 'कोई छात्र डेटा नहीं मिला' : 'No registered students found'}
                        </td>
                      </tr>
                    ) : (
                      studentsList.map((st, idx) => (
                        <tr key={st.id || idx} className="hover:bg-slate-50/80 transition-colors">
                          <td className="p-3 font-semibold text-slate-400">{idx + 1}</td>
                          <td className="p-3">
                            <div className="font-bold text-slate-900 text-xs">{st.name}</div>
                            <div className="text-[11px] text-slate-500 font-mono">{st.email}</div>
                          </td>
                          <td className="p-3 text-slate-700 font-medium">{st.targetExam || '71st BPSC CCE Prelims'}</td>
                          <td className="p-3 text-center">
                            <span className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              st.role === 'admin'
                                ? 'bg-red-100 text-red-800 border border-red-200'
                                : 'bg-blue-100 text-blue-800 border border-blue-200'
                            }`}>
                              {st.role?.toUpperCase() || 'STUDENT'}
                            </span>
                          </td>
                          <td className="p-3 text-center font-bold text-slate-900">
                            {st.testsCompleted ?? 0}
                          </td>
                          <td className="p-3 text-center">
                            <span className={`font-bold ${
                              (st.accuracy ?? 0) >= 60 ? 'text-emerald-700' : 'text-slate-700'
                            }`}>
                              {st.accuracy ? `${st.accuracy}%` : '-'}
                            </span>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Recent Student Test Results */}
            {adminStats?.recentResults && adminStats.recentResults.length > 0 && (
              <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
                <div className="p-4 border-b border-slate-200 flex items-center justify-between">
                  <h4 className="font-bold text-slate-900 text-sm sm:text-base flex items-center gap-2">
                    <BarChart3 className="w-4 h-4 text-emerald-700" />
                    <span>{language === 'hi' ? 'हाल के टेस्ट परिणाम' : 'Recent Test Submissions'}</span>
                  </h4>
                  <span className="text-xs text-slate-500 font-semibold">
                    {adminStats.recentResults.length} {language === 'hi' ? 'सबमिशन' : 'Submissions'}
                  </span>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold uppercase tracking-wider text-[10px]">
                        <th className="p-3">{language === 'hi' ? 'छात्र' : 'Student'}</th>
                        <th className="p-3">{language === 'hi' ? 'टेस्ट का नाम' : 'Test Title'}</th>
                        <th className="p-3 text-center">{language === 'hi' ? 'प्राप्तांक' : 'Score'}</th>
                        <th className="p-3 text-center">{language === 'hi' ? 'प्रतिशत' : 'Percentage'}</th>
                        <th className="p-3 text-right">{language === 'hi' ? 'दिनांक' : 'Date'}</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {adminStats.recentResults.map((r, idx) => (
                        <tr key={r.id || idx} className="hover:bg-slate-50/80">
                          <td className="p-3">
                            <div className="font-bold text-slate-900">{r.studentName}</div>
                            <div className="text-[10px] text-slate-400 font-mono">{r.studentEmail}</div>
                          </td>
                          <td className="p-3 font-semibold text-slate-800">{r.testTitle}</td>
                          <td className="p-3 text-center font-bold text-slate-900">
                            {r.score} / {r.maxScore}
                          </td>
                          <td className="p-3 text-center">
                            <span className={`inline-block px-2 py-0.5 rounded text-[11px] font-bold ${
                              r.percentage >= 60 ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                            }`}>
                              {r.percentage}%
                            </span>
                          </td>
                          <td className="p-3 text-right text-slate-500 text-[11px] font-mono">
                            {r.completedAt}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        )}

        {/* TAB: MOCK TEST BUILDER */}
        {activeAdminTab === 'mock-builder' && (
          <div className="space-y-6 max-w-4xl mx-auto">
            {/* Header Card */}
            <div className="bg-gradient-to-r from-red-900 to-amber-900 text-white rounded-2xl p-5 sm:p-6 shadow-md">
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-white/20 text-white text-[11px] font-bold mb-2">
                <Layers className="w-3.5 h-3.5" />
                <span>BPSC Official Exam Architect</span>
              </div>
              <h3 className="text-xl sm:text-2xl font-black">
                {language === 'hi' ? 'मॉक टेस्ट एवं प्रैक्टिस सेट निर्माता' : 'Mock Test & Practice Set Builder'}
              </h3>
              <p className="text-xs sm:text-sm text-red-100 mt-1 max-w-xl">
                {language === 'hi'
                  ? 'BPSC 5-विकल्प पैटर्न के अनुसार नए मॉक टेस्ट तैयार करें। समय सीमा, प्रश्नों की संख्या एवं निगेटिव मार्किंग (1/3 या 1/4) सेट करें।'
                  : 'Design custom mock tests and sectional practice sets with 5-option pattern, timer, marks, and negative marking.'}
              </p>
            </div>

            {/* Success Alert */}
            {mockSuccessMsg && (
              <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>{mockSuccessMsg}</span>
              </div>
            )}

            {/* Builder Form */}
            <form onSubmit={handleCreateMockTest} className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-2xs space-y-4">
              <h4 className="font-bold text-slate-900 text-sm sm:text-base border-b border-slate-100 pb-2 flex items-center gap-2">
                <Sliders className="w-4 h-4 text-red-700" />
                <span>{language === 'hi' ? 'टेस्ट विनिर्देश कॉन्फ़िगर करें' : 'Configure Test Parameters'}</span>
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {language === 'hi' ? 'टेस्ट का नाम (अंग्रेजी)' : 'Test Title (English)'} *
                  </label>
                  <input
                    type="text"
                    required
                    value={newMockTitle}
                    onChange={(e) => setNewMockTitle(e.target.value)}
                    placeholder="e.g. 71st BPSC Prelims Full Mock 01"
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-900 focus:bg-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {language === 'hi' ? 'टेस्ट का नाम (हिन्दी)' : 'Test Title (Hindi)'}
                  </label>
                  <input
                    type="text"
                    value={newMockTitleHi}
                    onChange={(e) => setNewMockTitleHi(e.target.value)}
                    placeholder="उदा. 71वीं बीपीएससी प्रारंभिक परीक्षा संपूर्ण मॉक 01"
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-900 focus:bg-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {language === 'hi' ? 'विवरण या निर्देश' : 'Description / Instructions'}
                </label>
                <textarea
                  rows={2}
                  value={newMockDesc}
                  onChange={(e) => setNewMockDesc(e.target.value)}
                  placeholder={language === 'hi' ? 'BPSC 5-विकल्प प्रारूप, ऋणात्मक अंकन -0.33, समय 120 मिनट' : 'Standard 5 options A-E, 0.33 negative marking'}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white"
                />
              </div>

              {/* Subject Multi-select */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  {language === 'hi' ? 'शामिल विषय चुनें (कम से कम 1)' : 'Select Included Subjects'}
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
                  {BPSC_SUBJECTS.map((s) => {
                    const isChecked = newMockSubjects.includes(s.id);
                    return (
                      <button
                        type="button"
                        key={s.id}
                        onClick={() => {
                          if (isChecked) {
                            if (newMockSubjects.length > 1) {
                              setNewMockSubjects(newMockSubjects.filter((id) => id !== s.id));
                            }
                          } else {
                            setNewMockSubjects([...newMockSubjects, s.id]);
                          }
                        }}
                        className={`p-2 rounded-xl border text-xs text-left font-semibold transition-all flex items-center justify-between ${
                          isChecked
                            ? 'bg-red-50 text-red-900 border-red-300 shadow-2xs'
                            : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        <span className="truncate">{language === 'hi' ? s.nameHindi : s.nameEnglish}</span>
                        {isChecked && <CheckCircle2 className="w-3.5 h-3.5 text-red-700 shrink-0 ml-1" />}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Test Length, Timer, Negative Marking */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {language === 'hi' ? 'प्रश्नों की संख्या' : 'Question Count'}
                  </label>
                  <select
                    value={newMockQuestionCount}
                    onChange={(e) => setNewMockQuestionCount(Number(e.target.value))}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900"
                  >
                    <option value={10}>10 {language === 'hi' ? 'प्रश्न (मिनी)' : 'Questions'}</option>
                    <option value={25}>25 {language === 'hi' ? 'प्रश्न (मानक)' : 'Questions'}</option>
                    <option value={50}>50 {language === 'hi' ? 'प्रश्न (विस्तृत)' : 'Questions'}</option>
                    <option value={100}>100 {language === 'hi' ? 'प्रश्न (सेक्शनल)' : 'Questions'}</option>
                    <option value={150}>150 {language === 'hi' ? 'प्रश्न (फुल लेंथ BPSC)' : 'Questions (Full Length)'}</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {language === 'hi' ? 'समय सीमा (मिनट)' : 'Time Limit (Minutes)'}
                  </label>
                  <select
                    value={newMockTimeMinutes}
                    onChange={(e) => setNewMockTimeMinutes(Number(e.target.value))}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900"
                  >
                    <option value={15}>15 {language === 'hi' ? 'मिनट' : 'Minutes'}</option>
                    <option value={30}>30 {language === 'hi' ? 'मिनट' : 'Minutes'}</option>
                    <option value={60}>60 {language === 'hi' ? 'मिनट (1 घंटा)' : 'Minutes'}</option>
                    <option value={120}>120 {language === 'hi' ? 'मिनट (2 घंटे - BPSC मानक)' : 'Minutes (2h BPSC Standard)'}</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {language === 'hi' ? 'ऋणात्मक अंकन (Negative Marking)' : 'Negative Marking'}
                  </label>
                  <select
                    value={newMockNegative}
                    onChange={(e) => setNewMockNegative(Number(e.target.value))}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900"
                  >
                    <option value={0.33}>-0.33 ({language === 'hi' ? '1/3 अंक - नया BPSC नियम' : '1/3rd Mark'})</option>
                    <option value={0.25}>-0.25 ({language === 'hi' ? '1/4 अंक - पारम्परिक' : '1/4th Mark'})</option>
                    <option value={0}>0.00 ({language === 'hi' ? 'कोई ऋणात्मक अंकन नहीं' : 'No Negative'})</option>
                  </select>
                </div>
              </div>

              {/* Full Length Checkbox */}
              <div className="flex items-center gap-2 pt-2">
                <input
                  type="checkbox"
                  id="isFullLengthCheck"
                  checked={newMockFullLength}
                  onChange={(e) => {
                    setNewMockFullLength(e.target.checked);
                    if (e.target.checked) {
                      setNewMockQuestionCount(150);
                      setNewMockTimeMinutes(120);
                      setNewMockNegative(0.33);
                      setNewMockSubjects(BPSC_SUBJECTS.map((s) => s.id));
                    }
                  }}
                  className="w-4 h-4 text-red-700 rounded border-slate-300"
                />
                <label htmlFor="isFullLengthCheck" className="text-xs font-bold text-slate-800 cursor-pointer">
                  {language === 'hi' ? 'यह आधिकारिक 150 प्रश्नों का सम्पूर्ण BPSC मॉक टेस्ट है' : 'Full-Length 150-Question Official BPSC Prelims Mock Exam'}
                </label>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full sm:w-auto px-6 py-2.5 bg-red-700 hover:bg-red-800 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-sm transition-all"
                >
                  <Plus className="w-4 h-4" />
                  <span>{language === 'hi' ? 'मॉक टेस्ट सहेजें व प्रकाशित करें' : 'Save & Publish Mock Test'}</span>
                </button>
              </div>
            </form>

            {/* Current Active Mock Tests List */}
            <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-2xs space-y-3">
              <h4 className="font-bold text-slate-900 text-sm sm:text-base flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Layers className="w-4 h-4 text-amber-700" />
                  <span>{language === 'hi' ? 'वर्तमान में सक्रिय मॉक टेस्ट' : 'Active Mock Tests'}</span>
                </div>
                <span className="text-xs text-slate-500 font-bold">{mockTestsList.length} टेस्ट</span>
              </h4>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
                {mockTestsList.map((m) => (
                  <div key={m.id} className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 hover:border-slate-300 flex flex-col justify-between gap-3">
                    <div>
                      <div className="flex items-start justify-between gap-2">
                        <h5 className="font-bold text-slate-900 text-xs sm:text-sm">
                          {language === 'hi' ? m.titleHindi || m.title : m.title}
                        </h5>
                        <button
                          type="button"
                          onClick={() => handleDeleteMockTest(m.id)}
                          className="p-1 text-slate-400 hover:text-red-700 rounded"
                          title="Delete Mock Test"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                      <p className="text-[11px] text-slate-500 line-clamp-1 mt-0.5">
                        {m.description || '5-option official practice set'}
                      </p>
                    </div>

                    <div className="flex flex-wrap items-center gap-2 text-[10px] font-bold">
                      <span className="px-2 py-0.5 rounded bg-blue-100 text-blue-800">
                        {m.questionCount} {language === 'hi' ? 'प्रश्न' : 'Qns'}
                      </span>
                      <span className="px-2 py-0.5 rounded bg-amber-100 text-amber-800">
                        {m.timeLimitMinutes} {language === 'hi' ? 'मिनट' : 'mins'}
                      </span>
                      <span className="px-2 py-0.5 rounded bg-red-100 text-red-800">
                        -{m.negativeMarking} {language === 'hi' ? 'नेगेटिव' : 'neg'}
                      </span>
                      {m.isFullLength && (
                        <span className="px-2 py-0.5 rounded bg-purple-100 text-purple-800">
                          Full Length
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 1: BULK IMPORT (CSV & JSON) */}
        {activeAdminTab === 'import' && (
          <div className="space-y-6 max-w-4xl mx-auto">
            {/* Top Overview & Action Card */}
            <div className="bg-gradient-to-br from-slate-900 to-red-950 text-white rounded-2xl p-5 sm:p-6 shadow-md border border-slate-800">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div>
                  <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-red-600 text-white text-[11px] font-bold mb-2">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>BPSC 5-Option Bulk Engine</span>
                  </div>
                  <h3 className="text-lg sm:text-xl font-black">
                    {language === 'hi' ? 'थोक प्रश्न आयात (CSV व JSON)' : 'Bulk Question Import (CSV & JSON)'}
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-xl">
                    {language === 'hi'
                      ? 'CSV या JSON फाइल अपलोड करें। आयात से पूर्व सभी प्रश्नों का पूर्वावलोकन, 5-विकल्प सत्यापन (A-E) एवं डुप्लिकेट जांच की जाती है।'
                      : 'Upload CSV or JSON. Previews all questions with strict 5-option validation (A-E) and duplicate detection before saving.'}
                  </p>
                </div>

                <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 w-full sm:w-auto shrink-0">
                  <button
                    onClick={handleLoadSamplePreview}
                    disabled={isProcessingImport}
                    className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-md shadow-emerald-700/30 transition-all cursor-pointer"
                    title="Load 3 authentic sample questions directly into preview"
                  >
                    <Eye className="w-4 h-4" />
                    <span>{language === 'hi' ? '5 नमूना प्रश्न पूर्वावलोकन (डेमो/परीक्षण)' : 'Preview 5 Demo Questions'}</span>
                  </button>
                </div>
              </div>
            </div>

            {/* PREVIEW VIEW: Displayed when previewData is present */}
            {previewData ? (
              <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm animate-in fade-in duration-200 space-y-4 p-5 sm:p-6">
                {/* Preview Header */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-200">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded-md bg-red-100 text-red-800 text-[11px] font-black uppercase">
                        {previewData.fileType.toUpperCase()}
                      </span>
                      <h4 className="font-extrabold text-base sm:text-lg text-slate-900">
                        {language === 'hi' ? 'आयात पूर्वावलोकन एवं सत्यापन' : 'Import Preview & Validation'}
                      </h4>
                    </div>
                    <p className="text-xs text-slate-500 mt-0.5">
                      {language === 'hi' ? 'फाइल का नाम:' : 'File:'} <span className="font-mono font-bold text-slate-700">{previewData.filename}</span>
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setPreviewData(null)}
                      className="px-3 py-1.5 rounded-xl border border-slate-300 text-slate-700 text-xs font-bold hover:bg-slate-100 transition-colors"
                    >
                      {language === 'hi' ? 'रद्द करें / नई फाइल' : 'Cancel / New File'}
                    </button>
                  </div>
                </div>

                {/* 4 Summary Stat Chips */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 sm:gap-3 text-center">
                  <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                    <span className="text-[11px] font-semibold text-slate-500 block">{language === 'hi' ? 'कुल पंक्तियां' : 'Total Rows'}</span>
                    <span className="text-xl font-black text-slate-900">{previewData.totalParsed}</span>
                  </div>

                  <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200">
                    <span className="text-[11px] font-semibold text-emerald-700 block">{language === 'hi' ? 'नए मान्य प्रश्न' : 'Valid New'}</span>
                    <span className="text-xl font-black text-emerald-700">✓ {previewData.validCount}</span>
                  </div>

                  <div className="p-3 rounded-xl bg-amber-50 border border-amber-200">
                    <span className="text-[11px] font-semibold text-amber-700 block">{language === 'hi' ? 'डुप्लिकेट प्रश्न' : 'Duplicates'}</span>
                    <span className="text-xl font-black text-amber-700">⚠ {previewData.duplicateCount}</span>
                  </div>

                  <div className="p-3 rounded-xl bg-red-50 border border-red-200">
                    <span className="text-[11px] font-semibold text-red-700 block">{language === 'hi' ? 'अमान्य / त्रुटियां' : 'Errors'}</span>
                    <span className={`text-xl font-black ${previewData.errorCount > 0 ? 'text-red-700' : 'text-slate-400'}`}>
                      ✕ {previewData.errorCount}
                    </span>
                  </div>
                </div>

                {/* Import Preference & Action Buttons Bar */}
                <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                  <label className="flex items-center gap-2 cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={skipDuplicates}
                      onChange={(e) => setSkipDuplicates(e.target.checked)}
                      className="w-4 h-4 rounded text-red-700 focus:ring-red-600"
                    />
                    <div>
                      <span className="text-xs font-bold text-slate-800">
                        {language === 'hi' ? 'डुप्लिकेट प्रश्न छोड़ें (Skip Duplicates)' : 'Skip Duplicate Questions'}
                      </span>
                      <p className="text-[11px] text-slate-500">
                        {skipDuplicates
                          ? (language === 'hi' 
                              ? `केवल ${previewData.validCount} नए अद्वितीय प्रश्न आयात किए जाएंगे।` 
                              : `Only ${previewData.validCount} unique new questions will be imported.`)
                          : (language === 'hi' 
                              ? `सभी ${previewData.validCount + previewData.duplicateCount} मान्य प्रश्न (डुप्लिकेट सहित) आयात किए जाएंगे।` 
                              : `All ${previewData.validCount + previewData.duplicateCount} questions including duplicates will be imported.`)}
                      </p>
                    </div>
                  </label>

                  <button
                    onClick={handleConfirmImport}
                    disabled={isProcessingImport || (skipDuplicates ? previewData.validCount === 0 : (previewData.validCount + previewData.duplicateCount) === 0)}
                    className="w-full sm:w-auto px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-300 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-sm transition-all cursor-pointer"
                  >
                    <Check className="w-4 h-4" />
                    <span>
                      {language === 'hi'
                        ? `आयात की पुष्टि करें (${skipDuplicates ? previewData.validCount : previewData.validCount + previewData.duplicateCount} प्रश्न)`
                        : `Confirm & Import (${skipDuplicates ? previewData.validCount : previewData.validCount + previewData.duplicateCount} Questions)`}
                    </span>
                  </button>
                </div>

                {/* Filter Sub-Tabs for Preview Items */}
                <div className="flex items-center gap-1.5 pt-2 border-b border-slate-200 pb-2 overflow-x-auto text-xs">
                  <span className="text-slate-500 font-semibold flex items-center gap-1 pr-1">
                    <Filter className="w-3.5 h-3.5" />
                    <span>{language === 'hi' ? 'दिखाएं:' : 'Show:'}</span>
                  </span>

                  <button
                    onClick={() => setPreviewFilter('all')}
                    className={`px-3 py-1 rounded-lg font-bold transition-colors ${
                      previewFilter === 'all'
                        ? 'bg-slate-900 text-white'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {language === 'hi' ? 'सभी' : 'All'} ({previewData.totalParsed})
                  </button>

                  <button
                    onClick={() => setPreviewFilter('valid')}
                    className={`px-3 py-1 rounded-lg font-bold transition-colors ${
                      previewFilter === 'valid'
                        ? 'bg-emerald-700 text-white'
                        : 'bg-emerald-50 text-emerald-800 hover:bg-emerald-100'
                    }`}
                  >
                    {language === 'hi' ? 'केवल नए' : 'Valid'} ({previewData.validCount})
                  </button>

                  <button
                    onClick={() => setPreviewFilter('duplicates')}
                    className={`px-3 py-1 rounded-lg font-bold transition-colors ${
                      previewFilter === 'duplicates'
                        ? 'bg-amber-700 text-white'
                        : 'bg-amber-50 text-amber-800 hover:bg-amber-100'
                    }`}
                  >
                    {language === 'hi' ? 'डुप्लिकेट' : 'Duplicates'} ({previewData.duplicateCount})
                  </button>

                  <button
                    onClick={() => setPreviewFilter('errors')}
                    className={`px-3 py-1 rounded-lg font-bold transition-colors ${
                      previewFilter === 'errors'
                        ? 'bg-red-700 text-white'
                        : 'bg-red-50 text-red-800 hover:bg-red-100'
                    }`}
                  >
                    {language === 'hi' ? 'त्रुटियां' : 'Errors'} ({previewData.errorCount})
                  </button>
                </div>

                {/* Preview Items List */}
                <div className="space-y-3.5 max-h-[500px] overflow-y-auto pr-1">
                  {previewData.items
                    .filter((item) => {
                      if (previewFilter === 'valid') return item.isValid && !item.isDuplicate;
                      if (previewFilter === 'duplicates') return item.isDuplicate;
                      if (previewFilter === 'errors') return !item.isValid;
                      return true;
                    })
                    .map((item, idx) => {
                      const q = item.question;
                      return (
                        <div
                          key={idx}
                          className={`p-4 rounded-xl border transition-all ${
                            !item.isValid
                              ? 'bg-red-50/60 border-red-200'
                              : item.isDuplicate
                              ? 'bg-amber-50/60 border-amber-200'
                              : 'bg-white border-slate-200 shadow-2xs'
                          }`}
                        >
                          {/* Row Header & Badges */}
                          <div className="flex flex-wrap items-center justify-between gap-2 mb-2 pb-2 border-b border-slate-100">
                            <div className="flex items-center gap-2">
                              <span className="w-6 h-6 rounded-lg bg-slate-800 text-white text-xs font-bold flex items-center justify-center">
                                #{item.rowNumber}
                              </span>
                              {q && (
                                <>
                                  <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 text-[10px] font-bold">
                                    {q.subjectId}
                                  </span>
                                  <span className="text-xs text-slate-500 font-medium truncate max-w-[150px] sm:max-w-xs">
                                    {q.topic}
                                  </span>
                                </>
                              )}
                            </div>

                            {/* Status Badge */}
                            <div>
                              {!item.isValid ? (
                                <span className="px-2 py-0.5 rounded-full bg-red-100 text-red-800 font-black text-[10px] flex items-center gap-1">
                                  <AlertTriangle className="w-3 h-3" />
                                  <span>{language === 'hi' ? 'अमान्य (Validation Error)' : 'Invalid Question'}</span>
                                </span>
                              ) : item.isDuplicate ? (
                                <span className="px-2 py-0.5 rounded-full bg-amber-100 text-amber-900 font-black text-[10px] flex items-center gap-1">
                                  <AlertTriangle className="w-3 h-3 text-amber-700" />
                                  <span>{language === 'hi' ? 'डुप्लिकेट (Duplicate Detected)' : 'Duplicate Question'}</span>
                                </span>
                              ) : (
                                <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-black text-[10px] flex items-center gap-1">
                                  <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                                  <span>{language === 'hi' ? 'मान्य (Valid BPSC Format)' : 'Valid 5-Option Format'}</span>
                                </span>
                              )}
                            </div>
                          </div>

                          {/* Duplicate or Error Notice Banner */}
                          {item.isDuplicate && (
                            <div className="mb-2 p-2 rounded-lg bg-amber-100/70 border border-amber-300 text-amber-900 text-[11px] flex items-center gap-1.5">
                              <AlertTriangle className="w-3.5 h-3.5 text-amber-700 shrink-0" />
                              <span>{item.duplicateReason || 'यह प्रश्न पहले से बैंक में मौजूद है'}</span>
                            </div>
                          )}

                          {!item.isValid && (
                            <div className="mb-2 p-2.5 rounded-lg bg-red-100/70 border border-red-300 text-red-900 text-xs">
                              <span className="font-bold block mb-1">
                                {language === 'hi' ? 'सत्यापन विफलता कारण:' : 'Validation Error Details:'}
                              </span>
                              <ul className="list-disc list-inside space-y-0.5 text-[11px]">
                                {item.errors.map((e, eIdx) => (
                                  <li key={eIdx}>{e}</li>
                                ))}
                              </ul>
                            </div>
                          )}

                          {/* Question Text */}
                          <div className="mb-2.5">
                            <h5 className="font-bold text-xs sm:text-sm text-slate-900 leading-snug">
                              {q ? q.questionHindi : item.rawTitle}
                            </h5>
                            {q?.questionEnglish && q.questionEnglish !== q.questionHindi && (
                              <p className="text-xs text-slate-500 mt-0.5 italic">
                                {q.questionEnglish}
                              </p>
                            )}
                          </div>

                          {/* 5 Options Display */}
                          {q && (
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 mb-2.5">
                              {q.optionsHindi.map((opt, optIdx) => {
                                const optKey = (['A', 'B', 'C', 'D', 'E'][optIdx]) as OptionKey;
                                const isCorrect = q.correctAnswer === optKey;
                                return (
                                  <div
                                    key={optKey}
                                    className={`p-2 rounded-lg text-xs flex items-start gap-2 border ${
                                      isCorrect
                                        ? 'bg-emerald-50 border-emerald-300 text-emerald-950 font-semibold'
                                        : 'bg-slate-50 border-slate-200 text-slate-700'
                                    }`}
                                  >
                                    <span
                                      className={`w-5 h-5 rounded font-black text-[10px] flex items-center justify-center shrink-0 mt-0.5 ${
                                        isCorrect
                                          ? 'bg-emerald-600 text-white'
                                          : 'bg-slate-200 text-slate-700'
                                      }`}
                                    >
                                      {optKey}
                                    </span>
                                    <span className="break-words flex-1 leading-snug">{opt}</span>
                                    {isCorrect && (
                                      <span className="text-[10px] text-emerald-700 font-black shrink-0 mt-0.5">
                                        ✓ {language === 'hi' ? 'सही उत्तर' : 'Correct'}
                                      </span>
                                    )}
                                  </div>
                                );
                              })}
                            </div>
                          )}

                          {/* Explanation */}
                          {q && q.explanationHindi && (
                            <div className="p-2 rounded-lg bg-slate-50 border border-slate-200 text-[11px] text-slate-600">
                              <span className="font-bold text-slate-800">
                                {language === 'hi' ? 'व्याख्या:' : 'Explanation:'}{' '}
                              </span>
                              {q.explanationHindi}
                            </div>
                          )}
                        </div>
                      );
                    })}
                </div>
              </div>
            ) : (
              <>
                {/* Upload Zone & Downloadable Templates (Default State) */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* File Upload Box */}
                  <div className="border-2 border-dashed border-red-300 hover:border-red-500 bg-red-50/40 rounded-2xl p-6 flex flex-col items-center justify-center text-center transition-colors">
                    <div className="w-12 h-12 rounded-2xl bg-red-100 text-red-700 flex items-center justify-center mb-3 shadow-2xs">
                      <Upload className="w-6 h-6" />
                    </div>
                    <h4 className="font-bold text-sm text-slate-900 mb-1">
                      {language === 'hi' ? 'CSV या JSON फाइल चुनें' : 'Select CSV or JSON File'}
                    </h4>
                    <p className="text-xs text-slate-500 mb-4 max-w-xs">
                      {language === 'hi'
                        ? 'फाइल अपलोड करने पर पहले पूर्वावलोकन व डुप्लिकेट जांच दिखाई जाएगी'
                        : 'Uploading file immediately opens preview with duplicate detection'}
                    </p>

                    <label className="px-5 py-2.5 bg-red-700 hover:bg-red-800 text-white rounded-xl text-xs font-bold flex items-center gap-2 cursor-pointer shadow-sm active:scale-98 transition-transform">
                      <Upload className="w-4 h-4" />
                      <span>{isProcessingImport ? (language === 'hi' ? 'प्रक्रिया जारी...' : 'Processing...') : (language === 'hi' ? 'फाइल चुनें एवं पूर्वावलोकन करें' : 'Choose File to Preview')}</span>
                      <input
                        type="file"
                        accept=".csv, .json, text/csv, application/json"
                        onChange={handleFileUpload}
                        disabled={isProcessingImport}
                        className="hidden"
                      />
                    </label>
                  </div>

                  {/* Downloadable Templates Card */}
                  <div className="bg-slate-50 border border-slate-200 rounded-2xl p-5 flex flex-col justify-between">
                    <div>
                      <h4 className="font-bold text-sm text-slate-900 flex items-center gap-1.5 mb-1.5">
                        <Download className="w-4 h-4 text-slate-700" />
                        <span>{language === 'hi' ? 'डाउनलोड करने योग्य नमूना टेम्पलेट्स' : 'Downloadable Sample Templates'}</span>
                      </h4>
                      <p className="text-xs text-slate-600 mb-4">
                        {language === 'hi'
                          ? 'तैयार टेम्पलेट डाउनलोड करें, अपने प्रश्न भरें और सीधे अपलोड करें:'
                          : 'Download ready-to-use sample templates with 5 options, correct answer and explanations:'}
                      </p>

                      <div className="space-y-2.5">
                        <button
                          onClick={handleDownloadSampleCSV}
                          className="w-full py-2.5 px-3 bg-white hover:bg-slate-100 border border-slate-200 text-slate-800 rounded-xl text-xs font-bold flex items-center justify-between shadow-2xs transition-colors cursor-pointer"
                        >
                          <div className="flex items-center gap-2">
                            <FileText className="w-4 h-4 text-emerald-600" />
                            <span>{language === 'hi' ? 'नमूना CSV टेम्पलेट (Sample CSV)' : 'Download Sample CSV'}</span>
                          </div>
                          <span className="text-[11px] font-semibold text-emerald-700">.csv ↓</span>
                        </button>

                        <button
                          onClick={handleDownloadSampleJSON}
                          className="w-full py-2.5 px-3 bg-white hover:bg-slate-100 border border-slate-200 text-slate-800 rounded-xl text-xs font-bold flex items-center justify-between shadow-2xs transition-colors cursor-pointer"
                        >
                          <div className="flex items-center gap-2">
                            <FileCode className="w-4 h-4 text-blue-600" />
                            <span>{language === 'hi' ? 'नमूना JSON टेम्पलेट (Sample JSON)' : 'Download Sample JSON'}</span>
                          </div>
                          <span className="text-[11px] font-semibold text-blue-700">.json ↓</span>
                        </button>
                      </div>
                    </div>

                    <div className="text-[11px] text-slate-500 mt-4 pt-3 border-t border-slate-200 flex items-center gap-1">
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                      <span>{language === 'hi' ? 'दोनों टेम्पलेट्स 5-विकल्प BPSC मानक के अनुरूप हैं।' : 'Both templates adhere strictly to the 5-option BPSC format.'}</span>
                    </div>
                  </div>
                </div>

                {/* Validation Rules Checklist Card */}
                <div className="bg-white border border-slate-200 rounded-2xl p-5">
                  <h4 className="font-bold text-xs uppercase tracking-wider text-slate-700 mb-3 flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4 text-red-700" />
                    <span>{language === 'hi' ? 'अनिवार्य सत्यापन नियम (Strict Validation Rules)' : 'Strict Validation Checklist'}</span>
                  </h4>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                    <div className="flex items-start gap-2 p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                      <div>
                        <span className="font-bold text-slate-900">{language === 'hi' ? 'ठीक 5 विकल्प (A, B, C, D, E):' : 'Exactly 5 Options (A-E):'}</span>
                        <p className="text-slate-500 text-[11px] mt-0.5">
                          {language === 'hi' ? 'प्रत्येक प्रश्न में 5 विकल्प अनिवार्य हैं। विकल्प रिक्त नहीं हो सकता।' : 'Each question must have all 5 options non-empty.'}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start gap-2 p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                      <div>
                        <span className="font-bold text-slate-900">{language === 'hi' ? 'मान्य सही उत्तर (A, B, C, D, E):' : 'Valid Correct Option:'}</span>
                        <p className="text-slate-500 text-[11px] mt-0.5">
                          {language === 'hi' ? 'उत्तर केवल A, B, C, D या E में से एक होना चाहिए।' : 'Answer must strictly be one of A, B, C, D, or E.'}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start gap-2 p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                      <div>
                        <span className="font-bold text-slate-900">{language === 'hi' ? 'हिन्दी प्रश्न (questionHindi):' : 'Hindi Question Text:'}</span>
                        <p className="text-slate-500 text-[11px] mt-0.5">
                          {language === 'hi' ? 'स्पष्ट देवनागरी हिन्दी प्रश्न पाठ अनिवार्य है।' : 'Hindi question text is mandatory.'}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start gap-2 p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                      <div>
                        <span className="font-bold text-slate-900">{language === 'hi' ? 'हिन्दी विस्तृत व्याख्या (explanationHindi):' : 'Hindi Explanation:'}</span>
                        <p className="text-slate-500 text-[11px] mt-0.5">
                          {language === 'hi' ? 'विद्यार्थी के सीखने हेतु प्रामाणिक व्याख्या आवश्यक है।' : 'Clear factual explanation in Hindi is required.'}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </>
            )}

            {/* LIVE IMPORT REPORT (Success / Error Report) */}
            {importReport && !previewData && (
              <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm animate-in fade-in duration-200">
                <div className={`p-4 sm:p-5 flex items-center justify-between border-b ${
                  importReport.failureCount === 0
                    ? 'bg-emerald-50/80 border-emerald-200 text-emerald-950'
                    : importReport.successfulCount > 0
                    ? 'bg-amber-50/80 border-amber-200 text-amber-950'
                    : 'bg-red-50/80 border-red-200 text-red-950'
                }`}>
                  <div className="flex items-center gap-2.5">
                    {importReport.failureCount === 0 ? (
                      <CheckCircle2 className="w-6 h-6 text-emerald-600 shrink-0" />
                    ) : importReport.successfulCount > 0 ? (
                      <AlertTriangle className="w-6 h-6 text-amber-600 shrink-0" />
                    ) : (
                      <AlertTriangle className="w-6 h-6 text-red-600 shrink-0" />
                    )}
                    <div>
                      <h4 className="font-bold text-sm sm:text-base">
                        {language === 'hi' ? 'आयात परिणाम रिपोर्ट (Import Result Report)' : 'Bulk Import Report'}
                      </h4>
                      <p className="text-xs opacity-80 mt-0.5">
                        {language === 'hi' ? 'फाइल:' : 'File:'} <span className="font-mono font-bold">{importReport.filename}</span> ({importReport.fileType.toUpperCase()})
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() => setImportReport(null)}
                    className="text-xs font-bold px-2.5 py-1 rounded-lg bg-white/60 hover:bg-white text-slate-700 border border-slate-200 transition-colors"
                  >
                    {language === 'hi' ? 'बंद करें' : 'Dismiss'}
                  </button>
                </div>

                {/* Score Stats Bar */}
                <div className="grid grid-cols-4 divide-x divide-slate-100 bg-slate-50/60 p-3 text-center border-b border-slate-100 text-xs">
                  <div>
                    <span className="text-slate-500 font-semibold">{language === 'hi' ? 'कुल प्रोसेस' : 'Total'}</span>
                    <div className="text-base font-black text-slate-900">{importReport.totalProcessed}</div>
                  </div>
                  <div>
                    <span className="text-emerald-700 font-semibold">{language === 'hi' ? 'सफल आयात' : 'Imported'}</span>
                    <div className="text-base font-black text-emerald-600">✓ {importReport.successfulCount}</div>
                  </div>
                  <div>
                    <span className="text-amber-700 font-semibold">{language === 'hi' ? 'डुप्लिकेट छोड़े' : 'Skipped'}</span>
                    <div className="text-base font-black text-amber-600">{importReport.duplicatesSkippedCount}</div>
                  </div>
                  <div>
                    <span className="text-red-700 font-semibold">{language === 'hi' ? 'अस्वीकृत' : 'Failed'}</span>
                    <div className={`text-base font-black ${importReport.failureCount > 0 ? 'text-red-600' : 'text-slate-400'}`}>
                      {importReport.failureCount}
                    </div>
                  </div>
                </div>

                <div className="p-4 sm:p-5 space-y-4">
                  {/* Successfully Imported Questions List */}
                  {importReport.importedQuestions.length > 0 && (
                    <div>
                      <h5 className="font-bold text-xs uppercase tracking-wider text-emerald-800 mb-2 flex items-center gap-1.5">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                        <span>{language === 'hi' ? `सफलतापूर्वक जोड़े गए प्रश्न (${importReport.importedQuestions.length})` : `Successfully Imported Questions (${importReport.importedQuestions.length})`}</span>
                      </h5>
                      <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                        {importReport.importedQuestions.map((q, idx) => (
                          <div key={q.id || idx} className="p-2.5 rounded-xl bg-emerald-50/50 border border-emerald-100 text-xs flex items-center justify-between gap-2">
                            <div className="flex items-center gap-2 flex-1 truncate">
                              <span className="w-5 h-5 rounded-full bg-emerald-600 text-white font-bold text-[10px] flex items-center justify-center shrink-0">
                                {idx + 1}
                              </span>
                              <span className="font-semibold text-slate-900 truncate">
                                {q.questionHindi}
                              </span>
                            </div>
                            <span className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 font-bold text-[10px] shrink-0">
                              Ans: {q.correctAnswer}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Rejected Questions & Specific Error Reasons */}
                  {importReport.errors.length > 0 && (
                    <div>
                      <h5 className="font-bold text-xs uppercase tracking-wider text-red-800 mb-2 flex items-center gap-1.5">
                        <AlertTriangle className="w-4 h-4 text-red-600" />
                        <span>{language === 'hi' ? `सत्यापन विफलताएं (${importReport.errors.length})` : `Validation Errors (${importReport.errors.length})`}</span>
                      </h5>
                      <div className="space-y-2 max-h-52 overflow-y-auto pr-1">
                        {importReport.errors.map((err, idx) => (
                          <div key={idx} className="p-3 rounded-xl bg-red-50/80 border border-red-200 text-xs">
                            <div className="flex items-center justify-between gap-2 mb-1">
                              <span className="font-bold text-red-900">
                                {language === 'hi' ? `पंक्ति/प्रश्न संख्या ${err.rowNumber}` : `Row/Question #${err.rowNumber}`}: {err.questionTitle}
                              </span>
                              <span className="px-1.5 py-0.2 rounded bg-red-200 text-red-800 font-bold text-[10px]">
                                Rejected
                              </span>
                            </div>
                            <ul className="list-disc list-inside space-y-0.5 text-red-700 text-[11px] pl-1">
                              {err.reasons.map((r, rIdx) => (
                                <li key={rIdx}>{r}</li>
                              ))}
                            </ul>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  <div className="pt-2 flex items-center justify-between">
                    <button
                      onClick={() => setImportReport(null)}
                      className="px-4 py-2 border border-slate-300 hover:bg-slate-50 text-slate-700 rounded-xl text-xs font-bold transition-colors"
                    >
                      {language === 'hi' ? 'नई फाइल आयात करें' : 'Import Another File'}
                    </button>

                    <button
                      onClick={() => setActiveAdminTab('browse')}
                      className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors"
                    >
                      <span>{language === 'hi' ? 'प्रश्न बैंक में देखें' : 'View in Question Bank'}</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* TAB 2: CREATE / EDIT MANUAL QUESTION FORM */}
        {activeAdminTab === 'create' && (
          <form onSubmit={handleSaveForm} className="space-y-4 max-w-2xl mx-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <h3 className="font-bold text-base text-slate-900">
                {editingQuestion ? (language === 'hi' ? 'प्रश्न संपादित करें' : 'Edit Question') : t('addNewQuestion')}
              </h3>
              <button
                type="button"
                onClick={() => {
                  setEditingQuestion(null);
                  setActiveAdminTab('browse');
                }}
                className="text-xs text-slate-500 hover:text-slate-800"
              >
                {t('cancel')}
              </button>
            </div>

            {formError && (
              <div className="p-3 bg-red-50 border border-red-200 text-red-700 rounded-xl text-xs font-semibold flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>{formError}</span>
              </div>
            )}

            {/* Subject & Topic */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {language === 'hi' ? 'विषय (Subject)' : 'Subject'}
                </label>
                <select
                  value={formSubjectId}
                  onChange={(e) => setFormSubjectId(e.target.value)}
                  className="w-full p-2 text-xs border border-slate-300 rounded-lg bg-white"
                >
                  {BPSC_SUBJECTS.map((s) => (
                    <option key={s.id} value={s.id}>
                      {language === 'hi' ? s.nameHindi : s.nameEnglish}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {language === 'hi' ? 'अध्याय / विषय-वस्तु (Topic)' : 'Topic'}
                </label>
                <input
                  type="text"
                  value={formTopic}
                  onChange={(e) => setFormTopic(e.target.value)}
                  placeholder="e.g. 1857 Revolt, Someshwar Range..."
                  className="w-full p-2 text-xs border border-slate-300 rounded-lg bg-white"
                />
              </div>
            </div>

            {/* Question Text in Hindi */}
            <div>
              <label className="block text-xs font-bold text-slate-900 mb-1">
                {language === 'hi' ? 'प्रश्न (हिन्दी - अनिवार्य):' : 'Question Text (Hindi - Mandatory):'}
              </label>
              <textarea
                value={formQuestionHi}
                onChange={(e) => setFormQuestionHi(e.target.value)}
                placeholder="यहाँ देवनागरी हिन्दी में प्रश्न लिखें..."
                rows={3}
                className="w-full p-2.5 text-xs sm:text-sm border border-slate-300 rounded-xl bg-white"
                required
              />
            </div>

            {/* Question Text in English */}
            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1">
                {language === 'hi' ? 'प्रश्न (अंग्रेजी अनुवाद - वैकल्पिक):' : 'Question Text (English Translation - Optional):'}
              </label>
              <textarea
                value={formQuestionEn}
                onChange={(e) => setFormQuestionEn(e.target.value)}
                placeholder="English translation of the question..."
                rows={2}
                className="w-full p-2 text-xs border border-slate-300 rounded-lg bg-white text-slate-700"
              />
            </div>

            {/* 5 Options Inputs */}
            <div>
              <label className="block text-xs font-bold text-slate-900 mb-2">
                {language === 'hi' ? 'पाँच विकल्प (A, B, C, D, E) - BPSC मानक:' : 'Five Options (A, B, C, D, E):'}
              </label>
              <div className="space-y-2">
                {(['A', 'B', 'C', 'D', 'E'] as OptionKey[]).map((key, i) => (
                  <div key={key} className="flex items-center gap-2">
                    <span className={`w-7 h-7 rounded-lg text-xs font-black flex items-center justify-center shrink-0 ${
                      formCorrectAnswer === key
                        ? 'bg-emerald-600 text-white ring-2 ring-emerald-600'
                        : 'bg-slate-200 text-slate-800'
                    }`}>
                      {key}
                    </span>
                    <input
                      type="text"
                      value={formOptionsHi[i]}
                      onChange={(e) => {
                        const updated = [...formOptionsHi] as [string, string, string, string, string];
                        updated[i] = e.target.value;
                        setFormOptionsHi(updated);
                      }}
                      placeholder={`विकल्प ${key} (हिन्दी)`}
                      className="flex-1 p-2 text-xs border border-slate-300 rounded-lg bg-white"
                      required
                    />
                    <label className="flex items-center gap-1 cursor-pointer shrink-0 text-xs font-bold text-slate-600">
                      <input
                        type="radio"
                        name="correctAnswer"
                        checked={formCorrectAnswer === key}
                        onChange={() => setFormCorrectAnswer(key)}
                        className="text-emerald-600 focus:ring-emerald-500"
                      />
                      <span className={formCorrectAnswer === key ? 'text-emerald-700 font-extrabold' : ''}>
                        {language === 'hi' ? 'सही' : 'Correct'}
                      </span>
                    </label>
                  </div>
                ))}
              </div>
            </div>

            {/* Explanation Hindi */}
            <div>
              <label className="block text-xs font-bold text-slate-900 mb-1">
                {language === 'hi' ? 'विस्तृत व्याख्या (हिन्दी - अनिवार्य):' : 'Detailed Explanation (Hindi - Mandatory):'}
              </label>
              <textarea
                value={formExplanationHi}
                onChange={(e) => setFormExplanationHi(e.target.value)}
                placeholder="सही उत्तर की पुष्टि करने वाली प्रामाणिक व्याख्या..."
                rows={3}
                className="w-full p-2.5 text-xs sm:text-sm border border-slate-300 rounded-xl bg-white"
                required
              />
            </div>

            {/* Source, Difficulty & PYQ Info */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {language === 'hi' ? 'कठिनाई (Difficulty)' : 'Difficulty'}
                </label>
                <select
                  value={formDifficulty}
                  onChange={(e) => setFormDifficulty(e.target.value as any)}
                  className="w-full p-2 text-xs border border-slate-300 rounded-lg bg-white"
                >
                  <option value="Easy">Easy (सरल)</option>
                  <option value="Medium">Medium (मध्यम)</option>
                  <option value="Hard">Hard (कठिन)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {language === 'hi' ? 'परीक्षा स्रोत (Source)' : 'Source Exam'}
                </label>
                <input
                  type="text"
                  value={formSource}
                  onChange={(e) => setFormSource(e.target.value)}
                  placeholder="e.g. 68th BPSC Prelims"
                  className="w-full p-2 text-xs border border-slate-300 rounded-lg bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {language === 'hi' ? 'वर्ष (Year)' : 'Year'}
                </label>
                <input
                  type="number"
                  value={formYear}
                  onChange={(e) => setFormYear(Number(e.target.value))}
                  className="w-full p-2 text-xs border border-slate-300 rounded-lg bg-white"
                />
              </div>
            </div>

            <div className="flex items-center gap-4 pt-2 border-t border-slate-100">
              <label className="flex items-center gap-1.5 text-xs font-semibold text-slate-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={formIsPYQ}
                  onChange={(e) => setFormIsPYQ(e.target.checked)}
                  className="rounded text-red-600"
                />
                <span>{language === 'hi' ? 'यह BPSC विगत वर्ष का प्रश्न (PYQ) है' : 'Official Previous Year Question (PYQ)'}</span>
              </label>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
              <button
                type="button"
                onClick={() => {
                  setEditingQuestion(null);
                  setActiveAdminTab('browse');
                }}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold"
              >
                {t('cancel')}
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-red-700 hover:bg-red-800 text-white rounded-xl text-xs font-bold shadow-md shadow-red-700/20"
              >
                {editingQuestion ? (language === 'hi' ? 'अद्यतन सहेजें' : 'Update Question') : (language === 'hi' ? 'प्रश्न सहेजें' : 'Save Question')}
              </button>
            </div>
          </form>
        )}

        {/* TAB 3: BROWSE QUESTION BANK LIST */}
        {activeAdminTab === 'browse' && (
          <div className="space-y-4">
            {/* Search & Subject & Difficulty Filters */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-2">
              <div className="relative w-full sm:w-64">
                <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder={t('searchPlaceholder')}
                  className="w-full pl-9 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800"
                />
              </div>

              <div className="grid grid-cols-1 min-[440px]:grid-cols-3 sm:flex sm:flex-wrap items-center gap-2 w-full sm:w-auto">
                <select
                  value={selectedSubject}
                  onChange={(e) => setSelectedSubject(e.target.value)}
                  className="w-full sm:w-auto p-2 sm:p-1.5 text-xs border border-slate-200 rounded-xl bg-slate-50 font-semibold"
                >
                  <option value="all">{language === 'hi' ? 'सभी 11 विषय' : 'All 11 Subjects'}</option>
                  {BPSC_SUBJECTS.map((s) => (
                    <option key={s.id} value={s.id}>
                      {language === 'hi' ? s.nameHindi : s.nameEnglish}
                    </option>
                  ))}
                </select>

                <select
                  value={selectedDifficulty}
                  onChange={(e) => setSelectedDifficulty(e.target.value)}
                  className="w-full sm:w-auto p-2 sm:p-1.5 text-xs border border-slate-200 rounded-xl bg-slate-50 font-semibold"
                >
                  <option value="all">{language === 'hi' ? 'सभी कठिनाई' : 'All Difficulty'}</option>
                  <option value="Easy">{language === 'hi' ? 'सरल (Easy)' : 'Easy'}</option>
                  <option value="Medium">{language === 'hi' ? 'मध्यम (Med)' : 'Medium'}</option>
                  <option value="Hard">{language === 'hi' ? 'कठिन (Hard)' : 'Hard'}</option>
                </select>

                <select
                  value={selectedOrigin}
                  onChange={(e) => setSelectedOrigin(e.target.value as any)}
                  className="w-full sm:w-auto p-2 sm:p-1.5 text-xs border border-slate-200 rounded-xl bg-slate-50 font-semibold text-slate-800"
                >
                  <option value="all">{language === 'hi' ? 'सभी प्रकार (All)' : 'All Questions'}</option>
                  <option value="original">{language === 'hi' ? 'मूल प्रश्न (Original)' : 'Original Questions'}</option>
                  <option value="imported">{language === 'hi' ? 'नए आयातित (Imported)' : 'Imported Questions'}</option>
                  <option value="demo">{language === 'hi' ? 'डेमो / टेस्ट (Demo/Test)' : 'Demo / Test Questions'}</option>
                </select>
              </div>
            </div>

            <div className="flex items-center justify-between text-xs text-slate-500 font-semibold">
              <span>{filteredList.length} {language === 'hi' ? 'प्रश्न प्रदर्शित' : 'questions listed'}</span>
              <button
                onClick={() => setActiveAdminTab('import')}
                className="text-red-700 hover:underline flex items-center gap-1 font-bold"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>{language === 'hi' ? 'नये प्रश्न बल्क आयात करें' : 'Bulk Import Questions'}</span>
              </button>
            </div>

            {/* Questions Cards List */}
            <div className="space-y-2.5">
              {filteredList.map((q) => {
                const subj = BPSC_SUBJECTS.find((s) => s.id === q.subjectId);

                return (
                  <div
                    key={q.id}
                    className="p-3.5 rounded-xl border border-slate-200 bg-white hover:border-slate-300 transition-colors flex items-start justify-between gap-3 text-xs"
                  >
                    <div className="space-y-1.5 flex-1">
                      <div className="flex flex-wrap items-center gap-1.5">
                        <span className="font-bold px-2 py-0.5 rounded bg-slate-100 text-slate-700 text-[10px]">
                          {language === 'hi' ? subj?.nameHindi : subj?.nameEnglish}
                        </span>
                        <span className="font-semibold text-slate-600 text-[10px]">
                          • {q.topic}
                        </span>
                        <span className={`font-bold px-1.5 py-0.2 rounded text-[10px] ${
                          q.difficulty === 'Easy'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : q.difficulty === 'Hard'
                            ? 'bg-rose-50 text-rose-700 border border-rose-200'
                            : 'bg-amber-50 text-amber-700 border border-amber-200'
                        }`}>
                          {q.difficulty}
                        </span>
                        {q.isDemo && (
                          <span className="font-bold text-amber-900 bg-amber-100 border border-amber-300 px-1.5 py-0.2 rounded text-[10px] flex items-center gap-0.5">
                            <Sparkles className="w-3 h-3 text-amber-700" />
                            <span>[डेमो/परीक्षण]</span>
                          </span>
                        )}
                        {q.isImported && !q.isDemo && (
                          <span className="font-bold text-indigo-900 bg-indigo-100 border border-indigo-300 px-1.5 py-0.2 rounded text-[10px] flex items-center gap-0.5">
                            <CheckCircle2 className="w-3 h-3 text-indigo-700" />
                            <span>नया आयातित</span>
                          </span>
                        )}
                        {q.isPYQ && (
                          <span className="font-bold text-emerald-800 bg-emerald-50 border border-emerald-200 px-1.5 py-0.2 rounded text-[10px] flex items-center gap-0.5">
                            <ShieldCheck className="w-3 h-3 text-emerald-600" />
                            <span>{q.source}</span>
                          </span>
                        )}
                        {q.isAIGenerated && (
                          <span className="font-bold text-amber-800 bg-amber-50 border border-amber-200 px-1.5 py-0.2 rounded text-[10px] flex items-center gap-0.5">
                            <AlertTriangle className="w-3 h-3 text-amber-600" />
                            <span>{t('aiGeneratedLabel')}</span>
                          </span>
                        )}
                      </div>

                      <p className="font-bold text-slate-900 text-xs sm:text-sm line-clamp-2">
                        {q.questionHindi}
                      </p>

                      <div className="text-slate-500 text-[11px]">
                        <span className="font-bold text-emerald-700">
                          {language === 'hi' ? 'सही विकल्प:' : 'Answer:'} ({q.correctAnswer})
                        </span>{' '}
                        {q.optionsHindi[['A', 'B', 'C', 'D', 'E'].indexOf(q.correctAnswer)]}
                      </div>
                    </div>

                    {/* Action buttons */}
                    <div className="flex items-center gap-1 shrink-0 pt-1">
                      <button
                        onClick={() => handleOpenEdit(q)}
                        className="p-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-600"
                        title="Edit"
                      >
                        <Edit className="w-3.5 h-3.5" />
                      </button>
                      {confirmDeleteId === q.id ? (
                        <div className="flex items-center gap-1 bg-red-50 p-1 rounded-lg border border-red-200">
                          <button
                            onClick={() => {
                              deleteQuestion(q.id);
                              setConfirmDeleteId(null);
                            }}
                            className="px-2 py-0.5 bg-red-700 text-white font-bold rounded text-[10px] hover:bg-red-800"
                          >
                            {language === 'hi' ? 'हटाएं' : 'Delete'}
                          </button>
                          <button
                            onClick={() => setConfirmDeleteId(null)}
                            className="px-1.5 py-0.5 text-slate-500 hover:text-slate-800 text-[10px]"
                          >
                            ✕
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => setConfirmDeleteId(q.id)}
                          className="p-1.5 rounded-lg border border-slate-200 hover:bg-red-50 text-slate-400 hover:text-red-700"
                          title="Delete"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* Footer */}
      {onClose && (
        <div className="p-3 bg-slate-50 border-t border-slate-200 flex justify-end shrink-0">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-bold"
          >
            {language === 'hi' ? 'बंद करें' : 'Close'}
          </button>
        </div>
      )}
    </div>
  );

  if (isStandalonePage) {
    return <div className="w-full">{content}</div>;
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      {content}
    </div>
  );
};
