import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { useQuestions } from '../context/QuestionContext';
import { useTest } from '../context/TestContext';
import { BPSC_SUBJECTS } from '../data/subjects';
import { TestMode, TestSettings } from '../types';
import { 
  X, 
  Sparkles, 
  Clock, 
  HelpCircle, 
  CheckCircle2, 
  SlidersHorizontal,
  Shuffle,
  ShieldAlert
} from 'lucide-react';

interface TestConfigModalProps {
  isOpen: boolean;
  onClose: () => void;
  presetSubjectId?: string;
  presetPYQOnly?: boolean;
}

export const TestConfigModal: React.FC<TestConfigModalProps> = ({
  isOpen,
  onClose,
  presetSubjectId,
  presetPYQOnly = false,
}) => {
  const { t, language } = useLanguage();
  const { questions } = useQuestions();
  const { startTest } = useTest();

  const [questionCount, setQuestionCount] = useState<number>(10);
  const [mode, setMode] = useState<TestMode>('exam');
  const [negativeMarking, setNegativeMarking] = useState<number>(0.25); // Standard BPSC negative marking
  const [selectedSubjects, setSelectedSubjects] = useState<string[]>(
    presetSubjectId ? [presetSubjectId] : []
  );
  const [timeMode, setTimeMode] = useState<'auto' | 'custom' | 'none'>('auto');
  const [customMinutes, setCustomMinutes] = useState<number>(15);
  const [shuffleQuestions, setShuffleQuestions] = useState<boolean>(true);
  const [shuffleOptions, setShuffleOptions] = useState<boolean>(true);
  const [pyqOnly, setPyqOnly] = useState<boolean>(presetPYQOnly);

  if (!isOpen) return null;

  // Filter pool count
  let availablePool = [...questions];
  if (pyqOnly) {
    availablePool = availablePool.filter((q) => q.isPYQ);
  }
  if (selectedSubjects.length > 0) {
    availablePool = availablePool.filter((q) => selectedSubjects.includes(q.subjectId));
  }

  const handleStart = () => {
    let minutes = 0;
    if (timeMode === 'auto') {
      minutes = Math.max(5, Math.round(questionCount * 1.2));
    } else if (timeMode === 'custom') {
      minutes = customMinutes;
    } else {
      minutes = 0; // untimed
    }

    const testSettings: TestSettings = {
      questionCount,
      subjects: selectedSubjects,
      mode,
      negativeMarking,
      timeLimitMinutes: minutes,
      shuffleQuestions,
      shuffleOptions,
      pyqOnly,
    };

    let title = 'BPSC Full Mock Test';
    if (selectedSubjects.length === 1) {
      const subj = BPSC_SUBJECTS.find((s) => s.id === selectedSubjects[0]);
      title = `${language === 'hi' ? subj?.nameHindi : subj?.nameEnglish} Practice`;
    } else if (pyqOnly) {
      title = 'BPSC Previous Year Questions (PYQs)';
    }

    startTest(testSettings, availablePool, title);
    onClose();
  };

  const toggleSubject = (subjId: string) => {
    if (selectedSubjects.includes(subjId)) {
      setSelectedSubjects(selectedSubjects.filter((id) => id !== subjId));
    } else {
      setSelectedSubjects([...selectedSubjects, subjId]);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white w-full max-w-xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-auto animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="bg-gradient-to-r from-red-800 to-amber-700 text-white p-4 sm:p-5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <SlidersHorizontal className="w-5 h-5 text-amber-200" />
            <div>
              <h2 className="text-base sm:text-lg font-bold">
                {t('configureTest')}
              </h2>
              <p className="text-xs text-red-100">
                {language === 'hi' 
                  ? 'अपनी तैयारी के अनुसार टेस्ट पैरामीटर निर्धारित करें'
                  : 'Customize question count, marking rules and timer'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-red-200 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-4 sm:p-6 space-y-5 max-h-[75vh] overflow-y-auto">
          {/* Question count selection */}
          <div>
            <label className="block text-xs sm:text-sm font-bold text-slate-900 mb-2">
              {t('chooseQuestions')}
            </label>
            <div className="grid grid-cols-5 gap-1.5 sm:gap-2">
              {[3, 10, 25, 50, 100].map((num) => (
                <button
                  key={num}
                  type="button"
                  onClick={() => setQuestionCount(num)}
                  className={`py-2 px-2 sm:px-3 rounded-xl border text-xs sm:text-sm font-bold transition-all ${
                    questionCount === num
                      ? 'bg-red-700 text-white border-red-700 shadow-sm'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  {num} {language === 'hi' ? 'प्रश्न' : 'Q'}
                </button>
              ))}
            </div>
          </div>

          {/* Test Mode */}
          <div>
            <label className="block text-xs sm:text-sm font-bold text-slate-900 mb-2">
              {t('testMode')}
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <button
                type="button"
                onClick={() => setMode('exam')}
                className={`p-3 rounded-xl border text-left transition-all ${
                  mode === 'exam'
                    ? 'border-red-600 bg-red-50/70 ring-1 ring-red-600'
                    : 'border-slate-200 hover:border-slate-300 bg-white'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-bold text-sm text-slate-900">
                    {language === 'hi' ? 'परीक्षा मोड (Exam Mode)' : 'Exam Mode'}
                  </span>
                  {mode === 'exam' && <CheckCircle2 className="w-4 h-4 text-red-700" />}
                </div>
                <p className="text-xs text-slate-500">
                  {language === 'hi' 
                    ? 'समयबद्ध, वास्तविक परीक्षा माहौल, उत्तर अंत में'
                    : 'Timed simulation, final score & review at end'}
                </p>
              </button>

              <button
                type="button"
                onClick={() => setMode('practice')}
                className={`p-3 rounded-xl border text-left transition-all ${
                  mode === 'practice'
                    ? 'border-amber-600 bg-amber-50/70 ring-1 ring-amber-600'
                    : 'border-slate-200 hover:border-slate-300 bg-white'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-bold text-sm text-slate-900">
                    {language === 'hi' ? 'अभ्यास मोड (Practice Mode)' : 'Practice Mode'}
                  </span>
                  {mode === 'practice' && <CheckCircle2 className="w-4 h-4 text-amber-700" />}
                </div>
                <p className="text-xs text-slate-500">
                  {language === 'hi' 
                    ? 'तुरंत उत्तर जांचें, त्वरित विस्तृत व्याख्या'
                    : 'Instant feedback with detailed Devanagari explanation'}
                </p>
              </button>
            </div>
          </div>

          {/* Negative Marking Selection */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs sm:text-sm font-bold text-slate-900 flex items-center gap-1.5">
                <ShieldAlert className="w-4 h-4 text-amber-600" />
                <span>{t('negativeMarking')}</span>
              </label>
              <span className="text-[11px] font-medium text-slate-500">
                {language === 'hi' ? 'कॉन्फ़िगर करने योग्य नियम' : 'Configurable Rule'}
              </span>
            </div>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setNegativeMarking(0)}
                className={`py-2 px-2.5 rounded-xl border text-xs font-semibold text-center transition-all ${
                  negativeMarking === 0
                    ? 'bg-slate-800 text-white border-slate-800'
                    : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                <div>0.00</div>
                <div className="text-[10px] opacity-80">{language === 'hi' ? 'कोई कटौती नहीं' : 'No Negative'}</div>
              </button>

              <button
                type="button"
                onClick={() => setNegativeMarking(0.25)}
                className={`py-2 px-2.5 rounded-xl border text-xs font-semibold text-center transition-all ${
                  negativeMarking === 0.25
                    ? 'bg-red-700 text-white border-red-700'
                    : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                <div>-0.25 (1/4)</div>
                <div className="text-[10px] opacity-80">{language === 'hi' ? 'मानक BPSC' : 'Standard BPSC'}</div>
              </button>

              <button
                type="button"
                onClick={() => setNegativeMarking(0.33)}
                className={`py-2 px-2.5 rounded-xl border text-xs font-semibold text-center transition-all ${
                  negativeMarking === 0.33
                    ? 'bg-red-700 text-white border-red-700'
                    : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                <div>-0.33 (1/3)</div>
                <div className="text-[10px] opacity-80">{language === 'hi' ? 'कठिन कटौती' : 'Strict 1/3rd'}</div>
              </button>
            </div>
          </div>

          {/* Time Limit */}
          <div>
            <label className="block text-xs sm:text-sm font-bold text-slate-900 mb-2">
              {t('timeLimit')}
            </label>
            <div className="grid grid-cols-3 gap-2 mb-2">
              <button
                type="button"
                onClick={() => setTimeMode('auto')}
                className={`py-2 px-2 rounded-xl border text-xs font-semibold text-center transition-all ${
                  timeMode === 'auto'
                    ? 'bg-slate-900 text-white border-slate-900'
                    : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                {Math.round(questionCount * 1.2)} {language === 'hi' ? 'मिनट (स्वतः)' : 'min (Auto)'}
              </button>

              <button
                type="button"
                onClick={() => setTimeMode('custom')}
                className={`py-2 px-2 rounded-xl border text-xs font-semibold text-center transition-all ${
                  timeMode === 'custom'
                    ? 'bg-slate-900 text-white border-slate-900'
                    : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                {language === 'hi' ? 'कस्टम समय' : 'Custom Min'}
              </button>

              <button
                type="button"
                onClick={() => setTimeMode('none')}
                className={`py-2 px-2 rounded-xl border text-xs font-semibold text-center transition-all ${
                  timeMode === 'none'
                    ? 'bg-slate-900 text-white border-slate-900'
                    : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                {language === 'hi' ? 'असीमित समय' : 'Untimed'}
              </button>
            </div>

            {timeMode === 'custom' && (
              <div className="flex items-center gap-2 mt-2">
                <input
                  type="number"
                  min="2"
                  max="180"
                  value={customMinutes}
                  onChange={(e) => setCustomMinutes(Math.max(2, parseInt(e.target.value) || 10))}
                  className="w-24 px-3 py-1.5 border border-slate-300 rounded-lg text-sm font-bold text-slate-800"
                />
                <span className="text-xs text-slate-500 font-medium">
                  {language === 'hi' ? 'कुल मिनट' : 'total minutes'}
                </span>
              </div>
            )}
          </div>

          {/* Subject Selector */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs sm:text-sm font-bold text-slate-900">
                {language === 'hi' ? 'विषय चुनें (वैकल्पिक)' : 'Select Subjects (Optional)'}
              </label>
              {selectedSubjects.length > 0 && (
                <button
                  type="button"
                  onClick={() => setSelectedSubjects([])}
                  className="text-xs text-red-700 hover:underline font-semibold"
                >
                  {language === 'hi' ? 'सभी विषय (मिश्रित)' : 'Clear (All Mixed)'}
                </button>
              )}
            </div>
            <div className="flex flex-wrap gap-1.5 max-h-36 overflow-y-auto p-1.5 bg-slate-50 rounded-xl border border-slate-200">
              {BPSC_SUBJECTS.map((subj) => {
                const isSelected = selectedSubjects.includes(subj.id);
                return (
                  <button
                    key={subj.id}
                    type="button"
                    onClick={() => toggleSubject(subj.id)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all ${
                      isSelected
                        ? 'bg-red-700 text-white shadow-2xs'
                        : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {language === 'hi' ? subj.nameHindi : subj.nameEnglish}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Toggles */}
          <div className="space-y-2 pt-2 border-t border-slate-100">
            <label className="flex items-center justify-between cursor-pointer py-1">
              <span className="text-xs sm:text-sm font-medium text-slate-700">
                {t('pyqOnly')}
              </span>
              <input
                type="checkbox"
                checked={pyqOnly}
                onChange={(e) => setPyqOnly(e.target.checked)}
                className="w-4 h-4 accent-red-700 rounded cursor-pointer"
              />
            </label>

            <label className="flex items-center justify-between cursor-pointer py-1">
              <span className="text-xs sm:text-sm font-medium text-slate-700">
                {t('shuffleQuestions')}
              </span>
              <input
                type="checkbox"
                checked={shuffleQuestions}
                onChange={(e) => setShuffleQuestions(e.target.checked)}
                className="w-4 h-4 accent-red-700 rounded cursor-pointer"
              />
            </label>

            <label className="flex items-center justify-between cursor-pointer py-1">
              <span className="text-xs sm:text-sm font-medium text-slate-700">
                {t('shuffleOptions')}
              </span>
              <input
                type="checkbox"
                checked={shuffleOptions}
                onChange={(e) => setShuffleOptions(e.target.checked)}
                className="w-4 h-4 accent-red-700 rounded cursor-pointer"
              />
            </label>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-slate-50 p-4 border-t border-slate-200 flex items-center justify-between gap-3">
          <div className="text-xs text-slate-600 font-medium">
            <span>{availablePool.length} {language === 'hi' ? 'योग्य प्रश्न उपलब्ध' : 'questions matched'}</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-bold text-slate-600 hover:text-slate-800 transition-colors"
            >
              {t('cancel')}
            </button>
            <button
              type="button"
              onClick={handleStart}
              disabled={availablePool.length === 0}
              className="px-5 py-2.5 bg-red-700 hover:bg-red-800 disabled:bg-slate-300 text-white rounded-xl text-xs sm:text-sm font-bold transition-all shadow-md shadow-red-700/20 active:scale-98"
            >
              {t('startTestBtn')}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
