import React, { useState, useEffect } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { useUser } from '../context/UserContext';
import { useQuestions } from '../context/QuestionContext';
import { useTest } from '../context/TestContext';
import { BPSC_SUBJECTS } from '../data/subjects';
import { MockTestTemplate, Question } from '../types';
import {
  GraduationCap,
  Award,
  Target,
  Flame,
  Clock,
  BookOpen,
  Bookmark,
  AlertCircle,
  Play,
  RotateCcw,
  LogOut,
  ChevronRight,
  TrendingUp,
  SlidersHorizontal,
  CheckCircle2,
  Calendar,
  Sparkles,
  Layers,
  FileCheck,
  FileText,
  Database,
  Upload
} from 'lucide-react';

interface StudentDashboardProps {
  onOpenConfigModal: (subjectId?: string) => void;
  onNavigateTab: (tab: string) => void;
}

export const StudentDashboard: React.FC<StudentDashboardProps> = ({
  onOpenConfigModal,
  onNavigateTab,
}) => {
  const { language } = useLanguage();
  const { 
    profile, 
    currentUser, 
    testHistory, 
    overallStats, 
    logout, 
    isLoggedIn, 
    openLoginModal,
    hasCompletedQuizToday 
  } = useUser();
  const { questions } = useQuestions();
  const { startTest } = useTest();

  const [availableMockTests, setAvailableMockTests] = useState<MockTestTemplate[]>([]);
  const [loadingMocks, setLoadingMocks] = useState(false);

  // Load mock tests from backend
  useEffect(() => {
    setLoadingMocks(true);
    fetch('/api/mock-tests')
      .then((res) => res.json())
      .then((data) => {
        if (Array.isArray(data)) {
          setAvailableMockTests(data);
        }
      })
      .catch((err) => console.warn('Could not load mock tests:', err))
      .finally(() => setLoadingMocks(false));
  }, []);

  // Subject-wise accuracy & practice statistics calculation
  const subjectProgress = React.useMemo(() => {
    return BPSC_SUBJECTS.map((subject) => {
      let totalQuestionsInSubject = 0;
      let totalAttempted = 0;
      let totalCorrect = 0;

      // Count in bank
      totalQuestionsInSubject = questions.filter((q) => q.subjectId === subject.id).length;

      // Sum from test history
      testHistory.forEach((t) => {
        const breakdown = t.subjectBreakdown?.[subject.id];
        if (breakdown) {
          totalAttempted += (breakdown.correct + breakdown.incorrect);
          totalCorrect += breakdown.correct;
        }
      });

      const accuracy = totalAttempted > 0 ? Math.round((totalCorrect / totalAttempted) * 100) : 0;

      return {
        ...subject,
        totalQuestionsInSubject,
        totalAttempted,
        totalCorrect,
        accuracy,
      };
    });
  }, [questions, testHistory]);

  const handleStartDailyChallenge = () => {
    startTest(
      {
        questionCount: 10,
        subjects: [],
        mode: 'exam',
        negativeMarking: 0.25,
        timeLimitMinutes: 12,
        shuffleQuestions: true,
        shuffleOptions: true,
      },
      questions,
      language === 'hi' ? 'दैनिक 10-प्रश्न चैलेंज' : 'Daily 10-MCQ Challenge'
    );
  };

  const handleStartMockTemplate = (template: MockTestTemplate) => {
    const pool = template.subjectIds.length > 0
      ? questions.filter((q) => template.subjectIds.includes(q.subjectId))
      : questions;

    const testQuestions = pool.slice(0, template.questionCount);

    startTest(
      {
        questionCount: Math.min(template.questionCount, testQuestions.length),
        subjects: template.subjectIds,
        mode: 'exam',
        negativeMarking: template.negativeMarking,
        timeLimitMinutes: template.timeLimitMinutes,
        shuffleQuestions: true,
        shuffleOptions: true,
      },
      testQuestions,
      language === 'hi' ? template.titleHindi : template.title
    );
  };

  return (
    <div className="space-y-6 sm:space-y-8 pb-12 animate-in fade-in duration-200">
      {/* Top Student Profile & Identity Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-red-950 to-slate-900 text-white rounded-2xl sm:rounded-3xl p-4 sm:p-7 shadow-xl border border-slate-800 relative overflow-hidden">
        {/* Glow accent */}
        <div className="absolute top-0 right-0 w-80 h-80 bg-red-600/15 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 sm:gap-5">
          <div className="flex items-center gap-3 sm:gap-4 min-w-0 w-full md:w-auto">
            <div className="w-12 h-12 sm:w-16 sm:h-16 rounded-2xl bg-gradient-to-tr from-amber-500 to-red-600 text-slate-950 font-black text-lg sm:text-2xl flex items-center justify-center shadow-lg border-2 border-white/20 shrink-0">
              {currentUser?.name ? currentUser.name.charAt(0).toUpperCase() : profile.name.charAt(0).toUpperCase()}
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-1.5 sm:gap-2">
                <h2 className="text-lg sm:text-2xl font-black tracking-tight truncate">
                  {currentUser?.name || profile.name}
                </h2>
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] sm:text-xs font-bold border border-emerald-500/30 flex items-center gap-1 shrink-0">
                  <CheckCircle2 className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
                  <span>{language === 'hi' ? 'सत्यापित विद्यार्थी' : 'Verified Aspirant'}</span>
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate-300 mt-0.5 sm:mt-1 flex items-center gap-1.5 truncate">
                <Target className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-amber-400 shrink-0" />
                <span className="truncate">{currentUser?.targetExam || profile.targetExam}</span>
              </p>
              <p className="text-[10px] sm:text-[11px] text-slate-400 mt-0.5 font-mono truncate">
                {currentUser?.email || 'Guest Student Mode'}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto">
            {isLoggedIn ? (
              <button
                onClick={logout}
                className="px-4 py-2 bg-white/10 hover:bg-white/20 border border-white/20 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer w-full sm:w-auto"
              >
                <LogOut className="w-3.5 h-3.5 text-red-300" />
                <span>{language === 'hi' ? 'लॉगआउट (Logout)' : 'Logout'}</span>
              </button>
            ) : (
              <button
                onClick={openLoginModal}
                className="px-4 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-xl text-xs font-black flex items-center justify-center gap-1.5 shadow-md transition-all cursor-pointer w-full sm:w-auto"
              >
                <GraduationCap className="w-4 h-4" />
                <span>{language === 'hi' ? 'लॉगिन / साइन अप करें' : 'Login / Register'}</span>
              </button>
            )}

            <button
              onClick={() => onOpenConfigModal()}
              className="px-4 py-2.5 bg-red-700 hover:bg-red-800 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-md shadow-red-900/30 transition-all cursor-pointer w-full sm:w-auto"
            >
              <SlidersHorizontal className="w-4 h-4" />
              <span>{language === 'hi' ? 'कस्टम मॉक टेस्ट' : 'Create Custom Mock'}</span>
            </button>

            <button
              onClick={() => onNavigateTab('import')}
              className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-md shadow-emerald-900/20 transition-all cursor-pointer w-full sm:w-auto"
              title={language === 'hi' ? 'CSV और JSON से प्रश्न आयात करें' : 'Import questions via CSV and JSON'}
            >
              <Upload className="w-4 h-4" />
              <span>{language === 'hi' ? 'प्रश्न बैंक आयात (CSV/JSON)' : 'Question Bank Import'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* 4 Performance Metric Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {/* Total Tests */}
        <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-500 font-semibold block">
              {language === 'hi' ? 'कुल दिए गए टेस्ट' : 'Total Tests Taken'}
            </span>
            <span className="text-xl sm:text-2xl font-black text-slate-900 mt-1 block">
              {overallStats.totalTests}
            </span>
            <span className="text-[11px] text-slate-400 font-medium">
              {overallStats.totalAttempted} {language === 'hi' ? 'प्रश्न हल किए' : 'Qs attempted'}
            </span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-red-50 text-red-700 flex items-center justify-center shrink-0">
            <Award className="w-5 h-5" />
          </div>
        </div>

        {/* Accuracy */}
        <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-500 font-semibold block">
              {language === 'hi' ? 'सटीकता (Accuracy)' : 'Overall Accuracy'}
            </span>
            <span className="text-xl sm:text-2xl font-black text-emerald-600 mt-1 block">
              {overallStats.accuracy}%
            </span>
            <span className="text-[11px] text-emerald-700 font-medium">
              ✓ {overallStats.totalCorrect} {language === 'hi' ? 'सही उत्तर' : 'correct'}
            </span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0">
            <TrendingUp className="w-5 h-5" />
          </div>
        </div>

        {/* Daily Study Streak */}
        <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-500 font-semibold block">
              {language === 'hi' ? 'दैनिक क्विज स्ट्रीक' : 'Current Study Streak'}
            </span>
            <div className="flex items-center gap-1.5 mt-1">
              <span className="text-xl sm:text-2xl font-black text-amber-600">
                {profile.studyStreakDays} {language === 'hi' ? 'दिन' : 'Days'}
              </span>
              {hasCompletedQuizToday && (
                <span className="px-1.5 py-0.2 rounded bg-amber-100 text-amber-800 text-[10px] font-black">
                  ✓ आज पूरा
                </span>
              )}
            </div>
            <span className="text-[11px] text-slate-400 font-medium">
              {language === 'hi' ? 'सर्वश्रेष्ठ:' : 'Best:'} {profile.longestStreakDays} {language === 'hi' ? 'दिन' : 'days'}
            </span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center shrink-0">
            <Flame className="w-5 h-5 fill-amber-500" />
          </div>
        </div>

        {/* Average Score */}
        <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-500 font-semibold block">
              {language === 'hi' ? 'औसत अंक (Avg Score)' : 'Average Score'}
            </span>
            <span className="text-xl sm:text-2xl font-black text-blue-600 mt-1 block">
              {overallStats.averageScore}
            </span>
            <span className="text-[11px] text-slate-400 font-medium">
              {language === 'hi' ? 'प्रति टेस्ट अंक' : 'points / test'}
            </span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center shrink-0">
            <Clock className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Quick Access Action Banners (Previous Year TRE Papers, Daily Quiz, Mistake Revision, Bookmarks) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
        {/* CARD 1: Previous Year TRE Papers */}
        <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-emerald-950 via-teal-950 to-emerald-900 text-white flex flex-col justify-between shadow-md border border-emerald-800/80 group hover:border-emerald-500/60 transition-all">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="px-2 py-0.5 rounded-full bg-emerald-500 text-slate-950 text-[10px] font-black uppercase tracking-wider">
                Official TRE
              </span>
              <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-300 flex items-center justify-center">
                <FileText className="w-4 h-4 text-emerald-400 group-hover:scale-110 transition-transform" />
              </div>
            </div>
            <h3 className="font-black text-base sm:text-lg leading-tight text-white">
              {language === 'hi' ? 'विगत वर्षों के TRE प्रश्न पत्र' : 'Previous Year TRE Papers'}
            </h3>
            <p className="text-xs text-emerald-200/90 mt-1">
              {language === 'hi'
                ? 'Practice Previous Year Question Papers (TRE 1.0, 2.0 व 3.0 आधिकारिक प्रश्न पत्र हल करें)'
                : 'Practice Previous Year Question Papers with authentic 5-option answer keys & PDFs'}
            </p>
            <div className="flex flex-wrap items-center gap-1 mt-2.5">
              <span className="px-1.5 py-0.5 rounded bg-emerald-800/80 text-emerald-200 text-[10px] font-bold">TRE 1.0</span>
              <span className="px-1.5 py-0.5 rounded bg-emerald-800/80 text-emerald-200 text-[10px] font-bold">TRE 2.0</span>
              <span className="px-1.5 py-0.5 rounded bg-emerald-800/80 text-emerald-200 text-[10px] font-bold">TRE 3.0</span>
              <span className="px-1.5 py-0.5 rounded bg-white/10 text-emerald-300 text-[10px] font-bold">TRE 4.0</span>
            </div>
          </div>
          <button
            onClick={() => onNavigateTab('pyq')}
            className="mt-4 w-full py-2.5 bg-emerald-400 hover:bg-emerald-300 text-slate-950 rounded-xl text-xs font-black flex items-center justify-center gap-1.5 shadow-sm transition-all cursor-pointer"
          >
            <Play className="w-3.5 h-3.5 fill-slate-950" />
            <span>{language === 'hi' ? 'TRE पेपर्स हल करें' : 'Open TRE Papers'}</span>
          </button>
        </div>

        {/* CARD 2: Daily 10-Question Quiz */}
        <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-amber-500 to-amber-600 text-slate-950 flex flex-col justify-between shadow-sm">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="px-2 py-0.5 rounded-full bg-slate-950 text-amber-300 text-[10px] font-black uppercase">
                Daily Drill
              </span>
              <Sparkles className="w-4 h-4 text-slate-950" />
            </div>
            <h3 className="font-black text-base sm:text-lg leading-tight">
              {language === 'hi' ? 'दैनिक 10-प्रश्न चैलेंज' : 'Daily 10-MCQ Challenge'}
            </h3>
            <p className="text-xs text-slate-900/80 mt-1">
              {language === 'hi'
                ? 'नियमित अभ्यास करें और अपनी लगातार अध्ययन स्ट्रीक सुरक्षित रखें।'
                : '10 questions, negative marking 0.25, keeps streak active.'}
            </p>
          </div>
          <button
            onClick={handleStartDailyChallenge}
            className="mt-4 w-full py-2.5 bg-slate-950 hover:bg-slate-900 text-white rounded-xl text-xs font-extrabold flex items-center justify-center gap-1.5 transition-all cursor-pointer"
          >
            <Play className="w-3.5 h-3.5 fill-white" />
            <span>{language === 'hi' ? 'अभी क्विज शुरू करें' : 'Start Daily Quiz'}</span>
          </button>
        </div>

        {/* CARD 3: Mistakes Revision */}
        <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-red-50 to-orange-50 border border-red-200 flex flex-col justify-between shadow-2xs">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="px-2 py-0.5 rounded-full bg-red-100 text-red-800 text-[10px] font-black uppercase">
                Mistake Bank
              </span>
              <AlertCircle className="w-4 h-4 text-red-600" />
            </div>
            <h3 className="font-extrabold text-base text-slate-900 leading-tight">
              {language === 'hi' ? 'गलत उत्तरों का पुनरावलोकन' : 'Mistakes Revision'}
            </h3>
            <p className="text-xs text-slate-600 mt-1">
              {language === 'hi'
                ? `आपके पास ${profile.incorrectQuestionIds.length} गलत उत्तर वाले प्रश्न हैं जिन्हें दोबारा हल करना चाहिए।`
                : `${profile.incorrectQuestionIds.length} incorrect questions available for retry.`}
            </p>
          </div>
          <button
            onClick={() => onNavigateTab('mistakes')}
            className="mt-4 w-full py-2.5 bg-red-700 hover:bg-red-800 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>{language === 'hi' ? 'गलती सुधारें' : 'Practice Mistakes'} ({profile.incorrectQuestionIds.length})</span>
          </button>
        </div>

        {/* CARD 4: Bookmarked Questions */}
        <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-slate-50 to-blue-50 border border-slate-200 flex flex-col justify-between shadow-2xs">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 text-[10px] font-black uppercase">
                Saved MCQs
              </span>
              <Bookmark className="w-4 h-4 text-blue-600" />
            </div>
            <h3 className="font-extrabold text-base text-slate-900 leading-tight">
              {language === 'hi' ? 'सहेजे गए महत्वपूर्ण प्रश्न' : 'Bookmarked Questions'}
            </h3>
            <p className="text-xs text-slate-600 mt-1">
              {language === 'hi'
                ? `परीक्षा से पूर्व त्वरित रिवीजन हेतु ${profile.bookmarks.length} प्रश्न बुकमार्क किए गए हैं।`
                : `${profile.bookmarks.length} bookmarked high-yield questions for rapid revision.`}
            </p>
          </div>
          <button
            onClick={() => onNavigateTab('bookmarks')}
            className="mt-4 w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer"
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>{language === 'hi' ? 'बुकमार्क देखें' : 'View Bookmarks'} ({profile.bookmarks.length})</span>
          </button>
        </div>
      </div>

      {/* Official Practice Sets & Mock Tests Section */}
      <div className="bg-white rounded-3xl border border-slate-200 p-5 sm:p-6 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 pb-3 border-b border-slate-200">
          <div>
            <div className="flex items-center gap-2">
              <Layers className="w-5 h-5 text-red-700" />
              <h3 className="font-black text-base sm:text-lg text-slate-900">
                {language === 'hi' ? 'आधिकारिक प्रैक्टिस सेट व मॉक टेस्ट' : 'Official Practice Sets & Mock Tests'}
              </h3>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              {language === 'hi'
                ? '5-विकल्प मानक (A-E), टाइमर एवं नेगेटिव मार्किंग के साथ पूर्ण अभ्यास करें।'
                : 'Timed tests with strict 5-option format and negative marking.'}
            </p>
          </div>

          <button
            onClick={() => onOpenConfigModal()}
            className="text-xs font-bold text-red-700 hover:text-red-900 flex items-center gap-1"
          >
            <span>{language === 'hi' ? 'नया टेस्ट कॉन्फ़िगर करें' : 'Configure Custom Test'}</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
          {availableMockTests.map((mock) => (
            <div
              key={mock.id}
              className="p-4 rounded-2xl border border-slate-200 bg-slate-50/60 hover:bg-white hover:border-red-300 hover:shadow-sm transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider ${
                    mock.isFullLength 
                      ? 'bg-red-100 text-red-800 border border-red-200' 
                      : 'bg-slate-200 text-slate-700'
                  }`}>
                    {mock.isFullLength ? 'Full Length Mock' : `${mock.questionCount} Questions`}
                  </span>

                  <span className="text-[11px] text-slate-500 font-bold flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5 text-slate-400" />
                    <span>{mock.timeLimitMinutes} {language === 'hi' ? 'मिनट' : 'mins'}</span>
                  </span>
                </div>

                <h4 className="font-extrabold text-sm text-slate-900 leading-snug">
                  {language === 'hi' ? mock.titleHindi : mock.title}
                </h4>
                <p className="text-xs text-slate-500 mt-1 line-clamp-2">
                  {mock.description}
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-200 flex items-center justify-between gap-2">
                <span className="text-[11px] font-semibold text-slate-600">
                  {language === 'hi' ? 'नेगेटिव मार्किंग:' : 'Negative:'}{' '}
                  <span className="font-mono font-bold text-red-700">-{mock.negativeMarking}</span>
                </span>

                <button
                  onClick={() => handleStartMockTemplate(mock)}
                  className="px-3.5 py-1.5 bg-red-700 hover:bg-red-800 text-white rounded-xl text-xs font-bold flex items-center gap-1 shadow-2xs transition-colors cursor-pointer"
                >
                  <Play className="w-3 h-3 fill-white" />
                  <span>{language === 'hi' ? 'टेस्ट दें' : 'Start Test'}</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Subject-Wise Progress Matrix (All 11 BPSC Subjects) */}
      <div className="bg-white rounded-3xl border border-slate-200 p-5 sm:p-6 shadow-xs space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-200">
          <div>
            <div className="flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-red-700" />
              <h3 className="font-black text-base sm:text-lg text-slate-900">
                {language === 'hi' ? 'विषयवार तैयारी एवं प्रगति (Subject Progress)' : 'Subject-wise Preparation'}
              </h3>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              {language === 'hi'
                ? 'BPSC 11 प्रमुख विषयों में आपका अभ्यास, प्रश्न बैंक और सटीकता'
                : 'Track questions practiced, question bank size, and accuracy per subject.'}
            </p>
          </div>

          <button
            onClick={() => onNavigateTab('practice')}
            className="text-xs font-bold text-red-700 hover:underline flex items-center gap-1"
          >
            <span>{language === 'hi' ? 'सभी विषय देखें' : 'View Subjects'}</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {subjectProgress.map((subj) => (
            <div
              key={subj.id}
              className="p-3.5 rounded-2xl border border-slate-200 bg-slate-50/50 hover:bg-white transition-all space-y-2"
            >
              <div className="flex items-center justify-between gap-2">
                <span className="font-bold text-xs text-slate-900 truncate">
                  {language === 'hi' ? subj.nameHindi : subj.nameEnglish}
                </span>
                <span className="px-1.5 py-0.2 rounded bg-slate-200 text-slate-700 text-[10px] font-bold shrink-0">
                  {subj.totalQuestionsInSubject} Qs
                </span>
              </div>

              {/* Progress bar */}
              <div>
                <div className="flex items-center justify-between text-[11px] text-slate-500 mb-1">
                  <span>{language === 'hi' ? 'सटीकता:' : 'Accuracy:'}</span>
                  <span className="font-bold text-emerald-700">{subj.accuracy}%</span>
                </div>
                <div className="w-full h-1.5 bg-slate-200 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-emerald-600 rounded-full transition-all"
                    style={{ width: `${subj.accuracy}%` }}
                  />
                </div>
              </div>

              <div className="pt-1 flex items-center justify-between">
                <span className="text-[10px] text-slate-400">
                  {subj.totalAttempted} {language === 'hi' ? 'हल किए' : 'solved'}
                </span>
                <button
                  onClick={() => onOpenConfigModal(subj.id)}
                  className="text-[11px] font-bold text-red-700 hover:underline"
                >
                  {language === 'hi' ? 'अभ्यास करें →' : 'Practice →'}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Recent Test History */}
      {testHistory.length > 0 && (
        <div className="bg-white rounded-3xl border border-slate-200 p-5 sm:p-6 shadow-xs space-y-3">
          <div className="flex items-center justify-between pb-3 border-b border-slate-200">
            <h3 className="font-black text-base text-slate-900 flex items-center gap-2">
              <Calendar className="w-4 h-4 text-slate-600" />
              <span>{language === 'hi' ? 'हालिया टेस्ट इतिहास (Recent Test Results)' : 'Recent Test History'}</span>
            </h3>
            <span className="text-xs text-slate-500 font-semibold">
              {testHistory.length} {language === 'hi' ? 'टेस्ट रिकॉर्ड' : 'records'}
            </span>
          </div>

          <div className="space-y-2.5">
            {testHistory.slice(0, 5).map((test) => (
              <div
                key={test.id}
                className="p-3.5 rounded-xl border border-slate-100 bg-slate-50/70 hover:bg-slate-50 flex items-center justify-between gap-3 text-xs"
              >
                <div>
                  <div className="font-bold text-slate-900">{test.testTitle}</div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    {new Date(test.completedAt).toLocaleDateString()} • {test.totalQuestions} {language === 'hi' ? 'प्रश्न' : 'Qs'} • {language === 'hi' ? 'नेगेटिव:' : 'Negative:'} -{test.negativeMarking}
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <div className="font-extrabold text-slate-900 text-sm">
                    {test.score} <span className="text-slate-400 text-xs">/ {test.maxScore}</span>
                  </div>
                  <span className="text-[11px] font-bold text-emerald-700">
                    {test.percentage}% {language === 'hi' ? 'सटीकता' : 'accuracy'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
