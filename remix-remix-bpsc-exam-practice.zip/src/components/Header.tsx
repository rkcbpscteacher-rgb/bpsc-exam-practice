import React from 'react';
import { useLanguage } from '../context/LanguageContext';
import { useUser } from '../context/UserContext';
import { useTest } from '../context/TestContext';
import { 
  GraduationCap, 
  Languages, 
  Flame, 
  Bookmark, 
  AlertCircle, 
  Database, 
  Home, 
  History,
  LogIn,
  LogOut,
  ShieldCheck,
  LayoutDashboard
} from 'lucide-react';

interface HeaderProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  openProfileModal: () => void;
  openAdminModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  setCurrentTab,
  openProfileModal,
  openAdminModal,
}) => {
  const { language, toggleLanguage, t } = useLanguage();
  const { 
    profile, 
    currentUser, 
    userRole, 
    isLoggedIn, 
    openLoginModal, 
    logout 
  } = useUser();
  const { activeTest } = useTest();

  // If in an active test, render a minimal focused header
  if (activeTest) {
    return (
      <header className="sticky top-0 z-30 bg-white border-b border-slate-200 shadow-xs">
        <div className="max-w-7xl mx-auto px-2.5 sm:px-4 h-14 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 min-w-0">
            <div className="w-8 h-8 rounded-lg bg-red-700 flex items-center justify-center text-white shadow-xs shrink-0">
              <GraduationCap className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <span className="font-bold text-slate-900 tracking-tight text-xs sm:text-base truncate block">
                {t('appName')}
              </span>
              <span className="hidden sm:inline-block text-[10px] font-medium text-red-700 bg-red-50 border border-red-200 px-1.5 py-0.2 rounded-full">
                BPSC 5-Option Mode
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={toggleLanguage}
              className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold rounded-md border border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-700 transition-colors shrink-0 cursor-pointer"
              title={t('switchLang')}
            >
              <Languages className="w-3.5 h-3.5 text-red-700 shrink-0" />
              <span>{language === 'hi' ? 'EN' : 'हिन्दी'}</span>
            </button>
          </div>
        </div>
      </header>
    );
  }

  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs">
      {/* Top Banner on Mobile/Desktop */}
      <div className="bg-slate-900 text-slate-100 text-xs py-1 px-4 text-center font-medium flex items-center justify-center gap-2">
        <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
        <span>{t('prelimsTarget')}</span>
        <span className="hidden md:inline text-slate-400">| 5-Option Pattern (A, B, C, D, E)</span>
        {isLoggedIn && (
          <span className="ml-2 px-2 py-0.2 rounded text-[10px] font-bold bg-white/10 text-slate-200">
            {userRole === 'admin' ? '🛡️ Admin Access' : '🎓 Student Portal'}
          </span>
        )}
      </div>

      <div className="max-w-7xl mx-auto px-2 sm:px-6 h-14 sm:h-16 flex items-center justify-between gap-1.5 sm:gap-2">
        {/* Logo and Brand */}
        <button
          onClick={() => setCurrentTab(userRole === 'admin' ? 'admin' : 'home')}
          className="flex items-center gap-1.5 sm:gap-3 text-left group focus:outline-hidden min-w-0 shrink cursor-pointer"
          title="BPSC TRE Exam Practice"
        >
          <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-tr from-red-800 to-amber-600 flex items-center justify-center text-white shadow-md shadow-red-900/10 group-hover:scale-105 transition-transform shrink-0">
            <GraduationCap className="w-4 h-4 sm:w-5 sm:h-5" />
          </div>
          <div className="min-w-0 flex flex-col justify-center">
            <div className="flex items-center gap-1 sm:gap-1.5">
              <span className="font-extrabold text-xs min-[380px]:text-sm sm:text-base md:text-lg text-slate-900 tracking-tight leading-none whitespace-nowrap">
                BPSC TRE
              </span>
              <span className="sm:hidden text-[10px] font-black text-red-700 bg-red-50 border border-red-200 px-1 py-0.2 rounded-sm leading-none whitespace-nowrap">
                {language === 'hi' ? 'अभ्यास' : 'Prep'}
              </span>
              <span className="hidden sm:inline font-extrabold text-base md:text-lg text-red-700 tracking-tight leading-none whitespace-nowrap">
                Exam Practice
              </span>
              <span className="hidden lg:inline text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded-sm bg-red-100 text-red-800">
                Official Prep
              </span>
            </div>
            <p className="hidden min-[360px]:block text-[9.5px] min-[390px]:text-[10px] sm:text-xs text-slate-500 font-medium truncate max-w-[125px] min-[390px]:max-w-[180px] sm:max-w-xs leading-tight mt-0.5">
              {language === 'hi' ? '5-विकल्प परीक्षा अभ्यास' : '5-Option Test Engine'}
            </p>
          </div>
        </button>

        {/* Desktop Navigation Links */}
        <nav className="hidden md:flex items-center gap-1 lg:gap-2">
          {/* Home / Student Dashboard */}
          <button
            onClick={() => setCurrentTab('home')}
            className={`px-3 py-1.5 rounded-lg text-sm font-semibold transition-colors flex items-center gap-1.5 ${
              currentTab === 'home'
                ? 'bg-red-50 text-red-800 border border-red-200'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <LayoutDashboard className="w-4 h-4" />
            <span>{language === 'hi' ? 'डैशबोर्ड' : 'Dashboard'}</span>
          </button>

          <button
            onClick={() => setCurrentTab('pyq')}
            className={`px-3 py-1.5 rounded-lg text-sm font-semibold transition-colors flex items-center gap-1.5 ${
              currentTab === 'pyq'
                ? 'bg-red-50 text-red-800 border border-red-200'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <History className="w-4 h-4" />
            <span>{t('navPYQ')}</span>
          </button>

          <button
            onClick={() => setCurrentTab('mistakes')}
            className={`px-3 py-1.5 rounded-lg text-sm font-semibold transition-colors flex items-center gap-1.5 relative ${
              currentTab === 'mistakes'
                ? 'bg-red-50 text-red-800 border border-red-200'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <AlertCircle className="w-4 h-4 text-amber-600" />
            <span>{t('navMistakes')}</span>
            {profile.incorrectQuestionIds.length > 0 && (
              <span className="w-5 h-5 rounded-full bg-amber-500 text-white text-[11px] font-bold flex items-center justify-center">
                {profile.incorrectQuestionIds.length}
              </span>
            )}
          </button>

          <button
            onClick={() => setCurrentTab('bookmarks')}
            className={`px-3 py-1.5 rounded-lg text-sm font-semibold transition-colors flex items-center gap-1.5 ${
              currentTab === 'bookmarks'
                ? 'bg-red-50 text-red-800 border border-red-200'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <Bookmark className="w-4 h-4 text-red-600" />
            <span>{t('navBookmarks')}</span>
            {profile.bookmarks.length > 0 && (
              <span className="text-xs px-1.5 py-0.2 rounded-full bg-slate-200 text-slate-700 font-bold">
                {profile.bookmarks.length}
              </span>
            )}
          </button>

          {/* Admin Dashboard / Question Bank Import */}
          <button
            onClick={() => setCurrentTab('admin')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 shadow-2xs ${
              currentTab === 'admin'
                ? 'bg-red-700 text-white shadow-xs'
                : userRole === 'admin'
                ? 'bg-red-100 text-red-900 border border-red-300'
                : 'text-slate-700 hover:text-slate-900 bg-red-50/80 hover:bg-red-100 border border-red-200'
            }`}
            title={language === 'hi' ? 'प्रशासक डैशबोर्ड व प्रश्न बैंक आयात' : 'Admin Assessment Dashboard & Question Bank'}
          >
            {userRole === 'admin' ? (
              <ShieldCheck className="w-3.5 h-3.5 text-red-600" />
            ) : (
              <Database className="w-3.5 h-3.5 text-red-600" />
            )}
            <span>
              {userRole === 'admin'
                ? (language === 'hi' ? 'प्रशासक डैशबोर्ड' : 'Admin Dashboard')
                : (language === 'hi' ? 'प्रश्न बैंक आयात' : 'Question Bank Import')}
            </span>
            <span className={`px-1.5 py-0.2 rounded-full text-[9px] font-black uppercase ${
              currentTab === 'admin' ? 'bg-red-900 text-red-100' : 'bg-red-200 text-red-900'
            }`}>
              {userRole === 'admin' ? 'ADMIN' : 'CSV/JSON'}
            </span>
          </button>
        </nav>

        {/* Right Action Buttons */}
        <div className="flex items-center gap-1 sm:gap-2 shrink-0">
          {/* Mobile Admin Question Bank / Quick Import Button */}
          <button
            onClick={() => setCurrentTab('admin')}
            className={`md:hidden px-2 py-1.5 rounded-lg border text-xs font-bold transition-all flex items-center gap-1 shadow-2xs shrink-0 cursor-pointer ${
              currentTab === 'admin'
                ? 'bg-red-700 text-white border-red-800'
                : 'bg-red-50 text-red-800 border-red-200 hover:bg-red-100'
            }`}
            title={language === 'hi' ? 'प्रश्न बैंक आयात' : 'Question Bank Import'}
            aria-label={userRole === 'admin' ? 'Admin' : 'Import'}
          >
            {userRole === 'admin' ? (
              <ShieldCheck className="w-3.5 h-3.5 shrink-0" />
            ) : (
              <Database className="w-3.5 h-3.5 shrink-0 text-red-700" />
            )}
            <span className="text-[11px] font-bold whitespace-nowrap">
              {userRole === 'admin' ? 'Admin' : (language === 'hi' ? 'आयात' : 'Import')}
            </span>
          </button>

          {/* Daily study streak badge (shown on sm+ screens) */}
          <button
            onClick={openProfileModal}
            className={`hidden sm:flex items-center gap-1.5 px-2.5 sm:px-3 py-1 rounded-full text-xs font-bold transition-all shadow-2xs border shrink-0 cursor-pointer ${
              profile.lastQuizCompletionDate === new Date().toISOString().split('T')[0]
                ? 'bg-amber-500 text-white border-amber-600 shadow-sm shadow-amber-500/30'
                : profile.studyStreakDays > 0
                ? 'bg-amber-50 text-amber-900 border-amber-300 hover:bg-amber-100'
                : 'bg-slate-100 text-slate-600 border-slate-200 hover:bg-slate-200'
            }`}
            title={
              profile.lastQuizCompletionDate === new Date().toISOString().split('T')[0]
                ? (language === 'hi' ? 'आज का क्विज पूरा हुआ! स्ट्रीक सक्रिय है' : 'Quiz completed today! Streak safe')
                : (language === 'hi' ? 'आज कम से कम 1 क्विज देकर स्ट्रीक बनाएं' : 'Complete at least 1 quiz today to keep streak')
            }
          >
            <Flame className={`w-3.5 h-3.5 shrink-0 ${
              profile.lastQuizCompletionDate === new Date().toISOString().split('T')[0]
                ? 'fill-white text-white'
                : 'fill-amber-500 text-amber-500'
            }`} />
            <span className="whitespace-nowrap">
              {profile.studyStreakDays} {language === 'hi' ? 'दिन' : 'd'}
            </span>
          </button>

          {/* Bilingual Language Switcher */}
          <button
            onClick={toggleLanguage}
            className="flex items-center gap-1 px-2 py-1.5 rounded-lg border border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-700 text-xs font-bold transition-all shadow-2xs shrink-0 cursor-pointer"
            title="Switch Language / भाषा बदलें"
            aria-label="Switch Language"
          >
            <Languages className="w-3.5 h-3.5 text-red-700 shrink-0" />
            <span className="font-bold text-[11px] sm:text-xs whitespace-nowrap">
              {language === 'hi' ? 'EN' : 'हिन्दी'}
            </span>
          </button>

          {/* Auth State Button */}
          {isLoggedIn ? (
            <div className="flex items-center gap-1 sm:gap-1.5 shrink-0">
              {/* User Identity / Role Pill */}
              <button
                onClick={openProfileModal}
                className="flex items-center gap-1 p-1 sm:px-2.5 sm:py-1 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-800 text-xs font-semibold shadow-2xs cursor-pointer shrink-0"
                title={currentUser?.email || profile.name}
              >
                <div className={`w-6 h-6 rounded-full flex items-center justify-center font-bold text-xs shrink-0 ${
                  userRole === 'admin'
                    ? 'bg-red-700 text-white'
                    : 'bg-blue-600 text-white'
                }`}>
                  {(currentUser?.name || profile.name || 'U').charAt(0).toUpperCase()}
                </div>
                <div className="hidden sm:block text-left">
                  <div className="font-bold text-slate-900 text-xs max-w-[90px] truncate leading-tight">
                    {currentUser?.name || profile.name}
                  </div>
                  <div className="text-[9px] font-bold uppercase tracking-wider text-slate-400">
                    {userRole === 'admin' ? 'Admin' : 'Student'}
                  </div>
                </div>
              </button>

              {/* Logout Button */}
              <button
                onClick={() => logout()}
                className="p-1.5 rounded-lg border border-slate-200 hover:bg-red-50 text-slate-500 hover:text-red-700 transition-colors shrink-0 cursor-pointer"
                title={language === 'hi' ? 'लॉगआउट' : 'Logout'}
                aria-label="Logout"
              >
                <LogOut className="w-3.5 h-3.5" />
              </button>
            </div>
          ) : (
            <button
              onClick={openLoginModal}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-red-700 hover:bg-red-800 text-white text-xs font-bold shadow-xs transition-all shrink-0 cursor-pointer"
              aria-label="Login"
            >
              <LogIn className="w-3.5 h-3.5 shrink-0" />
              <span className="text-[11px] sm:text-xs whitespace-nowrap">
                {language === 'hi' ? 'लॉगिन' : 'Login'}
              </span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};

