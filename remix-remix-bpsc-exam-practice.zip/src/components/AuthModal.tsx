import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { useUser } from '../context/UserContext';
import { 
  X, 
  LogIn, 
  UserPlus, 
  KeyRound, 
  Mail, 
  Lock, 
  User, 
  ShieldCheck, 
  Sparkles, 
  AlertCircle, 
  CheckCircle2, 
  ArrowRight,
  GraduationCap
} from 'lucide-react';

interface AuthModalProps {
  onLoginSuccess?: (role: 'student' | 'admin') => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ onLoginSuccess }) => {
  const { language } = useLanguage();
  const { 
    isAuthModalOpen, 
    setIsAuthModalOpen, 
    authModalMode, 
    setAuthModalMode, 
    login, 
    register, 
    loginDemo,
    forgotPassword,
    resetPassword
  } = useUser();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [targetExam, setTargetExam] = useState('71st BPSC Combined Competitive Prelims');

  // Forgot password states
  const [resetToken, setResetToken] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [resetMessage, setResetMessage] = useState<string | null>(null);

  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  if (!isAuthModalOpen) return null;

  const handleClose = () => {
    setError(null);
    setResetMessage(null);
    setIsAuthModalOpen(false);
  };

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const res = await login(email, password);
      if (res.success && res.user) {
        if (onLoginSuccess) {
          onLoginSuccess(res.user.role);
        }
        handleClose();
      } else {
        setError(res.error || (language === 'hi' ? 'लॉगिन विफल रहा।' : 'Login failed.'));
      }
    } finally {
      setLoading(false);
    }
  };

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const res = await register(name, email, password, targetExam);
      if (res.success && res.user) {
        if (onLoginSuccess) {
          onLoginSuccess(res.user.role);
        }
        handleClose();
      } else {
        setError(res.error || (language === 'hi' ? 'पंजीकरण विफल रहा।' : 'Registration failed.'));
      }
    } finally {
      setLoading(false);
    }
  };

  const handleForgotPasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const res = await forgotPassword(email);
      if (res.success) {
        setResetMessage(res.message);
        if (res.resetToken) {
          setResetToken(res.resetToken);
          setAuthModalMode('reset');
        }
      } else {
        setError(res.message || 'Error requesting reset.');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleResetPasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const res = await resetPassword(resetToken, newPassword);
      if (res.success) {
        setResetMessage(res.message);
        setTimeout(() => {
          setAuthModalMode('login');
          setResetMessage(null);
        }, 1500);
      } else {
        setError(res.message || 'Password reset failed.');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleQuickDemo = async (role: 'student' | 'admin') => {
    setLoading(true);
    setError(null);
    try {
      await loginDemo(role);
      if (onLoginSuccess) {
        onLoginSuccess(role);
      }
      handleClose();
    } catch (err: any) {
      setError(err?.message || 'Demo login failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-md overflow-hidden flex flex-col max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Header */}
        <div className="bg-gradient-to-r from-red-900 to-amber-900 text-white p-5 sm:p-6 relative">
          <button
            onClick={handleClose}
            className="absolute top-4 right-4 p-1.5 rounded-full text-white/80 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-white/15 backdrop-blur-md flex items-center justify-center text-amber-300 border border-white/20 shadow-md">
              <GraduationCap className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg sm:text-xl font-black">
                {authModalMode === 'login' && (language === 'hi' ? 'खाता लॉगिन करें' : 'Sign In to Account')}
                {authModalMode === 'register' && (language === 'hi' ? 'नया विद्यार्थी खाता बनाएं' : 'Student Registration')}
                {authModalMode === 'forgot' && (language === 'hi' ? 'पासवर्ड रीसेट करें' : 'Forgot Password')}
                {authModalMode === 'reset' && (language === 'hi' ? 'नया पासवर्ड दर्ज करें' : 'Set New Password')}
              </h3>
              <p className="text-xs text-red-200 mt-0.5">
                {language === 'hi'
                  ? 'BPSC 71वीं प्रारंभिक परीक्षा अभ्यास पोर्टल'
                  : 'BPSC Prelims Practice & Assessment Portal'}
              </p>
            </div>
          </div>
        </div>

        {/* Mode Selector Tabs (Login / Register) */}
        {authModalMode !== 'reset' && (
          <div className="flex border-b border-slate-200 bg-slate-50 px-4 pt-2">
            <button
              onClick={() => {
                setAuthModalMode('login');
                setError(null);
              }}
              className={`flex-1 py-2.5 text-xs sm:text-sm font-bold border-b-2 flex items-center justify-center gap-1.5 transition-colors ${
                authModalMode === 'login'
                  ? 'border-red-700 text-red-800 bg-white rounded-t-xl'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              <LogIn className="w-4 h-4" />
              <span>{language === 'hi' ? 'लॉगिन (Login)' : 'Sign In'}</span>
            </button>

            <button
              onClick={() => {
                setAuthModalMode('register');
                setError(null);
              }}
              className={`flex-1 py-2.5 text-xs sm:text-sm font-bold border-b-2 flex items-center justify-center gap-1.5 transition-colors ${
                authModalMode === 'register'
                  ? 'border-red-700 text-red-800 bg-white rounded-t-xl'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              <UserPlus className="w-4 h-4" />
              <span>{language === 'hi' ? 'नया पंजीकरण (Register)' : 'Register'}</span>
            </button>
          </div>
        )}

        <div className="p-5 sm:p-6 overflow-y-auto space-y-4 flex-1">
          {/* Quick Demo Mode Buttons Card */}
          <div className="bg-amber-50/70 border border-amber-200 rounded-2xl p-3.5 space-y-2">
            <div className="flex items-center gap-1.5 text-amber-900 text-xs font-black">
              <Sparkles className="w-3.5 h-3.5 text-amber-600" />
              <span>{language === 'hi' ? 'त्वरित 1-क्लिक डेमो मोड (Quick Demo Login):' : '1-Click Quick Demo Login:'}</span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => handleQuickDemo('student')}
                disabled={loading}
                className="py-2 px-2.5 bg-white hover:bg-slate-50 border border-amber-300 rounded-xl text-xs font-bold text-slate-800 flex items-center justify-center gap-1.5 shadow-2xs transition-all active:scale-98 cursor-pointer"
                title="Login as demo student"
              >
                <User className="w-3.5 h-3.5 text-red-700" />
                <span>{language === 'hi' ? 'विद्यार्थी डेमो' : 'Student Demo'}</span>
              </button>

              <button
                type="button"
                onClick={() => handleQuickDemo('admin')}
                disabled={loading}
                className="py-2 px-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-2xs transition-all active:scale-98 cursor-pointer"
                title="Login as demo admin"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                <span>{language === 'hi' ? 'प्रशासक (Admin)' : 'Admin Demo'}</span>
              </button>
            </div>
          </div>

          {/* Feedback & Error Notices */}
          {error && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-red-800 text-xs font-semibold flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {resetMessage && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-xs font-semibold flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{resetMessage}</span>
            </div>
          )}

          {/* LOGIN FORM */}
          {authModalMode === 'login' && (
            <form onSubmit={handleLoginSubmit} className="space-y-3.5">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {language === 'hi' ? 'ईमेल पता (Email)' : 'Email Address'}
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="student@bpsc.exam"
                    className="w-full pl-9 pr-3 py-2 text-xs sm:text-sm border border-slate-300 rounded-xl bg-white focus:outline-hidden focus:border-red-600 focus:ring-1 focus:ring-red-600"
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-bold text-slate-700">
                    {language === 'hi' ? 'पासवर्ड (Password)' : 'Password'}
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      setAuthModalMode('forgot');
                      setError(null);
                    }}
                    className="text-[11px] font-semibold text-red-700 hover:underline"
                  >
                    {language === 'hi' ? 'पासवर्ड भूल गए?' : 'Forgot Password?'}
                  </button>
                </div>
                <div className="relative">
                  <Lock className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-9 pr-3 py-2 text-xs sm:text-sm border border-slate-300 rounded-xl bg-white focus:outline-hidden focus:border-red-600 focus:ring-1 focus:ring-red-600"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-2.5 bg-red-700 hover:bg-red-800 disabled:bg-slate-300 text-white rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-1.5 shadow-md shadow-red-900/20 transition-all cursor-pointer"
              >
                <LogIn className="w-4 h-4" />
                <span>{loading ? (language === 'hi' ? 'सत्यापित हो रहा है...' : 'Signing In...') : (language === 'hi' ? 'लॉगिन करें' : 'Sign In')}</span>
              </button>
            </form>
          )}

          {/* REGISTRATION FORM */}
          {authModalMode === 'register' && (
            <form onSubmit={handleRegisterSubmit} className="space-y-3.5">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {language === 'hi' ? 'पूरा नाम (Full Name)' : 'Full Name'}
                </label>
                <div className="relative">
                  <User className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. राहुल कुमार"
                    className="w-full pl-9 pr-3 py-2 text-xs sm:text-sm border border-slate-300 rounded-xl bg-white focus:outline-hidden focus:border-red-600 focus:ring-1 focus:ring-red-600"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {language === 'hi' ? 'ईमेल पता (Email)' : 'Email Address'}
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="rahul@example.com"
                    className="w-full pl-9 pr-3 py-2 text-xs sm:text-sm border border-slate-300 rounded-xl bg-white focus:outline-hidden focus:border-red-600 focus:ring-1 focus:ring-red-600"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {language === 'hi' ? 'पासवर्ड (कम से कम 6 अक्षर)' : 'Password (min 6 characters)'}
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="password"
                    required
                    minLength={6}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-9 pr-3 py-2 text-xs sm:text-sm border border-slate-300 rounded-xl bg-white focus:outline-hidden focus:border-red-600 focus:ring-1 focus:ring-red-600"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {language === 'hi' ? 'लक्षित परीक्षा (Target Exam)' : 'Target Exam'}
                </label>
                <select
                  value={targetExam}
                  onChange={(e) => setTargetExam(e.target.value)}
                  className="w-full p-2 text-xs border border-slate-300 rounded-xl bg-white"
                >
                  <option value="71st BPSC Combined Competitive Prelims">71st BPSC Prelims 2025</option>
                  <option value="70th BPSC Mains & Interview">70th BPSC Mains</option>
                  <option value="BPSC Headmaster / Teacher Exam">BPSC Teacher TRE 4.0</option>
                  <option value="BPSC CDPO / Assistant Exam">BPSC CDPO / Other Posts</option>
                </select>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-2.5 bg-red-700 hover:bg-red-800 disabled:bg-slate-300 text-white rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-1.5 shadow-md shadow-red-900/20 transition-all cursor-pointer"
              >
                <UserPlus className="w-4 h-4" />
                <span>{loading ? (language === 'hi' ? 'खाता बन रहा है...' : 'Creating Account...') : (language === 'hi' ? 'पंजीकरण पूरा करें' : 'Create Student Account')}</span>
              </button>
            </form>
          )}

          {/* FORGOT PASSWORD FORM */}
          {authModalMode === 'forgot' && (
            <form onSubmit={handleForgotPasswordSubmit} className="space-y-3.5">
              <p className="text-xs text-slate-600">
                {language === 'hi'
                  ? 'अपना पंजीकृत ईमेल दर्ज करें। पासवर्ड रीसेट टोकन तुरंत प्राप्त करें:'
                  : 'Enter your registered email address to receive password reset instructions:'}
              </p>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {language === 'hi' ? 'ईमेल पता (Registered Email)' : 'Registered Email'}
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="your-email@example.com"
                    className="w-full pl-9 pr-3 py-2 text-xs sm:text-sm border border-slate-300 rounded-xl bg-white"
                  />
                </div>
              </div>

              <div className="flex items-center gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setAuthModalMode('login')}
                  className="px-3 py-2 border border-slate-300 rounded-xl text-xs font-bold text-slate-700 hover:bg-slate-50"
                >
                  {language === 'hi' ? 'वापस' : 'Back'}
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="flex-1 py-2 bg-red-700 hover:bg-red-800 disabled:bg-slate-300 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1"
                >
                  <KeyRound className="w-3.5 h-3.5" />
                  <span>{loading ? 'Processing...' : (language === 'hi' ? 'रीसेट टोकन प्राप्त करें' : 'Get Reset Token')}</span>
                </button>
              </div>
            </form>
          )}

          {/* RESET PASSWORD FORM */}
          {authModalMode === 'reset' && (
            <form onSubmit={handleResetPasswordSubmit} className="space-y-3.5">
              <p className="text-xs text-emerald-800 font-semibold">
                {language === 'hi'
                  ? 'सत्यापन टोकन जनरेट हो चुका है। कृपया नया पासवर्ड सेट करें:'
                  : 'Reset token generated. Set your new secure password:'}
              </p>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {language === 'hi' ? 'रीसेट टोकन (Reset Token)' : 'Reset Token'}
                </label>
                <input
                  type="text"
                  required
                  value={resetToken}
                  onChange={(e) => setResetToken(e.target.value)}
                  className="w-full p-2 text-xs font-mono border border-slate-300 rounded-xl bg-slate-50"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {language === 'hi' ? 'नया पासवर्ड (New Password)' : 'New Password'}
                </label>
                <input
                  type="password"
                  required
                  minLength={6}
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="Min 6 characters"
                  className="w-full p-2 text-xs sm:text-sm border border-slate-300 rounded-xl bg-white"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>{loading ? 'Updating...' : (language === 'hi' ? 'पासवर्ड अपडेट करें' : 'Update Password')}</span>
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
