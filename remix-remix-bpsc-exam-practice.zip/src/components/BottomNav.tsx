import React from 'react';
import { useLanguage } from '../context/LanguageContext';
import { useUser } from '../context/UserContext';
import { Home, BookOpenCheck, History, AlertCircle, Bookmark, Upload } from 'lucide-react';

interface BottomNavProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ currentTab, setCurrentTab }) => {
  const { language } = useLanguage();
  const { profile } = useUser();

  const navItems = [
    {
      id: 'home',
      label: language === 'hi' ? 'होम' : 'Home',
      title: language === 'hi' ? 'मुख्य पृष्ठ' : 'Home Dashboard',
      icon: Home,
      badge: null,
    },
    {
      id: 'practice',
      label: language === 'hi' ? 'विषय' : 'Subjects',
      title: language === 'hi' ? 'विषयवार अभ्यास' : 'Subject Practice',
      icon: BookOpenCheck,
      badge: null,
    },
    {
      id: 'pyq',
      label: 'PYQ',
      title: language === 'hi' ? 'पिछले वर्ष के प्रश्न' : 'Previous Year Papers',
      icon: History,
      badge: null,
    },
    {
      id: 'admin',
      label: language === 'hi' ? 'आयात' : 'Import',
      title: language === 'hi' ? 'प्रश्न बैंक आयात (CSV/JSON)' : 'Import Questions',
      icon: Upload,
      badge: 'CSV',
      badgeColor: 'bg-emerald-600 text-white',
    },
    {
      id: 'mistakes',
      label: language === 'hi' ? 'गलती' : 'Mistakes',
      title: language === 'hi' ? 'गलती सुधार डायरी' : 'Mistakes Revision',
      icon: AlertCircle,
      badge: profile.incorrectQuestionIds.length > 0 ? profile.incorrectQuestionIds.length : null,
      badgeColor: 'bg-amber-500 text-white',
    },
    {
      id: 'bookmarks',
      label: language === 'hi' ? 'बुकमार्क' : 'Saved',
      title: language === 'hi' ? 'बुकमार्क किए गए प्रश्न' : 'Bookmarked Questions',
      icon: Bookmark,
      badge: profile.bookmarks.length > 0 ? profile.bookmarks.length : null,
      badgeColor: 'bg-red-700 text-white',
    },
  ];

  return (
    <nav
      role="navigation"
      aria-label="Bottom Navigation"
      className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 shadow-lg touch-manipulation pb-[max(0.35rem,env(safe-area-inset-bottom))] w-full max-w-full overflow-hidden"
    >
      <div className="grid grid-cols-6 items-stretch w-full max-w-full px-0.5 pt-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentTab === item.id || (item.id === 'admin' && currentTab === 'import');

          return (
            <button
              key={item.id}
              onClick={() => setCurrentTab(item.id)}
              className={`min-h-[52px] flex flex-col items-center justify-center py-1 px-0.5 rounded-xl transition-all cursor-pointer relative min-w-0 ${
                isActive
                  ? 'text-red-700 font-bold bg-red-50/70 shadow-2xs'
                  : 'text-slate-500 hover:text-slate-800 active:bg-slate-100'
              }`}
              title={item.title}
              aria-label={item.label}
              aria-current={isActive ? 'page' : undefined}
            >
              <div className="relative flex items-center justify-center">
                <Icon
                  className={`w-5 h-5 shrink-0 ${
                    isActive ? 'text-red-700 stroke-[2.3]' : 'text-slate-500 stroke-[1.8]'
                  }`}
                />
                {item.badge !== null && item.badge !== undefined && (
                  <span
                    className={`absolute -top-1 -right-2.5 min-w-[14px] h-3.5 px-0.5 text-[8px] font-black rounded-full flex items-center justify-center leading-none shadow-2xs ${
                      item.badgeColor || 'bg-emerald-600 text-white'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </div>
              <span className="text-[10px] leading-tight mt-0.5 tracking-tight truncate max-w-full text-center px-0.5 block">
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
