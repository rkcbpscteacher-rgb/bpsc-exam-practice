import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { useUser } from '../context/UserContext';
import { 
  X, 
  User, 
  Trophy, 
  Flame, 
  Download, 
  Upload, 
  CheckCircle2, 
  LogOut, 
  LogIn, 
  Award,
  BookOpen,
  Calendar
} from 'lucide-react';

interface StudentProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const StudentProfileModal: React.FC<StudentProfileModalProps> = ({ isOpen, onClose }) => {
  const { t, language } = useLanguage();
  const { 
    profile, 
    overallStats, 
    testHistory, 
    isLoggedIn, 
    userEmail,
    currentUser,
    userRole,
    openLoginModal,
    updateProfileName, 
    updateTargetExam, 
    exportUserData, 
    importUserData, 
    logout 
  } = useUser();

  const [nameInput, setNameInput] = useState(profile.name);
  const [targetInput, setTargetInput] = useState(profile.targetExam);
  const [isSaved, setIsSaved] = useState(false);
  const [importStatus, setImportStatus] = useState<string | null>(null);

  if (!isOpen) return null;

  const targetExamOptions = [
    '71st BPSC Combined Competitive Prelims (CCE 2025-26)',
    '70th BPSC Mains & Prelims',
    'BPSC TRE 4.0 (Bihar Teacher Recruitment Examination)',
    'Bihar Police Sub Inspector (Daroga)',
    'BPSC CDPO (Child Development Project Officer)',
    'BPSC Assistant Engineer / Judicial Services',
  ];

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    if (nameInput.trim()) updateProfileName(nameInput.trim());
    if (targetInput.trim()) updateTargetExam(targetInput.trim());
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2000);
  };

  const handleExportData = () => {
    const jsonStr = exportUserData();
    const dataUri = 'data:application/json;charset=utf-8,' + encodeURIComponent(jsonStr);
    const downloadLink = document.createElement('a');
    downloadLink.setAttribute('href', dataUri);
    downloadLink.setAttribute('download', `bpsc_progress_${new Date().toISOString().split('T')[0]}.json`);
    document.body.appendChild(downloadLink);
    downloadLink.click();
    downloadLink.remove();
  };

  const handleImportFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      const content = evt.target?.result as string;
      const success = importUserData(content);
      if (success) {
        setImportStatus(language === 'hi' ? 'डेटा सफलतापूर्वक पुनर्स्थापित किया गया' : 'Progress restored successfully');
      } else {
        setImportStatus(language === 'hi' ? 'अमान्य बैकअप फाइल' : 'Invalid backup file format');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-auto animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="bg-gradient-to-r from-red-800 to-amber-700 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-white/10 border border-white/20 flex items-center justify-center text-white font-black text-lg">
              {profile.name.charAt(0) || 'U'}
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold leading-tight">
                {profile.name}
              </h2>
              <p className="text-xs text-amber-200">
                {profile.targetExam}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-red-200 hover:text-white hover:bg-white/10"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 sm:p-6 space-y-5 max-h-[75vh] overflow-y-auto">
          {/* Account Status / Login Section */}
          <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-between gap-2">
            <div>
              <div className="flex items-center gap-1.5">
                <span className={`w-2 h-2 rounded-full ${isLoggedIn ? 'bg-emerald-500' : 'bg-amber-500'}`}></span>
                <span className="text-xs font-bold text-slate-800">
                  {isLoggedIn 
                    ? `${userRole === 'admin' ? '🛡️ Administrator' : '🎓 BPSC Aspirant'}`
                    : (language === 'hi' ? 'अतिथि मोड (अस्थायी)' : 'Guest Mode (Offline)')}
                </span>
              </div>
              <p className="text-[11px] text-slate-500 mt-0.5 font-mono truncate max-w-[200px] sm:max-w-xs">
                {isLoggedIn ? (currentUser?.email || userEmail) : (language === 'hi' ? 'प्रगति सहेजने के लिए लॉगिन करें' : 'Login to sync progress')}
              </p>
            </div>

            {isLoggedIn ? (
              <button
                onClick={() => logout()}
                className="px-2.5 py-1 text-xs font-bold text-slate-600 hover:text-red-700 flex items-center gap-1 border border-slate-200 rounded-lg bg-white transition-colors"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>{language === 'hi' ? 'लॉगआउट' : 'Sign Out'}</span>
              </button>
            ) : (
              <button
                onClick={() => {
                  onClose();
                  openLoginModal();
                }}
                className="px-3 py-1.5 text-xs font-bold bg-red-700 hover:bg-red-800 text-white flex items-center gap-1.5 rounded-xl shadow-2xs"
              >
                <LogIn className="w-3.5 h-3.5" />
                <span>{language === 'hi' ? 'लॉगिन / साइन अप' : 'Login / Register'}</span>
              </button>
            )}
          </div>

          {/* Quick Stats overview */}
          <div className="grid grid-cols-4 gap-2 text-center">
            <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100">
              <div className="text-base sm:text-lg font-black text-slate-900">{overallStats.totalAttempted}</div>
              <div className="text-[10px] font-bold text-slate-500">{language === 'hi' ? 'कुल प्रश्न' : 'Attempted'}</div>
            </div>

            <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-100">
              <div className="text-base sm:text-lg font-black text-emerald-700">{overallStats.accuracy}%</div>
              <div className="text-[10px] font-bold text-emerald-800">{language === 'hi' ? 'सटीकता' : 'Accuracy'}</div>
            </div>

            <div className="p-2.5 rounded-xl bg-amber-50 border border-amber-100">
              <div className="text-base sm:text-lg font-black text-amber-600 flex items-center justify-center gap-0.5">
                <Flame className="w-3.5 h-3.5 fill-amber-500" />
                <span>{profile.studyStreakDays}</span>
              </div>
              <div className="text-[10px] font-bold text-amber-800">{language === 'hi' ? 'वर्तमान स्ट्रीक' : 'Current'}</div>
            </div>

            <div className="p-2.5 rounded-xl bg-orange-50 border border-orange-100">
              <div className="text-base sm:text-lg font-black text-orange-600 flex items-center justify-center gap-0.5">
                <Award className="w-3.5 h-3.5 text-orange-600" />
                <span>{profile.longestStreakDays || profile.studyStreakDays}</span>
              </div>
              <div className="text-[10px] font-bold text-orange-800">{language === 'hi' ? 'सर्वश्रेष्ठ स्ट्रीक' : 'Longest'}</div>
            </div>
          </div>

          {/* Streak Status Summary Card */}
          <div className="p-3 bg-amber-50/70 rounded-xl border border-amber-200 text-xs text-amber-950 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Flame className="w-4 h-4 fill-amber-500 text-amber-500 shrink-0" />
              <div>
                <span className="font-bold">
                  {profile.lastQuizCompletionDate === new Date().toISOString().split('T')[0]
                    ? (language === 'hi' ? 'आज का क्विज पूरा हुआ (Streak Active)' : 'Quiz Completed Today (Streak Active)')
                    : (language === 'hi' ? 'आज का क्विज लंबित है' : 'Daily Quiz Pending for Today')}
                </span>
                <span className="text-[11px] block opacity-80">
                  {profile.lastQuizCompletionDate
                    ? `${language === 'hi' ? 'पिछला पूर्ण अभ्यास:' : 'Last completed:'} ${profile.lastQuizCompletionDate}`
                    : (language === 'hi' ? 'अभी तक कोई क्विज पूर्ण नहीं हुआ' : 'No quiz completed yet')}
                </span>
              </div>
            </div>
            <span className="font-bold text-xs bg-white px-2 py-1 rounded-md border border-amber-200 shadow-2xs">
              {profile.completedQuizDates.length} {language === 'hi' ? 'सक्रिय दिन' : 'active days'}
            </span>
          </div>

          {/* Profile Edit Form */}
          <form onSubmit={handleSaveProfile} className="space-y-3 pt-2 border-t border-slate-100">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                {language === 'hi' ? 'अभ्यर्थी का नाम' : 'Candidate Name'}
              </label>
              <input
                type="text"
                value={nameInput}
                onChange={(e) => setNameInput(e.target.value)}
                className="w-full p-2 text-xs sm:text-sm border border-slate-300 rounded-xl font-medium"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                {language === 'hi' ? 'लक्ष्य परीक्षा' : 'Target Examination'}
              </label>
              <select
                value={targetInput}
                onChange={(e) => setTargetInput(e.target.value)}
                className="w-full p-2 text-xs border border-slate-300 rounded-xl bg-white font-medium"
              >
                {targetExamOptions.map((opt) => (
                  <option key={opt} value={opt}>
                    {opt}
                  </option>
                ))}
              </select>
            </div>

            <div className="flex justify-end pt-1">
              <button
                type="submit"
                className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition-colors"
              >
                {isSaved ? '✓ सहेज लिया गया!' : (language === 'hi' ? 'प्रोफाइल सहेजें' : 'Save Profile')}
              </button>
            </div>
          </form>

          {/* Backup / Restore Progress */}
          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
            <h4 className="text-xs font-bold text-slate-800">
              {language === 'hi' ? 'डेटा बैकअप एवं रिस्टोर' : 'Backup & Restore Progress'}
            </h4>
            <p className="text-[11px] text-slate-500">
              {language === 'hi' 
                ? 'अपनी परीक्षा प्रगति, बुकमार्क और टेस्ट हिस्ट्री को JSON फाइल में सुरक्षित करें या पुनर्स्थापित करें।'
                : 'Download all bookmarks and test logs or restore from a previous JSON backup.'}
            </p>

            <div className="flex items-center gap-2 pt-1">
              <button
                type="button"
                onClick={handleExportData}
                className="px-3 py-1.5 bg-white border border-slate-300 hover:bg-slate-100 rounded-lg text-xs font-bold text-slate-700 flex items-center gap-1.5 shadow-2xs"
              >
                <Download className="w-3.5 h-3.5" />
                <span>{language === 'hi' ? 'बैकअप डाउनलोड' : 'Download Backup'}</span>
              </button>

              <label className="px-3 py-1.5 bg-white border border-slate-300 hover:bg-slate-100 rounded-lg text-xs font-bold text-slate-700 flex items-center gap-1.5 shadow-2xs cursor-pointer">
                <Upload className="w-3.5 h-3.5" />
                <span>{language === 'hi' ? 'बैकअप रिस्टोर' : 'Restore Backup'}</span>
                <input
                  type="file"
                  accept=".json"
                  onChange={handleImportFile}
                  className="hidden"
                />
              </label>
            </div>

            {importStatus && (
              <p className="text-xs text-emerald-700 font-semibold pt-1">{importStatus}</p>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-50 border-t border-slate-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 text-white rounded-xl text-xs font-bold"
          >
            {language === 'hi' ? 'बंद करें' : 'Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
