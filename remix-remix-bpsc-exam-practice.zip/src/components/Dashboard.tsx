import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { useQuestions } from '../context/QuestionContext';
import { useUser } from '../context/UserContext';
import { useTest } from '../context/TestContext';
import { SubjectGrid } from './SubjectGrid';
import { 
  Sparkles, 
  Play, 
  SlidersHorizontal, 
  History, 
  AlertCircle, 
  Bookmark, 
  Flame, 
  HelpCircle, 
  CheckCircle2, 
  Search, 
  ArrowRight,
  ShieldCheck,
  RotateCcw,
  BookOpen,
  Calendar,
  Clock,
  Award,
  Database,
  Upload
} from 'lucide-react';

interface DashboardProps {
  onOpenConfigModal: (subjectId?: string) => void;
  onNavigateTab: (tab: string) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ onOpenConfigModal, onNavigateTab }) => {
  const { t, language } = useLanguage();
  const { questions } = useQuestions();
  const { 
    profile, 
    testHistory, 
    overallStats, 
    hasCompletedQuizToday, 
    streakStatus, 
    recentDaysActivity 
  } = useUser();
  const { startTest } = useTest();

  const [searchQuery, setSearchQuery] = useState('');

  // Daily Quiz Action
  const handleDailyQuiz = () => {
    startTest(
      {
        questionCount: 10,
        subjects: [],
        mode: 'exam',
        negativeMarking: 0.25,
        timeLimitMinutes: 12, // 12 mins for 10 questions
        shuffleQuestions: true,
        shuffleOptions: true,
      },
      questions,
      `${language === 'hi' ? 'दैनिक 10-प्रश्न चैलेंज' : 'Daily 10-MCQ Challenge'}`
    );
  };

  // Full Mock Test Action
  const handleFullMockTest = () => {
    onOpenConfigModal();
  };

  const handleSubjectClick = (subjectId: string, directStart = false) => {
    if (directStart) {
      const subjectPool = questions.filter((q) => q.subjectId === subjectId);
      startTest(
        {
          questionCount: Math.min(10, subjectPool.length),
          subjects: [subjectId],
          mode: 'practice',
          negativeMarking: 0,
          timeLimitMinutes: 0,
          shuffleQuestions: true,
          shuffleOptions: false,
        },
        subjectPool,
        `${language === 'hi' ? 'त्वरित विषय अभ्यास' : 'Subject Practice'}`
      );
    } else {
      onOpenConfigModal(subjectId);
    }
  };

  // Filtered search preview
  const searchResults = searchQuery.trim()
    ? questions.filter(
        (q) =>
          q.questionHindi.toLowerCase().includes(searchQuery.toLowerCase()) ||
          q.questionEnglish.toLowerCase().includes(searchQuery.toLowerCase()) ||
          q.topic.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : [];

  return (
    <div className="space-y-6 sm:space-y-8 pb-10">
      {/* Search Bar */}
      <div className="relative">
        <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder={t('searchPlaceholder')}
          className="w-full pl-10 pr-4 py-2.5 sm:py-3 bg-white border border-slate-200 rounded-2xl text-xs sm:text-sm text-slate-800 placeholder-slate-400 focus:outline-hidden focus:border-red-600 focus:ring-1 focus:ring-red-600 shadow-2xs transition-all"
        />
        {searchQuery && (
          <button
            onClick={() => setSearchQuery('')}
            className="absolute right-3.5 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400 hover:text-slate-600"
          >
            Clear
          </button>
        )}
      </div>

      {/* Search results popup if searching */}
      {searchQuery.trim() && (
        <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-md space-y-2">
          <div className="text-xs font-bold text-slate-500 mb-2">
            {language === 'hi' 
              ? `"${searchQuery}" के लिए ${searchResults.length} प्रश्न मिले:`
              : `Found ${searchResults.length} matching questions:`}
          </div>
          {searchResults.length === 0 ? (
            <p className="text-xs text-slate-400 py-3 text-center">
              {language === 'hi' ? 'कोई प्रश्न नहीं मिला' : 'No matching questions found.'}
            </p>
          ) : (
            <div className="space-y-2 max-h-60 overflow-y-auto">
              {searchResults.slice(0, 5).map((q) => (
                <div
                  key={q.id}
                  onClick={() => {
                    startTest(
                      {
                        questionCount: 1,
                        subjects: [q.subjectId],
                        mode: 'practice',
                        negativeMarking: 0,
                        timeLimitMinutes: 0,
                        shuffleQuestions: false,
                        shuffleOptions: false,
                      },
                      [q],
                      q.topic
                    );
                  }}
                  className="p-2.5 rounded-xl border border-slate-100 hover:bg-red-50 hover:border-red-200 transition-colors cursor-pointer text-left"
                >
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-100 text-slate-700">
                    {q.topic}
                  </span>
                  <p className="text-xs font-semibold text-slate-800 mt-1 line-clamp-1">
                    {q.questionHindi}
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Quick Action Bar for Question Bank Import */}
      <div className="bg-white border-2 border-red-200 hover:border-red-400 rounded-2xl p-3.5 sm:p-4 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 transition-colors">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-red-700 text-white flex items-center justify-center font-bold text-sm shadow-xs shrink-0">
            <Upload className="w-5 h-5 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-extrabold text-sm sm:text-base text-slate-900">
                {language === 'hi' ? 'प्रश्न बैंक आयात (Question Bank Import)' : 'Question Bank Import'}
              </h3>
              <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-extrabold border border-emerald-300">
                CSV / JSON
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              {language === 'hi'
                ? 'CSV या JSON द्वारा थोक प्रश्न अपलोड करें। 5-विकल्प (A-E) सत्यापन, पूर्वावलोकन व डुप्लिकेट जांच उपलब्ध है।'
                : 'Upload questions via CSV or JSON with instant preview, 5-option validation, and duplicate detection.'}
            </p>
          </div>
        </div>

        <button
          onClick={() => onNavigateTab('admin')}
          className="px-4 py-2.5 bg-red-700 hover:bg-red-800 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-sm shrink-0 w-full sm:w-auto justify-center transition-all cursor-pointer"
        >
          <Upload className="w-4 h-4 text-amber-300" />
          <span>{language === 'hi' ? 'Question Bank Import खोलें' : 'Open Question Bank Import'}</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Hero Card */}
      <div className="relative rounded-3xl bg-gradient-to-br from-red-900 via-red-800 to-amber-800 text-white p-5 sm:p-8 shadow-xl overflow-hidden">
        {/* Decorative background glow */}
        <div className="absolute -right-10 -bottom-10 w-64 h-64 rounded-full bg-amber-500/15 blur-3xl pointer-events-none" />
        <div className="absolute -left-10 -top-10 w-64 h-64 rounded-full bg-red-600/30 blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-2xl space-y-3 sm:space-y-4">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md border border-white/20 text-xs font-bold text-amber-200">
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>{language === 'hi' ? 'बीपीएससी 71वीं प्रारंभिक परीक्षा स्पेशल' : '71st BPSC CCE Target'}</span>
          </div>

          <h2 className="text-xl sm:text-3xl font-black tracking-tight leading-tight">
            {t('heroTitle')}
          </h2>

          <p className="text-xs sm:text-sm text-red-100/90 leading-relaxed max-w-xl">
            {t('heroSubtitle')}
          </p>

          <div className="pt-2 flex flex-wrap items-center gap-2.5 sm:gap-3">
            <button
              onClick={handleDailyQuiz}
              className="w-full sm:w-auto px-5 py-3 sm:py-3 bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold rounded-xl text-xs sm:text-sm shadow-md shadow-amber-950/20 flex items-center justify-center gap-2 transition-all active:scale-98 cursor-pointer min-h-[44px]"
            >
              <Play className="w-4 h-4 fill-slate-950" />
              <span>{t('startQuickQuiz')}</span>
            </button>

            <button
              onClick={handleFullMockTest}
              className="flex-1 sm:flex-none px-4 py-2.5 sm:py-3 bg-white/10 hover:bg-white/20 backdrop-blur-md text-white font-bold rounded-xl text-xs sm:text-sm border border-white/20 flex items-center justify-center gap-2 transition-all cursor-pointer min-h-[44px]"
            >
              <SlidersHorizontal className="w-4 h-4" />
              <span>{t('customTest')}</span>
            </button>

            <button
              onClick={() => onNavigateTab('admin')}
              className="flex-1 sm:flex-none px-4 py-2.5 sm:py-3 bg-red-700/80 hover:bg-red-700 text-white font-bold rounded-xl text-xs sm:text-sm border border-red-500/50 flex items-center justify-center gap-2 transition-all shadow-xs cursor-pointer min-h-[44px]"
              title="Open Question Bank Import (CSV/JSON)"
            >
              <Upload className="w-4 h-4 text-amber-300" />
              <span>{language === 'hi' ? 'प्रश्न बैंक आयात (CSV/JSON)' : 'Import Questions (CSV/JSON)'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Daily Streak Tracking System Card */}
      <div className="bg-gradient-to-r from-amber-50 via-orange-50 to-amber-100/60 rounded-3xl border border-amber-200/90 p-4 sm:p-6 shadow-xs">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 pb-4 border-b border-amber-200/60">
          <div className="flex items-center gap-3.5">
            <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shadow-md transition-transform ${
              hasCompletedQuizToday 
                ? 'bg-amber-500 text-white shadow-amber-500/30 scale-105' 
                : profile.studyStreakDays > 0 
                ? 'bg-amber-100 text-amber-700 border border-amber-300' 
                : 'bg-slate-200 text-slate-600'
            }`}>
              <Flame className={`w-7 h-7 ${hasCompletedQuizToday ? 'fill-white text-white' : 'fill-amber-500 text-amber-500'}`} />
            </div>

            <div>
              <div className="flex items-center gap-2">
                <span className="text-xl sm:text-2xl font-black text-amber-950">
                  {profile.studyStreakDays} {language === 'hi' ? 'दिन की लगातार स्ट्रीक' : 'Days Streak'}
                </span>
                {hasCompletedQuizToday && (
                  <span className="px-2 py-0.5 rounded-full bg-emerald-600 text-white text-[10px] font-extrabold flex items-center gap-1 shadow-2xs">
                    <CheckCircle2 className="w-3 h-3" />
                    <span>{language === 'hi' ? 'आज पूर्ण' : 'Done Today'}</span>
                  </span>
                )}
              </div>
              <p className="text-xs text-amber-800/90 font-medium mt-0.5">
                {hasCompletedQuizToday
                  ? (language === 'hi' ? 'शाबाश! आपने आज का अभ्यास क्विज पूरा कर लिया है।' : 'Great job! You completed a practice quiz today.')
                  : profile.studyStreakDays > 0
                  ? (language === 'hi' ? 'अपनी लगातार स्ट्रीक बनाए रखने के लिए आज कम से कम 1 क्विज पूरा करें।' : 'Complete at least 1 practice quiz today to keep your streak alive.')
                  : (language === 'hi' ? 'आज पहला क्विज हल करें और अपनी 1 दिन की दैनिक स्ट्रीक शुरू करें!' : 'Complete your first practice quiz today to start a 1-day streak!')}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0 w-full sm:w-auto">
            <div className="px-3 py-1.5 rounded-xl bg-white/80 border border-amber-200 text-xs text-amber-900 font-bold flex items-center gap-1.5 shadow-2xs">
              <Award className="w-4 h-4 text-amber-600" />
              <span>
                {language === 'hi' ? 'सर्वश्रेष्ठ रिकॉर्ड:' : 'Best Streak:'} {profile.longestStreakDays || profile.studyStreakDays} {language === 'hi' ? 'दिन' : 'days'}
              </span>
            </div>

            {!hasCompletedQuizToday && (
              <button
                onClick={handleDailyQuiz}
                className="px-4 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold shadow-md shadow-amber-600/20 flex items-center gap-1 transition-all"
              >
                <Play className="w-3.5 h-3.5 fill-white" />
                <span>{language === 'hi' ? 'आज का क्विज दें' : 'Take Daily Quiz'}</span>
              </button>
            )}
          </div>
        </div>

        {/* 7-Day Activity Calendar Visualizer */}
        <div className="pt-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold text-amber-900 uppercase tracking-wider">
              {language === 'hi' ? 'विगत 7 दिनों की क्विज गतिविधि (7-Day Streak History):' : '7-Day Practice Quiz Activity:'}
            </span>
            <span className="text-[11px] text-amber-800 font-medium">
              {profile.completedQuizDates.length} {language === 'hi' ? 'सक्रिय अध्ययन दिन' : 'active days'}
            </span>
          </div>

          <div className="grid grid-cols-7 gap-1.5 sm:gap-2">
            {recentDaysActivity.map((day) => (
              <div
                key={day.date}
                className={`flex flex-col items-center justify-center p-2 rounded-xl border text-center transition-all ${
                  day.isCompleted
                    ? 'bg-amber-500 text-white border-amber-600 shadow-2xs'
                    : day.isToday
                    ? 'bg-white border-amber-400 ring-2 ring-amber-400 text-amber-900 font-bold'
                    : 'bg-white/60 border-amber-200/70 text-slate-500'
                }`}
              >
                <span className="text-[10px] font-medium leading-none opacity-90 mb-1">
                  {day.dayName}
                </span>

                <div className="w-6 h-6 rounded-full flex items-center justify-center font-bold text-xs">
                  {day.isCompleted ? (
                    <CheckCircle2 className="w-4 h-4 fill-white text-amber-500" />
                  ) : day.isToday ? (
                    <Flame className="w-4 h-4 text-amber-500 animate-pulse" />
                  ) : (
                    <span className="text-[11px] opacity-60">{day.dayNumber}</span>
                  )}
                </div>

                <span className="text-[9px] font-bold mt-1 leading-none">
                  {day.isCompleted
                    ? (language === 'hi' ? 'पूर्ण' : 'Done')
                    : day.isToday
                    ? (language === 'hi' ? 'आज' : 'Today')
                    : '—'}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Quick Stats Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-2xs">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-xs font-semibold text-slate-500">{t('statQuestions')}</span>
            <BookOpen className="w-4 h-4 text-slate-400" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-slate-900">{questions.length}</div>
          <div className="text-[10px] text-slate-400 mt-0.5">
            {questions.filter((q) => q.isPYQ).length} {language === 'hi' ? 'BPSC PYQ सहित' : 'with PYQs'}
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-2xs">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-xs font-semibold text-slate-500">{t('statAttempted')}</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-slate-900">{overallStats.totalAttempted}</div>
          <div className="text-[10px] text-slate-400 mt-0.5">
            {profile.testsCompleted} {language === 'hi' ? 'टेस्ट पूर्ण' : 'tests completed'}
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-2xs">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-xs font-semibold text-slate-500">{t('statAccuracy')}</span>
            <ShieldCheck className="w-4 h-4 text-blue-500" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-slate-900">{overallStats.accuracy}%</div>
          <div className="text-[10px] text-slate-400 mt-0.5">
            {overallStats.totalCorrect} {language === 'hi' ? 'सटीक उत्तर' : 'correct answers'}
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-2xs">
          <div className="flex items-center justify-between text-amber-500 mb-1">
            <span className="text-xs font-semibold text-slate-500">{t('statStreak')}</span>
            <Flame className="w-4 h-4 fill-amber-500" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-amber-600 flex items-baseline gap-1.5">
            <span>{profile.studyStreakDays}</span>
            <span className="text-xs font-bold text-amber-800">
              {language === 'hi' ? 'दिन' : 'days'}
            </span>
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5">
            {hasCompletedQuizToday 
              ? (language === 'hi' ? 'आज सक्रिय ✓' : 'Active today ✓')
              : (language === 'hi' ? 'आज क्विज लंबित ⚡' : 'Pending today ⚡')}
          </div>
        </div>
      </div>

      {/* Feature Tiles: PYQ, Mistakes, Bookmarks */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {/* PYQ Card */}
        <div
          onClick={() => onNavigateTab('pyq')}
          className="bg-gradient-to-br from-emerald-50 to-teal-50 border border-emerald-200/80 rounded-2xl p-4 hover:shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-2">
            <div className="w-9 h-9 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold text-xs shadow-2xs">
              <History className="w-5 h-5" />
            </div>
            <span className="text-xs font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded-md">
              64th - 69th BPSC
            </span>
          </div>
          <h3 className="font-extrabold text-sm sm:text-base text-slate-900 group-hover:text-emerald-800 transition-colors">
            {t('navPYQ')}
          </h3>
          <p className="text-xs text-slate-600 mt-1 line-clamp-2">
            {language === 'hi' 
              ? 'आधिकारिक BPSC प्रारंभिक परीक्षाओं के विगत वर्षों के प्रश्न 5-विकल्प प्रारूप में।'
              : 'Official BPSC previous papers formatted in standard 5-option design.'}
          </p>
        </div>

        {/* Mistakes Revision Card */}
        <div
          onClick={() => onNavigateTab('mistakes')}
          className="bg-gradient-to-br from-amber-50 to-orange-50 border border-amber-200/80 rounded-2xl p-4 hover:shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-2">
            <div className="w-9 h-9 rounded-xl bg-amber-600 text-white flex items-center justify-center font-bold text-xs shadow-2xs">
              <AlertCircle className="w-5 h-5" />
            </div>
            {profile.incorrectQuestionIds.length > 0 ? (
              <span className="text-xs font-bold text-amber-900 bg-amber-200 px-2 py-0.5 rounded-full">
                {profile.incorrectQuestionIds.length} {language === 'hi' ? 'गलत प्रश्न' : 'mistakes'}
              </span>
            ) : (
              <span className="text-xs font-semibold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-md">
                0 {language === 'hi' ? 'पेंडिंग' : 'pending'}
              </span>
            )}
          </div>
          <h3 className="font-extrabold text-sm sm:text-base text-slate-900 group-hover:text-amber-800 transition-colors">
            {language === 'hi' ? 'गलती सुधार डायरी' : 'Mistakes Revision'}
          </h3>
          <p className="text-xs text-slate-600 mt-1 line-clamp-2">
            {language === 'hi' 
              ? 'टेस्ट में गलत हुए प्रश्नों का पुनः अभ्यास करें ताकि परीक्षा में दोबारा गलती न हो।'
              : 'Targeted drill of questions you missed previously to achieve 100% mastery.'}
          </p>
        </div>

        {/* Bookmarks Card */}
        <div
          onClick={() => onNavigateTab('bookmarks')}
          className="bg-gradient-to-br from-red-50 to-rose-50 border border-red-200/80 rounded-2xl p-4 hover:shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-2">
            <div className="w-9 h-9 rounded-xl bg-red-700 text-white flex items-center justify-center font-bold text-xs shadow-2xs">
              <Bookmark className="w-5 h-5" />
            </div>
            <span className="text-xs font-bold text-red-800 bg-red-100 px-2 py-0.5 rounded-md">
              {profile.bookmarks.length} {language === 'hi' ? 'सहेजे गए' : 'saved'}
            </span>
          </div>
          <h3 className="font-extrabold text-sm sm:text-base text-slate-900 group-hover:text-red-800 transition-colors">
            {t('navBookmarks')}
          </h3>
          <p className="text-xs text-slate-600 mt-1 line-clamp-2">
            {language === 'hi' 
              ? 'महत्वपूर्ण प्रश्न और अपने व्यक्तिगत अध्ययन नोट्स एक स्थान पर देखें।'
              : 'Saved high-yield questions with personal revision annotations.'}
          </p>
        </div>
      </div>

      {/* Admin Question Bank & Bulk Import Quick Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-red-950 text-white rounded-2xl p-4 sm:p-5 shadow-sm border border-slate-700 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-red-700 text-white flex items-center justify-center font-bold text-sm shadow-xs shrink-0">
            <Database className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-extrabold text-sm sm:text-base">
                {language === 'hi' ? 'प्रशासनिक प्रश्न बैंक एवं थोक आयात' : 'Admin Question Bank & Bulk Import'}
              </h3>
              <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-extrabold border border-emerald-500/30">
                CSV & JSON
              </span>
            </div>
            <p className="text-xs text-slate-300 mt-0.5">
              {language === 'hi'
                ? 'CSV/JSON से थोक प्रश्न आयात करें, नमूना टेम्पलेट डाउनलोड करें और 5-विकल्प मानक सत्यापित करें।'
                : 'Bulk import questions via CSV/JSON, download sample templates, and validate 5 options.'}
            </p>
          </div>
        </div>

        <button
          onClick={() => onNavigateTab('admin')}
          className="px-4 py-2 bg-red-700 hover:bg-red-800 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-sm shrink-0 w-full sm:w-auto justify-center transition-all cursor-pointer"
        >
          <Upload className="w-3.5 h-3.5" />
          <span>{language === 'hi' ? 'प्रश्न बैंक एवं आयात खोलें' : 'Open Import & Question Bank'}</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* 11 Subject Cards Section */}
      <SubjectGrid onSelectSubject={handleSubjectClick} />

      {/* Recent Test History */}
      {testHistory.length > 0 && (
        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-extrabold text-sm sm:text-base text-slate-900 flex items-center gap-2">
              <Calendar className="w-4 h-4 text-slate-500" />
              <span>{language === 'hi' ? 'हालिया टेस्ट इतिहास' : 'Recent Test Attempts'}</span>
            </h3>
            <span className="text-xs text-slate-400 font-medium">
              {testHistory.length} {language === 'hi' ? 'टेस्ट दिए गए' : 'recorded'}
            </span>
          </div>

          <div className="space-y-2.5">
            {testHistory.slice(0, 3).map((item) => (
              <div
                key={item.id}
                className="p-3 rounded-xl border border-slate-100 bg-slate-50/70 flex items-center justify-between gap-3 text-xs"
              >
                <div>
                  <div className="font-bold text-slate-900">{item.testTitle}</div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    {new Date(item.completedAt).toLocaleDateString()} • {item.totalQuestions} {language === 'hi' ? 'प्रश्न' : 'Q'}
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <span className="font-extrabold text-slate-900 text-sm">{item.score}</span>
                    <span className="text-slate-400 text-[10px]"> / {item.maxScore}</span>
                    <span className="block font-semibold text-emerald-700 text-[10px]">
                      {item.percentage}%
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
