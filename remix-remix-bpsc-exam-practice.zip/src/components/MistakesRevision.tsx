import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { useQuestions } from '../context/QuestionContext';
import { useUser } from '../context/UserContext';
import { useTest } from '../context/TestContext';
import { OptionKey } from '../types';
import { 
  AlertCircle, 
  RotateCcw, 
  CheckCircle2, 
  Trash2, 
  BookOpen, 
  Play, 
  Sparkles,
  FileText
} from 'lucide-react';

export const MistakesRevision: React.FC = () => {
  const { t, language } = useLanguage();
  const { questions } = useQuestions();
  const { profile, removeMistake, clearMistakes } = useUser();
  const { startTest } = useTest();

  const [expandedSolutions, setExpandedSolutions] = useState<Record<string, boolean>>({});

  // Find question objects matching incorrect IDs
  const mistakeQuestions = profile.incorrectQuestionIds
    .map((id) => questions.find((q) => q.id === id))
    .filter((q): q is NonNullable<typeof q> => !!q);

  const handleRetestAll = () => {
    if (mistakeQuestions.length === 0) return;
    startTest(
      {
        questionCount: mistakeQuestions.length,
        subjects: [],
        mode: 'practice',
        negativeMarking: 0.25,
        timeLimitMinutes: 0,
        shuffleQuestions: true,
        shuffleOptions: false,
      },
      mistakeQuestions,
      `${language === 'hi' ? 'गलती सुधार टेस्ट (Mistake Drill)' : 'Mistake Revision Drill'}`
    );
  };

  const toggleSolution = (id: string) => {
    setExpandedSolutions((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const optionLetters: OptionKey[] = ['A', 'B', 'C', 'D', 'E'];

  return (
    <div className="space-y-6 pb-12">
      {/* Banner */}
      <div className="bg-gradient-to-r from-amber-700 to-orange-700 text-white rounded-3xl p-5 sm:p-7 shadow-lg flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/10 text-amber-100 text-xs font-bold mb-2">
            <AlertCircle className="w-3.5 h-3.5 text-amber-200" />
            <span>{language === 'hi' ? 'रिवीजन नोटबुक' : 'Weak Area Revision'}</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black">
            {t('mistakeNotebookTitle')}
          </h2>
          <p className="text-xs sm:text-sm text-amber-100 max-w-xl mt-1">
            {t('mistakeNotebookSubtitle')}
          </p>
        </div>

        {mistakeQuestions.length > 0 && (
          <div className="flex items-center gap-2">
            <button
              onClick={handleRetestAll}
              className="px-5 py-2.5 bg-white hover:bg-amber-50 text-amber-900 font-extrabold rounded-xl text-xs sm:text-sm shadow-md flex items-center gap-2 transition-all active:scale-98"
            >
              <RotateCcw className="w-4 h-4 text-amber-700" />
              <span>{t('practiceAllMistakes')} ({mistakeQuestions.length})</span>
            </button>
          </div>
        )}
      </div>

      {/* Main Content */}
      {mistakeQuestions.length === 0 ? (
        <div className="bg-white rounded-3xl border border-slate-200 p-8 sm:p-12 text-center max-w-md mx-auto shadow-xs">
          <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 mx-auto flex items-center justify-center mb-4">
            <CheckCircle2 className="w-8 h-8" />
          </div>
          <h3 className="font-extrabold text-base sm:text-lg text-slate-900 mb-2">
            {language === 'hi' ? 'कोई गलत प्रश्न लंबित नहीं!' : 'No Mistakes Pending!'}
          </h3>
          <p className="text-xs sm:text-sm text-slate-500 leading-relaxed">
            {t('noMistakes')}
          </p>
          <p className="text-xs text-slate-400 mt-2">
            {language === 'hi' 
              ? 'जब आप मॉक टेस्ट देंगे, तो जिन प्रश्नों के गलत उत्तर होंगे वे स्वतः यहाँ जुड़ जाएंगे।'
              : 'Whenever you take a test, any incorrect answers will be collected here for practice.'}
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          <div className="flex items-center justify-between px-1">
            <span className="text-xs font-bold text-slate-600">
              {mistakeQuestions.length} {language === 'hi' ? 'प्रश्नों में सुधार अपेक्षित' : 'questions to revise'}
            </span>
            <button
              onClick={clearMistakes}
              className="text-xs font-semibold text-red-700 hover:text-red-800 flex items-center gap-1 hover:underline"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>{language === 'hi' ? 'सभी गलतियां साफ़ करें' : 'Clear All Mistakes'}</span>
            </button>
          </div>

          {mistakeQuestions.map((q, idx) => {
            const isExpanded = expandedSolutions[q.id];

            return (
              <div
                key={q.id}
                className="bg-white rounded-2xl border border-amber-200/80 p-4 sm:p-5 shadow-2xs space-y-3"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-amber-500 text-white text-xs font-bold flex items-center justify-center shrink-0">
                      {idx + 1}
                    </span>
                    <span className="text-xs font-bold px-2 py-0.5 rounded-md bg-amber-50 text-amber-800 border border-amber-200">
                      {q.topic}
                    </span>
                  </div>

                  <button
                    onClick={() => removeMistake(q.id)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-red-700 hover:bg-slate-50 transition-colors"
                    title="Remove from Mistakes"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>

                {/* Question */}
                <p className="font-bold text-slate-900 text-sm sm:text-base leading-relaxed">
                  {q.questionHindi}
                </p>
                {q.questionEnglish && (
                  <p className="text-xs text-slate-500 italic">
                    {q.questionEnglish}
                  </p>
                )}

                {/* 5 Options */}
                <div className="space-y-1.5 pt-1">
                  {optionLetters.map((letter, optIdx) => {
                    const optHindi = q.optionsHindi[optIdx];
                    const isCorrect = letter === q.correctAnswer;

                    return (
                      <div
                        key={letter}
                        className={`p-2.5 rounded-xl border text-xs sm:text-sm flex items-start gap-2.5 ${
                          isExpanded && isCorrect
                            ? 'bg-emerald-50 border-emerald-400 text-emerald-950 font-semibold'
                            : 'bg-slate-50 border-slate-200 text-slate-700'
                        }`}
                      >
                        <span
                          className={`w-5 h-5 rounded border font-bold text-[11px] flex items-center justify-center shrink-0 mt-0.5 ${
                            isExpanded && isCorrect
                              ? 'bg-emerald-600 text-white border-emerald-600'
                              : 'bg-white text-slate-700 border-slate-300'
                          }`}
                        >
                          {letter}
                        </span>
                        <span className="flex-1 min-w-0 break-words font-devanagari">{optHindi}</span>
                        {isExpanded && isCorrect && (
                          <span className="text-[11px] font-bold text-emerald-700 shrink-0">
                            ✓ सही उत्तर
                          </span>
                        )}
                      </div>
                    );
                  })}
                </div>

                {/* Bottom actions */}
                <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                  <button
                    type="button"
                    onClick={() => toggleSolution(q.id)}
                    className="text-xs font-bold text-amber-800 hover:text-amber-900 flex items-center gap-1"
                  >
                    <FileText className="w-3.5 h-3.5" />
                    <span>
                      {isExpanded
                        ? language === 'hi' ? 'व्याख्या छिपाएं' : 'Hide Solution'
                        : language === 'hi' ? 'उत्तर एवं विस्तृत व्याख्या' : 'View Solution'}
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      startTest(
                        {
                          questionCount: 1,
                          subjects: [q.subjectId],
                          mode: 'practice',
                          negativeMarking: 0,
                          timeLimitMinutes: 0,
                          shuffleQuestions: false,
                          shuffleOptions: false,
                        },
                        [q],
                        `${language === 'hi' ? 'सुधार अभ्यास' : 'Mistake Drill'}: ${q.topic}`
                      );
                    }}
                    className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-bold flex items-center gap-1 transition-colors"
                  >
                    <Play className="w-3 h-3 fill-white" />
                    <span>{language === 'hi' ? 'पुनः हल करें' : 'Retry Question'}</span>
                  </button>
                </div>

                {/* Solution Box */}
                {isExpanded && (
                  <div className="p-3.5 rounded-xl bg-amber-50/80 border border-amber-200 text-xs sm:text-sm text-amber-950 font-devanagari leading-relaxed animate-in fade-in duration-150">
                    <div className="font-bold text-amber-900 mb-1">
                      {language === 'hi' ? `सही विकल्प: (${q.correctAnswer})` : `Correct Option: (${q.correctAnswer})`}
                    </div>
                    <p>{q.explanationHindi}</p>
                    {q.explanationEnglish && (
                      <p className="text-xs text-amber-800/80 italic pt-1.5 mt-1.5 border-t border-amber-200/50">
                        {q.explanationEnglish}
                      </p>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
