import React from 'react';
import { useLanguage } from '../context/LanguageContext';
import { useQuestions } from '../context/QuestionContext';
import { BPSC_SUBJECTS } from '../data/subjects';
import { Subject } from '../types';
import { 
  Landmark, 
  Flame, 
  Scroll, 
  Globe2, 
  Scale, 
  TrendingUp, 
  Atom, 
  Leaf, 
  Newspaper, 
  BookOpen, 
  Calculator,
  Play,
  SlidersHorizontal,
  ChevronRight
} from 'lucide-react';

interface SubjectGridProps {
  onSelectSubject: (subjectId: string, directStart?: boolean) => void;
}

export const SubjectGrid: React.FC<SubjectGridProps> = ({ onSelectSubject }) => {
  const { t, language } = useLanguage();
  const { questions } = useQuestions();

  // Icon mapping
  const renderIcon = (name: string, className = 'w-5 h-5') => {
    switch (name) {
      case 'Landmark': return <Landmark className={className} />;
      case 'Flame': return <Flame className={className} />;
      case 'Scroll': return <Scroll className={className} />;
      case 'Globe2': return <Globe2 className={className} />;
      case 'Scale': return <Scale className={className} />;
      case 'TrendingUp': return <TrendingUp className={className} />;
      case 'Atom': return <Atom className={className} />;
      case 'Leaf': return <Leaf className={className} />;
      case 'Newspaper': return <Newspaper className={className} />;
      case 'BookOpen': return <BookOpen className={className} />;
      case 'Calculator': return <Calculator className={className} />;
      default: return <BookOpen className={className} />;
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
        <div>
          <h2 className="text-lg sm:text-xl font-black text-slate-900 tracking-tight">
            {t('subjectHeading')}
          </h2>
          <p className="text-xs text-slate-500">
            {t('subjectSubtitle')}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
        {BPSC_SUBJECTS.map((subj) => {
          const count = questions.filter((q) => q.subjectId === subj.id).length;
          const pyqCount = questions.filter((q) => q.subjectId === subj.id && q.isPYQ).length;
          const importedCount = questions.filter((q) => q.subjectId === subj.id && q.isImported).length;

          return (
            <div
              key={subj.id}
              className="bg-white rounded-2xl border border-slate-200/90 hover:border-slate-300 p-4 shadow-2xs hover:shadow-md transition-all flex flex-col justify-between group"
            >
              <div>
                {/* Header: Icon + Counts */}
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div
                    className={`w-11 h-11 rounded-xl ${subj.bgColor} ${subj.color} flex items-center justify-center border ${subj.borderColor} shadow-2xs group-hover:scale-105 transition-transform`}
                  >
                    {renderIcon(subj.iconName, 'w-5 h-5')}
                  </div>

                  <div className="text-right">
                    <span className="inline-block text-xs font-bold text-slate-800 bg-slate-100 px-2 py-0.5 rounded-md">
                      {count} {t('questionsCount')}
                    </span>
                    <div className="flex flex-col items-end gap-0.5 mt-0.5">
                      {importedCount > 0 && (
                        <span className="text-[10px] font-bold text-indigo-700 bg-indigo-50 px-1.5 py-0.2 rounded border border-indigo-200">
                          +{importedCount} {language === 'hi' ? 'आयातित' : 'imported'}
                        </span>
                      )}
                      {pyqCount > 0 && (
                        <span className="text-[10px] font-semibold text-emerald-700">
                          {pyqCount} {language === 'hi' ? 'PYQ प्रश्न' : 'PYQs'}
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Subject Title & Description */}
                <h3 className="font-bold text-slate-900 text-sm sm:text-base leading-snug group-hover:text-red-700 transition-colors">
                  {language === 'hi' ? subj.nameHindi : subj.nameEnglish}
                </h3>
                <p className="text-xs text-slate-500 line-clamp-2 mt-1 leading-relaxed">
                  {language === 'hi' ? subj.descriptionHindi : subj.descriptionEnglish}
                </p>
              </div>

              {/* Action Buttons */}
              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => onSelectSubject(subj.id, true)}
                  className="flex-1 py-2 px-3 rounded-xl bg-red-50 hover:bg-red-100 text-red-800 text-xs font-bold flex items-center justify-center gap-1.5 transition-colors min-h-[40px] cursor-pointer"
                >
                  <Play className="w-3.5 h-3.5 fill-red-800" />
                  <span>{t('practiceNow')}</span>
                </button>

                <button
                  type="button"
                  onClick={() => onSelectSubject(subj.id, false)}
                  className="p-2 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-600 hover:text-slate-900 transition-colors min-h-[40px] min-w-[40px] flex items-center justify-center cursor-pointer"
                  title="Configure Custom Test for this subject"
                >
                  <SlidersHorizontal className="w-4 h-4" />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
