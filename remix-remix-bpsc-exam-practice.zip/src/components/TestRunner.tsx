import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { useTest } from '../context/TestContext';
import { useUser } from '../context/UserContext';
import { OptionKey } from '../types';
import { BPSC_SUBJECTS } from '../data/subjects';
import { 
  Clock, 
  ChevronLeft, 
  ChevronRight, 
  RotateCcw, 
  Bookmark, 
  Flag, 
  Grid3X3, 
  CheckCircle2, 
  AlertTriangle,
  X,
  Send,
  HelpCircle,
  Sparkles,
  ShieldCheck,
  Type
} from 'lucide-react';

export const TestRunner: React.FC = () => {
  const { t, language } = useLanguage();
  const {
    testTitle,
    settings,
    questions,
    currentIndex,
    currentQuestion,
    answers,
    timeRemainingSeconds,
    isTimerRunning,
    fontSize,
    setFontSize,
    selectOption,
    clearAnswer,
    toggleMarkForReview,
    goToQuestion,
    nextQuestion,
    prevQuestion,
    submitTest,
    abortTest,
    showSubmitModal,
    setShowSubmitModal,
    showPaletteDrawer,
    setShowPaletteDrawer,
  } = useTest();

  const { isBookmarked, toggleBookmark } = useUser();
  const [showExitConfirm, setShowExitConfirm] = useState(false);

  if (!currentQuestion) return null;

  const q = currentQuestion.original;
  const currentRecord = answers[q.id];
  const selectedOption = currentRecord?.selectedOption ?? null;
  const isMarked = currentRecord?.isMarkedForReview ?? false;
  const bookmarked = isBookmarked(q.id);

  // Subject details
  const subjectObj = BPSC_SUBJECTS.find((s) => s.id === q.subjectId);
  const subjectName = language === 'hi' ? subjectObj?.nameHindi : subjectObj?.nameEnglish;

  // Format timer
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const isPracticeMode = settings?.mode === 'practice';
  const optionLetters: OptionKey[] = ['A', 'B', 'C', 'D', 'E'];

  const handleNext = () => {
    nextQuestion();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handlePrev = () => {
    prevQuestion();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Font size classes
  const fontSizes = {
    normal: {
      question: 'text-sm sm:text-base leading-relaxed',
      option: 'text-xs sm:text-sm',
    },
    large: {
      question: 'text-base sm:text-lg leading-relaxed',
      option: 'text-sm sm:text-base',
    },
    xlarge: {
      question: 'text-lg sm:text-xl leading-relaxed',
      option: 'text-base sm:text-lg',
    },
  };

  // Stats for submission confirmation
  const totalQuestions = questions.length;
  let answeredCount = 0;
  let markedCount = 0;
  Object.values(answers).forEach((a) => {
    if (a.selectedOption !== null) answeredCount++;
    if (a.isMarkedForReview) markedCount++;
  });
  const unansweredCount = totalQuestions - answeredCount;

  // Practice mode reveal state:
  const isAnswerRevealed = isPracticeMode && selectedOption !== null;
  const isSelectedCorrect = selectedOption === currentQuestion.correctDisplayAnswer;

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col pb-20 sm:pb-8">
      {/* Test Header Bar */}
      <div className="sticky top-0 z-30 bg-white border-b border-slate-200 px-2 sm:px-6 py-2 shadow-xs flex items-center justify-between gap-1 sm:gap-2">
        {/* Left: Test Title & Question index */}
        <div className="flex items-center gap-1.5 sm:gap-3 min-w-0">
          <button
            onClick={() => setShowExitConfirm(true)}
            className="p-1.5 rounded-lg text-slate-500 hover:text-slate-800 hover:bg-slate-100 transition-colors shrink-0 min-h-[36px] min-w-[36px] flex items-center justify-center cursor-pointer"
            title="Exit Test"
          >
            <X className="w-4 h-4 sm:w-5 sm:h-5" />
          </button>
          <div className="min-w-0">
            <div className="flex items-center gap-1">
              <span className="font-extrabold text-xs sm:text-base text-slate-900 truncate max-w-[85px] min-[390px]:max-w-[140px] sm:max-w-xs">
                {testTitle}
              </span>
              <span className="hidden sm:inline-flex text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 border border-slate-200 shrink-0">
                {isPracticeMode ? 'अभ्यास मोड' : 'परीक्षा मोड'}
              </span>
            </div>
            <p className="text-[10px] min-[380px]:text-[11px] sm:text-xs text-slate-500 whitespace-nowrap">
              {t('question')} <span className="font-bold text-red-700">{currentIndex + 1}</span> {t('of')} {totalQuestions}
            </p>
          </div>
        </div>

        {/* Center: Countdown Timer */}
        {settings?.timeLimitMinutes && settings.timeLimitMinutes > 0 ? (
          <div
            className={`flex items-center gap-1 px-2 sm:px-3 py-1 rounded-xl font-mono font-bold text-xs sm:text-sm border shadow-2xs shrink-0 ${
              timeRemainingSeconds <= 300
                ? 'bg-red-50 text-red-700 border-red-300 animate-pulse'
                : 'bg-slate-50 text-slate-800 border-slate-200'
            }`}
          >
            <Clock className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-red-700 shrink-0" />
            <span>{formatTime(timeRemainingSeconds)}</span>
          </div>
        ) : (
          <div className="flex items-center gap-1 text-xs text-slate-500 font-mono shrink-0">
            <Clock className="w-3.5 h-3.5" />
            <span>{formatTime(timeRemainingSeconds)}</span>
          </div>
        )}

        {/* Right Tools: Font size, Bookmark, Palette trigger, Submit */}
        <div className="flex items-center gap-1 sm:gap-2 shrink-0">
          {/* Font Size Adjuster */}
          <div className="hidden sm:flex items-center bg-slate-100 rounded-lg p-0.5 border border-slate-200 text-xs font-bold">
            <button
              onClick={() => setFontSize('normal')}
              className={`px-1.5 py-0.5 rounded ${fontSize === 'normal' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-500'}`}
              title="Normal Font"
            >
              A
            </button>
            <button
              onClick={() => setFontSize('large')}
              className={`px-1.5 py-0.5 rounded ${fontSize === 'large' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-500'}`}
              title="Large Font"
            >
              A+
            </button>
            <button
              onClick={() => setFontSize('xlarge')}
              className={`px-1.5 py-0.5 rounded ${fontSize === 'xlarge' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-500'}`}
              title="Extra Large Font"
            >
              A++
            </button>
          </div>

          {/* Bookmark Button */}
          <button
            onClick={() => toggleBookmark(q.id)}
            className={`p-1.5 sm:p-2 rounded-lg border transition-colors shrink-0 cursor-pointer ${
              bookmarked
                ? 'bg-amber-50 text-amber-600 border-amber-300'
                : 'bg-white text-slate-400 hover:text-slate-700 border-slate-200'
            }`}
            title="Bookmark Question"
            aria-label="Bookmark"
          >
            <Bookmark className={`w-3.5 h-3.5 sm:w-4 sm:h-4 ${bookmarked ? 'fill-amber-500' : ''}`} />
          </button>

          {/* Question Palette Drawer Button */}
          <button
            onClick={() => setShowPaletteDrawer(true)}
            className="flex items-center gap-1 p-1.5 sm:px-2.5 sm:py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-bold shadow-2xs shrink-0 cursor-pointer"
            title="Open Question Palette"
            aria-label="Palette"
          >
            <Grid3X3 className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-red-700" />
            <span className="hidden sm:inline">{t('questionPalette')}</span>
          </button>

          {/* Submit Test Button */}
          <button
            onClick={() => setShowSubmitModal(true)}
            className="flex items-center gap-1 px-2.5 sm:px-3 py-1.5 bg-red-700 hover:bg-red-800 text-white rounded-lg text-xs font-bold shadow-xs transition-colors shrink-0 cursor-pointer"
            aria-label="Submit"
          >
            <Send className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
            <span className="hidden sm:inline">{t('submitTest')}</span>
            <span className="sm:hidden">{language === 'hi' ? 'सबमिट' : 'Submit'}</span>
          </button>
        </div>
      </div>

      {/* Main Test Layout */}
      <div className="max-w-4xl mx-auto w-full px-3 sm:px-6 py-4 flex-1 flex flex-col">
        {/* Question Card */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-4 sm:p-6 flex-1 flex flex-col">
          {/* Top metadata tags */}
          <div className="flex flex-wrap items-center justify-between gap-2 pb-3 mb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-red-800 bg-red-50 border border-red-200 px-2.5 py-1 rounded-md">
                {subjectName || 'BPSC General Studies'}
              </span>
              {q.topic && (
                <span className="text-xs text-slate-500 font-medium hidden sm:inline">
                  • {q.topic}
                </span>
              )}
            </div>

            <div className="flex flex-wrap items-center gap-1.5 text-xs">
              {q.isDemo && (
                <span className="font-bold text-amber-900 bg-amber-100 border border-amber-300 px-2 py-0.5 rounded-md flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5 text-amber-700" />
                  <span>[डेमो/परीक्षण]</span>
                </span>
              )}
              {q.isImported && !q.isDemo && (
                <span className="font-bold text-indigo-900 bg-indigo-100 border border-indigo-300 px-2 py-0.5 rounded-md flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5 text-indigo-700" />
                  <span>आयातित</span>
                </span>
              )}
              {q.isPYQ && (
                <span className="font-bold text-emerald-800 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-md flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{q.source || 'BPSC PYQ'}</span>
                </span>
              )}
              {settings?.negativeMarking !== undefined && settings.negativeMarking > 0 && (
                <span className="text-slate-400 font-mono text-[11px]">
                  -{(settings.negativeMarking).toFixed(2)} neg
                </span>
              )}
            </div>
          </div>

          {/* Question Text */}
          <div className="mb-6">
            <div className="flex items-start gap-2.5">
              <span className="w-6 h-6 rounded-full bg-slate-900 text-white text-xs font-extrabold flex items-center justify-center shrink-0 mt-0.5">
                {currentIndex + 1}
              </span>
              <div className="space-y-2 flex-1">
                {/* Hindi Question (Default / Primary) */}
                <p className={`font-semibold text-slate-900 ${fontSizes[fontSize].question}`}>
                  {q.questionHindi}
                </p>

                {/* English Translation always accessible */}
                {q.questionEnglish && (
                  <p className="text-xs sm:text-sm text-slate-600 font-normal italic pt-1 border-t border-slate-100">
                    {q.questionEnglish}
                  </p>
                )}
              </div>
            </div>
          </div>

          {/* Five Options (A, B, C, D, E) */}
          <div className="space-y-2.5 mb-6">
            {optionLetters.map((letter, idx) => {
              const optHindi = currentQuestion.displayOptionsHindi[idx];
              const optEnglish = currentQuestion.displayOptionsEnglish[idx];
              const isSelected = selectedOption === letter;
              const isCorrectOpt = letter === currentQuestion.correctDisplayAnswer;

              // Color classes based on mode
              let cardStyle = 'border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50/70 text-slate-800';
              let badgeStyle = 'bg-slate-100 text-slate-700 border-slate-300';

              if (isSelected && !isPracticeMode) {
                // Exam mode selected
                cardStyle = 'border-red-700 bg-red-50/70 ring-1 ring-red-700 text-slate-900 font-medium';
                badgeStyle = 'bg-red-700 text-white border-red-700';
              } else if (isPracticeMode && isAnswerRevealed) {
                // Practice mode instant feedback
                if (isCorrectOpt) {
                  cardStyle = 'border-emerald-600 bg-emerald-50 ring-1 ring-emerald-600 text-emerald-950 font-semibold';
                  badgeStyle = 'bg-emerald-600 text-white border-emerald-600';
                } else if (isSelected && !isCorrectOpt) {
                  cardStyle = 'border-red-600 bg-red-50 ring-1 ring-red-600 text-red-950 font-medium';
                  badgeStyle = 'bg-red-600 text-white border-red-600';
                } else {
                  cardStyle = 'border-slate-200 opacity-60 bg-slate-50 text-slate-600';
                }
              }

              return (
                <button
                  key={letter}
                  type="button"
                  onClick={() => selectOption(letter)}
                  className={`w-full p-3 sm:p-3.5 rounded-xl border text-left flex items-start gap-3 transition-all cursor-pointer min-h-[48px] active:scale-[0.99] ${cardStyle}`}
                >
                  {/* Option Badge (A, B, C, D, E) */}
                  <span
                    className={`w-7 h-7 rounded-lg border font-bold text-xs sm:text-sm flex items-center justify-center shrink-0 mt-0.5 transition-colors ${badgeStyle}`}
                  >
                    {letter}
                  </span>

                  {/* Option Text */}
                  <div className="flex-1 min-w-0">
                    <p className={`font-medium break-words leading-relaxed ${fontSizes[fontSize].option}`}>
                      {optHindi}
                    </p>
                    {optEnglish && optEnglish !== optHindi && (
                      <p className="text-[11px] sm:text-xs text-slate-500 italic mt-0.5 break-words">
                        {optEnglish}
                      </p>
                    )}
                  </div>

                  {/* Icon indicators */}
                  {isPracticeMode && isAnswerRevealed && (
                    <div className="shrink-0 pt-0.5">
                      {isCorrectOpt && <CheckCircle2 className="w-5 h-5 text-emerald-600" />}
                      {isSelected && !isCorrectOpt && <AlertTriangle className="w-5 h-5 text-red-600" />}
                    </div>
                  )}
                </button>
              );
            })}
          </div>

          {/* Instant Practice Mode Explanation Box */}
          {isPracticeMode && isAnswerRevealed && (
            <div
              className={`p-4 rounded-xl border mb-6 animate-in fade-in duration-200 ${
                isSelectedCorrect
                  ? 'bg-emerald-50/80 border-emerald-200 text-emerald-900'
                  : 'bg-red-50/80 border-red-200 text-red-900'
              }`}
            >
              <div className="flex items-center gap-2 font-bold text-sm mb-2">
                {isSelectedCorrect ? (
                  <>
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>{language === 'hi' ? 'शाबाश! सही उत्तर है' : 'Correct Answer!'}</span>
                  </>
                ) : (
                  <>
                    <AlertTriangle className="w-4 h-4 text-red-600" />
                    <span>
                      {language === 'hi' 
                        ? `गलत उत्तर। सही विकल्प (${currentQuestion.correctDisplayAnswer}) है:`
                        : `Incorrect. The correct option is (${currentQuestion.correctDisplayAnswer}):`}
                    </span>
                  </>
                )}
              </div>

              <div className="space-y-1.5 text-xs sm:text-sm text-slate-800 leading-relaxed font-devanagari">
                <p className="font-semibold text-slate-900">
                  {t('explanationTitle')}
                </p>
                <p>{q.explanationHindi}</p>
                {q.explanationEnglish && (
                  <p className="text-xs text-slate-600 italic pt-1 border-t border-slate-200/60">
                    {q.explanationEnglish}
                  </p>
                )}
              </div>
            </div>
          )}

          {/* Dedicated Primary Navigation Area - Directly below 5 options */}
          <div className="mt-auto pt-5 border-t border-slate-200">
            {/* Primary Buttons: "पिछला प्रश्न" & "अगला प्रश्न" / "टेस्ट सबमिट करें" */}
            <div className="grid grid-cols-2 gap-3 sm:gap-4 mb-3">
              {/* Previous Question Button */}
              <button
                type="button"
                onClick={handlePrev}
                disabled={currentIndex === 0}
                className={`w-full py-3 px-3 sm:px-4 rounded-xl border-2 font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 sm:gap-2 transition-all ${
                  currentIndex === 0
                    ? 'bg-slate-100 text-slate-400 border-slate-200 cursor-not-allowed opacity-50'
                    : 'bg-white hover:bg-slate-50 text-slate-800 border-slate-300 shadow-2xs active:scale-98 cursor-pointer'
                }`}
                title={language === 'hi' ? 'पिछला प्रश्न देखें' : 'Go to previous question'}
              >
                <ChevronLeft className="w-4 h-4 sm:w-5 sm:h-5 shrink-0" />
                <span>{language === 'hi' ? 'पिछला प्रश्न' : 'Previous Question'}</span>
              </button>

              {/* Next Question OR Submit Test on last question */}
              {currentIndex < totalQuestions - 1 ? (
                <button
                  type="button"
                  onClick={handleNext}
                  className="w-full py-3 px-3 sm:px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 sm:gap-2 shadow-md shadow-slate-900/20 active:scale-98 cursor-pointer transition-all border-2 border-slate-900"
                  title={language === 'hi' ? 'उत्तर सहेजें और अगला प्रश्न देखें' : 'Save and go to next question'}
                >
                  <span>{language === 'hi' ? 'अगला प्रश्न' : 'Next Question'}</span>
                  <ChevronRight className="w-4 h-4 sm:w-5 sm:h-5 shrink-0" />
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => setShowSubmitModal(true)}
                  className="w-full py-3 px-3 sm:px-4 rounded-xl bg-red-700 hover:bg-red-800 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 sm:gap-2 shadow-md shadow-red-700/25 active:scale-98 cursor-pointer transition-all border-2 border-red-700"
                  title={language === 'hi' ? 'टेस्ट सबमिट करें' : 'Submit test'}
                >
                  <Send className="w-4 h-4 shrink-0" />
                  <span>{language === 'hi' ? 'टेस्ट सबमिट करें' : 'Submit Test'}</span>
                </button>
              )}
            </div>

            {/* Secondary Action Row: Clear Answer, Mark for Review, and Palette Jump */}
            <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-100 text-xs">
              <div className="flex items-center gap-2">
                {/* Clear Answer Button */}
                {selectedOption !== null && (
                  <button
                    type="button"
                    onClick={clearAnswer}
                    className="px-3 py-1.5 rounded-lg border border-slate-200 text-slate-600 hover:text-slate-900 hover:bg-slate-50 font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>{t('clearAnswer')}</span>
                  </button>
                )}

                {/* Mark for Review Button */}
                <button
                  type="button"
                  onClick={toggleMarkForReview}
                  className={`px-3 py-1.5 rounded-lg border font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
                    isMarked
                      ? 'bg-purple-100 text-purple-800 border-purple-300'
                      : 'bg-white text-slate-600 hover:text-slate-900 border-slate-200'
                  }`}
                >
                  <Flag className={`w-3.5 h-3.5 ${isMarked ? 'fill-purple-600 text-purple-600' : ''}`} />
                  <span>{isMarked ? t('markedForReview') : t('markForReview')}</span>
                </button>
              </div>

              {/* Question Count & Palette Indicator */}
              <button
                type="button"
                onClick={() => setShowPaletteDrawer(true)}
                className="px-3 py-1.5 rounded-lg border border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-700 font-bold flex items-center gap-1.5 ml-auto cursor-pointer"
              >
                <Grid3X3 className="w-3.5 h-3.5 text-red-700" />
                <span>
                  {language === 'hi' ? `प्रश्न ${currentIndex + 1} / ${totalQuestions}` : `Q ${currentIndex + 1} of ${totalQuestions}`}
                </span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Question Palette Drawer Modal */}
      {showPaletteDrawer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            {/* Header */}
            <div className="bg-slate-900 text-white p-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Grid3X3 className="w-5 h-5 text-amber-400" />
                <h3 className="font-bold text-base">{t('questionPalette')}</h3>
              </div>
              <button
                onClick={() => setShowPaletteDrawer(false)}
                className="p-1 rounded-lg hover:bg-white/10 text-slate-300 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Legend */}
            <div className="p-3 bg-slate-50 border-b border-slate-200 grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
              <div className="flex items-center gap-1.5">
                <span className="w-3.5 h-3.5 rounded-full bg-emerald-600"></span>
                <span>{t('answered')} ({answeredCount})</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-3.5 h-3.5 rounded-full bg-amber-500"></span>
                <span>{t('unanswered')} ({unansweredCount})</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-3.5 h-3.5 rounded-full bg-purple-600"></span>
                <span>{t('markedForReview')} ({markedCount})</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-3.5 h-3.5 rounded-full bg-slate-300"></span>
                <span>{t('notVisited')}</span>
              </div>
            </div>

            {/* Numbers Grid */}
            <div className="p-4 max-h-72 overflow-y-auto grid grid-cols-5 sm:grid-cols-8 gap-2">
              {questions.map((wrapper, index) => {
                const rec = answers[wrapper.original.id];
                const isAns = rec && rec.selectedOption !== null;
                const isRev = rec && rec.isMarkedForReview;
                const isCurr = index === currentIndex;

                let btnBg = 'bg-slate-100 text-slate-700 border-slate-200';
                if (isAns) {
                  btnBg = 'bg-emerald-600 text-white border-emerald-700 shadow-2xs';
                } else if (rec && rec.timeSpentSeconds > 0) {
                  btnBg = 'bg-amber-100 text-amber-800 border-amber-300';
                }

                if (isRev) {
                  btnBg = 'bg-purple-600 text-white border-purple-700 ring-2 ring-purple-300';
                }

                return (
                  <button
                    key={wrapper.original.id}
                    onClick={() => {
                      goToQuestion(index);
                      setShowPaletteDrawer(false);
                    }}
                    className={`h-10 rounded-xl font-bold text-xs border flex items-center justify-center transition-all ${btnBg} ${
                      isCurr ? 'ring-2 ring-slate-900 ring-offset-1 scale-105' : ''
                    }`}
                  >
                    {index + 1}
                  </button>
                );
              })}
            </div>

            {/* Footer */}
            <div className="p-3 bg-slate-50 border-t border-slate-200 flex justify-between">
              <button
                onClick={() => setShowPaletteDrawer(false)}
                className="px-4 py-1.5 text-xs font-bold text-slate-600 hover:text-slate-800"
              >
                {language === 'hi' ? 'बंद करें' : 'Close'}
              </button>
              <button
                onClick={() => {
                  setShowPaletteDrawer(false);
                  setShowSubmitModal(true);
                }}
                className="px-4 py-1.5 bg-red-700 hover:bg-red-800 text-white rounded-lg text-xs font-bold"
              >
                {t('submitTest')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Final Submit Confirmation Modal */}
      {showSubmitModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="p-5 text-center">
              <div className="w-12 h-12 rounded-full bg-red-100 text-red-700 mx-auto flex items-center justify-center mb-3">
                <Send className="w-6 h-6" />
              </div>
              <h3 className="font-extrabold text-lg text-slate-900">
                {t('confirmSubmitTitle')}
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                {t('confirmSubmitDesc')}
              </p>

              {/* Status summary */}
              <div className="my-5 p-3.5 bg-slate-50 rounded-xl border border-slate-200 grid grid-cols-3 gap-2 text-center">
                <div>
                  <div className="text-xl font-extrabold text-emerald-700">{answeredCount}</div>
                  <div className="text-[11px] font-semibold text-slate-500">{t('answered')}</div>
                </div>
                <div>
                  <div className="text-xl font-extrabold text-amber-600">{unansweredCount}</div>
                  <div className="text-[11px] font-semibold text-slate-500">{t('unanswered')}</div>
                </div>
                <div>
                  <div className="text-xl font-extrabold text-purple-700">{markedCount}</div>
                  <div className="text-[11px] font-semibold text-slate-500">{language === 'hi' ? 'समीक्षा' : 'Review'}</div>
                </div>
              </div>

              {unansweredCount > 0 && (
                <div className="text-xs text-amber-700 bg-amber-50 border border-amber-200 p-2.5 rounded-lg mb-4 text-left flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>
                    {language === 'hi'
                      ? `चेतावनी: आपने ${unansweredCount} प्रश्नों के उत्तर नहीं दिए हैं। क्या आप अभी सबमिट करना चाहते हैं?`
                      : `Notice: You have ${unansweredCount} unanswered questions.`}
                  </span>
                </div>
              )}

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setShowSubmitModal(false)}
                  className="flex-1 py-2.5 rounded-xl border border-slate-200 text-slate-700 text-xs font-bold hover:bg-slate-50"
                >
                  {language === 'hi' ? 'हल करना जारी रखें' : 'Keep Testing'}
                </button>
                <button
                  type="button"
                  onClick={() => submitTest()}
                  className="flex-1 py-2.5 rounded-xl bg-red-700 hover:bg-red-800 text-white text-xs font-bold shadow-md shadow-red-700/20"
                >
                  {language === 'hi' ? 'हां, सबमिट करें' : 'Confirm Submit'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Exit Test Confirmation */}
      {showExitConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white w-full max-w-sm rounded-2xl shadow-2xl border border-slate-200 p-5 text-center">
            <h3 className="font-bold text-base text-slate-900 mb-2">
              {language === 'hi' ? 'क्या आप टेस्ट छोड़ना चाहते हैं?' : 'Exit Test Session?'}
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              {language === 'hi' 
                ? 'यदि आप अभी बाहर निकलते हैं तो आपकी वर्तमान प्रगति सहेजी नहीं जाएगी।'
                : 'Your current progress in this test session will be discarded.'}
            </p>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setShowExitConfirm(false)}
                className="flex-1 py-2 rounded-xl border border-slate-200 text-xs font-bold text-slate-700 hover:bg-slate-50"
              >
                {t('cancel')}
              </button>
              <button
                onClick={() => {
                  setShowExitConfirm(false);
                  abortTest();
                }}
                className="flex-1 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold"
              >
                {language === 'hi' ? 'टेस्ट छोड़ें' : 'Exit Test'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
