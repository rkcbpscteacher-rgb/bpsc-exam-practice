import React, { useState, useEffect } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { useQuestions } from '../context/QuestionContext';
import { useTest } from '../context/TestContext';
import { useUser } from '../context/UserContext';
import { BPSC_SUBJECTS } from '../data/subjects';
import { INITIAL_TRE_PAPERS } from '../data/treInitialPapers';
import { OptionKey, TREPaper, TREPhase, TREClassLevel, TREShift } from '../types';
import { 
  ShieldCheck, 
  Play, 
  Bookmark, 
  FileText, 
  Filter, 
  Search,
  Calendar,
  CheckCircle2,
  Clock,
  ExternalLink,
  BookOpen,
  Eye,
  X,
  Layers,
  AlertCircle,
  Download,
  Sparkles,
  ArrowRight,
  RotateCcw,
  Info
} from 'lucide-react';

export const PYQSection: React.FC = () => {
  const { t, language } = useLanguage();
  const { getPYQQuestions } = useQuestions();
  const { startTest } = useTest();
  const { isBookmarked, toggleBookmark } = useUser();

  // Mode: 'tre' (BPSC TRE Papers) or 'cce' (BPSC CCE 64th-69th Papers)
  const [activeTab, setActiveTab] = useState<'tre' | 'cce'>('tre');

  // TRE Papers state from API (with fallback to INITIAL_TRE_PAPERS)
  const [trePapers, setTrePapers] = useState<TREPaper[]>(INITIAL_TRE_PAPERS);
  const [loadingPapers, setLoadingPapers] = useState<boolean>(false);

  // TRE Filters
  const [selectedPhase, setSelectedPhase] = useState<string>('all');
  const [selectedClassLevel, setSelectedClassLevel] = useState<string>('all');
  const [selectedTRESubject, setSelectedTRESubject] = useState<string>('all');
  const [selectedShift, setSelectedShift] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // PDF & Paper Preview Modal
  const [viewingPdfPaper, setViewingPdfPaper] = useState<TREPaper | null>(null);

  // CCE PYQ states
  const [selectedYear, setSelectedYear] = useState<string>('all');
  const [selectedSubject, setSelectedSubject] = useState<string>('all');
  const [expandedSolutions, setExpandedSolutions] = useState<Record<string, boolean>>({});

  useEffect(() => {
    setLoadingPapers(true);
    fetch('/api/tre-papers')
      .then((res) => res.json())
      .then((data) => {
        if (Array.isArray(data) && data.length > 0) {
          setTrePapers(data);
        }
      })
      .catch((err) => {
        console.warn('Could not fetch TRE papers from API, using initial verified dataset:', err);
      })
      .finally(() => setLoadingPapers(false));
  }, []);

  // Check for verified TRE 4.0 papers with verified questions
  const verifiedTRE4Papers = trePapers.filter(
    (p) => p.phase === 'TRE 4.0' && p.isVerified && !p.isComingSoon && Array.isArray(p.questions) && p.questions.length > 0
  );
  const hasVerifiedTRE4Data = verifiedTRE4Papers.length > 0;

  // Filtered TRE Papers
  const filteredTREPapers = trePapers.filter((paper) => {
    if (selectedPhase !== 'all' && paper.phase !== selectedPhase) return false;
    // When viewing 'all', keep only verified papers if TRE 4.0 has not yet been conducted
    if (selectedPhase === 'all' && paper.phase === 'TRE 4.0' && !hasVerifiedTRE4Data) return false;
    if (selectedClassLevel !== 'all' && paper.classLevel !== selectedClassLevel) return false;
    if (selectedTRESubject !== 'all' && paper.subject !== selectedTRESubject && paper.subjectHindi !== selectedTRESubject) return false;
    if (selectedShift !== 'all' && paper.shift !== selectedShift) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchTitle = paper.title.toLowerCase().includes(q) || paper.titleHindi.toLowerCase().includes(q);
      const matchSubject = paper.subject.toLowerCase().includes(q) || paper.subjectHindi.toLowerCase().includes(q);
      const matchTopic = paper.questions.some((item) => item.topic.toLowerCase().includes(q) || item.questionHindi.toLowerCase().includes(q));
      if (!matchTitle && !matchSubject && !matchTopic) return false;
    }
    return true;
  });

  const handleResetFilters = () => {
    setSelectedPhase('all');
    setSelectedClassLevel('all');
    setSelectedTRESubject('all');
    setSelectedShift('all');
    setSearchQuery('');
  };

  // Start online test for a TRE paper
  const handleStartTREPaperTest = (paper: TREPaper) => {
    if (!paper.questions || paper.questions.length === 0) return;

    startTest(
      {
        questionCount: paper.questions.length,
        subjects: [],
        mode: 'exam',
        negativeMarking: paper.negativeMarking,
        timeLimitMinutes: paper.durationMinutes,
        shuffleQuestions: false,
        shuffleOptions: false,
        pyqOnly: true,
      },
      paper.questions,
      language === 'hi' ? paper.titleHindi : paper.title
    );
  };

  // CCE PYQ Handling
  const pyqs = getPYQQuestions();
  const availableExams = [
    { id: 'all', label: language === 'hi' ? 'सभी वर्ष (All Years)' : 'All Years' },
    { id: '69th', label: '69th BPSC Prelims (2023)' },
    { id: '68th', label: '68th BPSC Prelims (2023)' },
    { id: '67th', label: '67th BPSC Re-Exam (2022)' },
    { id: '66th', label: '66th BPSC Prelims (2020)' },
    { id: '65th', label: '65th BPSC Prelims (2019)' },
    { id: '64th', label: '64th BPSC Prelims (2018)' },
  ];

  const filteredPYQs = pyqs.filter((q) => {
    if (selectedYear !== 'all' && !q.source?.toLowerCase().includes(selectedYear.toLowerCase())) {
      return false;
    }
    if (selectedSubject !== 'all' && q.subjectId !== selectedSubject) {
      return false;
    }
    return true;
  });

  const handleStartPYQTest = () => {
    if (filteredPYQs.length === 0) return;
    startTest(
      {
        questionCount: filteredPYQs.length,
        subjects: selectedSubject !== 'all' ? [selectedSubject] : [],
        mode: 'exam',
        negativeMarking: 0.25,
        timeLimitMinutes: Math.round(filteredPYQs.length * 1.2),
        shuffleQuestions: true,
        shuffleOptions: false,
        pyqOnly: true,
      },
      filteredPYQs,
      `BPSC Official PYQ Test (${selectedYear === 'all' ? 'All Years' : selectedYear})`
    );
  };

  const toggleSolution = (id: string) => {
    setExpandedSolutions((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const optionLetters: OptionKey[] = ['A', 'B', 'C', 'D', 'E'];

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-150">
      {/* Top Main Hero Banner */}
      <div className="bg-gradient-to-r from-emerald-950 via-teal-900 to-slate-900 rounded-3xl text-white p-5 sm:p-7 shadow-xl border border-emerald-800/80 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-5">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-bold mb-2.5 border border-emerald-500/30">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>{language === 'hi' ? '100% प्रामाणिक BPSC TRE आधिकारिक प्रश्न पत्र' : '100% Authentic BPSC TRE Official Papers'}</span>
            </div>
            <h2 className="text-xl sm:text-2xl lg:text-3xl font-black tracking-tight">
              {language === 'hi' ? 'Previous Year TRE Papers (विगत वर्ष प्रश्न पत्र)' : 'Previous Year TRE Papers'}
            </h2>
            <p className="text-xs sm:text-sm text-emerald-100/90 max-w-2xl mt-1.5 leading-relaxed">
              {language === 'hi'
                ? 'BPSC TRE 1.0, 2.0 एवं 3.0 के प्राथमिक (1-5), मध्य (6-8), माध्यमिक (9-10) एवं उच्च माध्यमिक (11-12) के आधिकारिक 5-विकल्प प्रश्न पत्र हल करें एवं प्रामाणिक उत्तर कुंजी व PDF देखें।'
                : 'Practice authentic 5-option (A-E) question papers with official answer keys, online timed exam mode, and official PDF references.'}
            </p>
          </div>

          {/* Quick Tab Switcher between TRE Papers and General CCE PYQs */}
          <div className="flex bg-slate-900/80 p-1 rounded-2xl border border-emerald-500/30 shrink-0">
            <button
              onClick={() => setActiveTab('tre')}
              className={`px-3.5 py-2 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'tre'
                  ? 'bg-emerald-400 text-slate-950 shadow-md'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>BPSC TRE Papers</span>
            </button>
            <button
              onClick={() => setActiveTab('cce')}
              className={`px-3.5 py-2 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'cce'
                  ? 'bg-emerald-400 text-slate-950 shadow-md'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>CCE 64th-69th PYQs</span>
            </button>
          </div>
        </div>
      </div>

      {/* ===================== VIEW 1: BPSC TRE PAPERS ===================== */}
      {activeTab === 'tre' && (
        <div className="space-y-6">
          {/* Phase Filter Tabs (TRE 1.0, 2.0, 3.0, 4.0) */}
          <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-2xs space-y-4">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                  <Calendar className="w-4 h-4 text-emerald-700" />
                  <span>{language === 'hi' ? 'परीक्षा चरण (Exam Phase):' : 'Exam Phase:'}</span>
                </span>
                <span className="text-[11px] font-semibold text-slate-400">
                  {selectedPhase === 'TRE 4.0' && !hasVerifiedTRE4Data
                    ? (language === 'hi' ? '0 सत्यापित (शीघ्र उपलब्ध)' : '0 Verified (Coming Soon)')
                    : `${filteredTREPapers.length} ${language === 'hi' ? 'पेपर उपलब्ध' : 'papers available'}`}
                </span>
              </div>
              <div className="flex flex-wrap gap-2">
                {[
                  { id: 'all', label: language === 'hi' ? 'सभी TRE पेपर्स (All)' : 'All TRE Papers' },
                  { id: 'TRE 1.0', label: 'BPSC TRE 1.0 (2023)' },
                  { id: 'TRE 2.0', label: 'BPSC TRE 2.0 (2023)' },
                  { id: 'TRE 3.0', label: 'BPSC TRE 3.0 (2024)' },
                  { 
                    id: 'TRE 4.0', 
                    label: 'BPSC TRE 4.0',
                    isUpcoming: !hasVerifiedTRE4Data,
                    badge: hasVerifiedTRE4Data 
                      ? (language === 'hi' ? 'सत्यापित' : 'Verified') 
                      : (language === 'hi' ? 'शीघ्र' : 'Soon')
                  },
                ].map((phase) => {
                  const isSelected = selectedPhase === phase.id;
                  const isTRE4 = phase.id === 'TRE 4.0';

                  return (
                    <button
                      key={phase.id}
                      onClick={() => setSelectedPhase(phase.id)}
                      className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                        isSelected
                          ? 'bg-emerald-700 text-white shadow-sm ring-2 ring-emerald-600/30'
                          : isTRE4 && !hasVerifiedTRE4Data
                          ? 'bg-amber-50 text-amber-900 border border-amber-200 hover:bg-amber-100'
                          : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                      }`}
                    >
                      <span>{phase.label}</span>
                      {isTRE4 && (
                        <span
                          className={`px-1.5 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider ${
                            hasVerifiedTRE4Data
                              ? 'bg-emerald-400 text-slate-950'
                              : isSelected
                              ? 'bg-amber-400 text-slate-950 font-black'
                              : 'bg-amber-300 text-slate-950'
                          }`}
                        >
                          {phase.badge}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Class Level, Subject, Shift and Search Filters (Active when not in empty TRE 4.0 Coming Soon view) */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-2 border-t border-slate-100">
              {/* Class Level Filter */}
              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  {language === 'hi' ? 'कक्षा स्तर (Class Level)' : 'Class Level'}
                </label>
                <select
                  value={selectedClassLevel}
                  onChange={(e) => setSelectedClassLevel(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900"
                >
                  <option value="all">{language === 'hi' ? 'सभी कक्षाएं (1 से 12)' : 'All Classes (1-12)'}</option>
                  <option value="1-5">{language === 'hi' ? 'कक्षा 1-5 (प्राथमिक PRT)' : 'Class 1-5 (Primary PRT)'}</option>
                  <option value="6-8">{language === 'hi' ? 'कक्षा 6-8 (मध्य विद्यालय TGT)' : 'Class 6-8 (Middle School)'}</option>
                  <option value="9-10">{language === 'hi' ? 'कक्षा 9-10 (माध्यमिक TGT)' : 'Class 9-10 (Secondary)'}</option>
                  <option value="11-12">{language === 'hi' ? 'कक्षा 11-12 (उच्च माध्यमिक PGT)' : 'Class 11-12 (Higher Secondary)'}</option>
                </select>
              </div>

              {/* Subject Filter */}
              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  {language === 'hi' ? 'विषय (Subject)' : 'Subject'}
                </label>
                <select
                  value={selectedTRESubject}
                  onChange={(e) => setSelectedTRESubject(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900"
                >
                  <option value="all">{language === 'hi' ? 'सभी विषय (All Subjects)' : 'All Subjects'}</option>
                  <option value="General Studies">{language === 'hi' ? 'सामान्य अध्ययन (General Studies)' : 'General Studies'}</option>
                  <option value="Social Science">{language === 'hi' ? 'सामाजिक विज्ञान (Social Science)' : 'Social Science'}</option>
                  <option value="Hindi">{language === 'hi' ? 'हिन्दी साहित्य एवं व्याकरण' : 'Hindi'}</option>
                  <option value="Mathematics & Science">{language === 'hi' ? 'गणित एवं विज्ञान' : 'Math & Science'}</option>
                  <option value="English">{language === 'hi' ? 'अंग्रेजी (English)' : 'English'}</option>
                  <option value="Sanskrit">{language === 'hi' ? 'संस्कृत (Sanskrit)' : 'Sanskrit'}</option>
                </select>
              </div>

              {/* Shift Filter */}
              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  {language === 'hi' ? 'पाली (Shift)' : 'Shift'}
                </label>
                <select
                  value={selectedShift}
                  onChange={(e) => setSelectedShift(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900"
                >
                  <option value="all">{language === 'hi' ? 'सभी पाली (All Shifts)' : 'All Shifts'}</option>
                  <option value="Shift 1">{language === 'hi' ? 'प्रथम पाली (Shift 1)' : 'Shift 1'}</option>
                  <option value="Shift 2">{language === 'hi' ? 'द्वितीय पाली (Shift 2)' : 'Shift 2'}</option>
                </select>
              </div>

              {/* Search input */}
              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  {language === 'hi' ? 'कीवर्ड खोजें' : 'Search Paper / Topic'}
                </label>
                <div className="relative">
                  <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder={language === 'hi' ? 'उदा. कुंवर सिंह, 1-5, SST...' : 'Search topic...'}
                    className="w-full pl-8 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* CHECK LOGIC FOR BPSC TRE 4.0: Verified Data vs Coming Soon */}
          {selectedPhase === 'TRE 4.0' && !hasVerifiedTRE4Data ? (
            /* DEDICATED BPSC TRE 4.0 COMING SOON INTERFACE */
            <div className="bg-white rounded-3xl border border-amber-200 shadow-md p-6 sm:p-8 space-y-6 overflow-hidden relative animate-in fade-in duration-200">
              {/* Soft background decor */}
              <div className="absolute top-0 right-0 w-80 h-80 bg-amber-400/10 rounded-full blur-3xl pointer-events-none" />

              {/* Header Box */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-amber-100 pb-5">
                <div className="flex items-start sm:items-center gap-3.5">
                  <div className="w-12 h-12 rounded-2xl bg-amber-500/15 text-amber-800 border border-amber-300 flex items-center justify-center shrink-0 shadow-2xs">
                    <Clock className="w-6 h-6 text-amber-700" />
                  </div>
                  <div>
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="px-2.5 py-0.5 rounded-full bg-amber-400 text-slate-950 text-xs font-black uppercase tracking-wider shadow-2xs">
                        BPSC TRE 4.0
                      </span>
                      <span className="px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-900 border border-amber-200 text-xs font-bold">
                        {language === 'hi' ? 'शीघ्र उपलब्ध • Coming Soon' : 'Coming Soon'}
                      </span>
                      <span className="px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 text-[11px] font-bold flex items-center gap-1">
                        <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                        <span>{language === 'hi' ? '100% प्रामाणिक डेटा नीति' : '100% Verified Policy'}</span>
                      </span>
                    </div>
                    <h3 className="text-xl sm:text-2xl font-black text-slate-900 mt-1">
                      {language === 'hi' ? 'BPSC TRE 4.0 आधिकारिक प्रश्न पत्र' : 'BPSC TRE 4.0 Official Question Papers'}
                    </h3>
                  </div>
                </div>

                <div className="text-left sm:text-right">
                  <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                    {language === 'hi' ? 'स्थिति' : 'Status'}
                  </span>
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-amber-100 text-amber-900 text-xs font-extrabold border border-amber-200 mt-0.5">
                    <Clock className="w-3.5 h-3.5 text-amber-700" />
                    <span>{language === 'hi' ? 'परीक्षा एवं उत्तर कुंजी प्रतीक्षित' : 'Awaiting Exam & Answer Key'}</span>
                  </span>
                </div>
              </div>

              {/* Strict Verified Data Policy Notification */}
              <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-amber-50 to-orange-50/50 border border-amber-200/90 space-y-2">
                <div className="flex items-center gap-2 text-amber-950 font-black text-sm">
                  <AlertCircle className="w-4 h-4 text-amber-700 shrink-0" />
                  <span>
                    {language === 'hi'
                      ? 'सत्यापित डेटा नीति: परीक्षा उपरांत आधिकारिक प्रश्न एवं उत्तर कुंजी ही जोड़ी जाएगी'
                      : 'Verified Data Policy: Authentic Papers Added Only After Exam & Official Answer Key'}
                  </span>
                </div>
                <p className="text-xs sm:text-sm text-slate-700 leading-relaxed">
                  {language === 'hi'
                    ? 'बिहार लोक सेवा आयोग (BPSC) द्वारा TRE 4.0 परीक्षा आयोजित होने तथा आयोग द्वारा आधिकारिक मास्टर प्रश्न पुस्तिका व अनंतिम/अंतिम उत्तर कुंजी (Official Answer Key) जारी करने के उपरांत ही इस अनुभाग में प्रश्न पत्र लाइव किए जाएंगे। हमारे पोर्टल पर कोई भी काल्पनिक, अनौपचारिक या असत्यापित प्रश्न शामिल नहीं किया जाता ताकि आपकी तैयारी 100% शुद्ध और प्रामाणिक रहे।'
                    : 'Official question papers and verified 5-option answer keys will be uploaded and activated immediately after BPSC officially conducts the TRE 4.0 examination and releases official question booklets and answer keys. We maintain zero-tolerance for unverified or fabricated exam questions.'}
                </p>
              </div>

              {/* Upcoming TRE 4.0 Class-wise Structure Roadmap */}
              <div>
                <h4 className="text-xs sm:text-sm font-extrabold text-slate-900 mb-3 flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-amber-600" />
                  <span>{language === 'hi' ? 'TRE 4.0 आगामी कक्षा-वार प्रश्न पत्र रूपरेखा:' : 'Upcoming TRE 4.0 Class-wise Papers Structure:'}</span>
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
                  {/* Class 1-5 PRT */}
                  <div className="p-4 rounded-2xl border border-slate-200 bg-slate-50/80 flex flex-col justify-between">
                    <div>
                      <span className="px-2 py-0.5 rounded-md bg-blue-100 text-blue-900 text-[10px] font-bold">
                        Class 1-5 (PRT)
                      </span>
                      <h5 className="font-black text-sm text-slate-900 mt-2">
                        {language === 'hi' ? 'प्राथमिक शिक्षक (कक्षा 1-5)' : 'Primary Teacher (PRT)'}
                      </h5>
                      <p className="text-xs text-slate-600 mt-1">
                        {language === 'hi' ? 'सामान्य अध्ययन एवं भाषा (150 प्रश्न)' : 'General Studies & Language (150 MCQs)'}
                      </p>
                    </div>
                    <div className="mt-3 pt-2.5 border-t border-slate-200 flex items-center justify-between text-[11px]">
                      <span className="text-slate-500 font-semibold">5 विकल्प (A-E)</span>
                      <span className="text-amber-800 font-bold bg-amber-100 px-2 py-0.5 rounded-full">शीघ्र उपलब्ध</span>
                    </div>
                  </div>

                  {/* Class 6-8 Middle */}
                  <div className="p-4 rounded-2xl border border-slate-200 bg-slate-50/80 flex flex-col justify-between">
                    <div>
                      <span className="px-2 py-0.5 rounded-md bg-purple-100 text-purple-900 text-[10px] font-bold">
                        Class 6-8 (Middle)
                      </span>
                      <h5 className="font-black text-sm text-slate-900 mt-2">
                        {language === 'hi' ? 'मध्य विद्यालय (कक्षा 6-8)' : 'Middle School Teacher'}
                      </h5>
                      <p className="text-xs text-slate-600 mt-1">
                        {language === 'hi' ? 'सामाजिक विज्ञान, गणित-विज्ञान, भाषा' : 'Social Science, Math-Science, Language'}
                      </p>
                    </div>
                    <div className="mt-3 pt-2.5 border-t border-slate-200 flex items-center justify-between text-[11px]">
                      <span className="text-slate-500 font-semibold">5 विकल्प (A-E)</span>
                      <span className="text-amber-800 font-bold bg-amber-100 px-2 py-0.5 rounded-full">शीघ्र उपलब्ध</span>
                    </div>
                  </div>

                  {/* Class 9-10 Secondary */}
                  <div className="p-4 rounded-2xl border border-slate-200 bg-slate-50/80 flex flex-col justify-between">
                    <div>
                      <span className="px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-900 text-[10px] font-bold">
                        Class 9-10 (TGT)
                      </span>
                      <h5 className="font-black text-sm text-slate-900 mt-2">
                        {language === 'hi' ? 'माध्यमिक शिक्षक (कक्षा 9-10)' : 'Secondary School (TGT)'}
                      </h5>
                      <p className="text-xs text-slate-600 mt-1">
                        {language === 'hi' ? 'विषयवार (SST, हिन्दी, विज्ञान, गणित)' : 'Subject-specific (SST, Hindi, Math, etc.)'}
                      </p>
                    </div>
                    <div className="mt-3 pt-2.5 border-t border-slate-200 flex items-center justify-between text-[11px]">
                      <span className="text-slate-500 font-semibold">5 विकल्प (A-E)</span>
                      <span className="text-amber-800 font-bold bg-amber-100 px-2 py-0.5 rounded-full">शीघ्र उपलब्ध</span>
                    </div>
                  </div>

                  {/* Class 11-12 Higher Secondary */}
                  <div className="p-4 rounded-2xl border border-slate-200 bg-slate-50/80 flex flex-col justify-between">
                    <div>
                      <span className="px-2 py-0.5 rounded-md bg-indigo-100 text-indigo-900 text-[10px] font-bold">
                        Class 11-12 (PGT)
                      </span>
                      <h5 className="font-black text-sm text-slate-900 mt-2">
                        {language === 'hi' ? 'उच्च माध्यमिक (कक्षा 11-12)' : 'Higher Secondary (PGT)'}
                      </h5>
                      <p className="text-xs text-slate-600 mt-1">
                        {language === 'hi' ? 'इतिहास, राजनीति, भूगोल, भौतिकी आदि' : 'History, Pol Sci, Geo, Physics, etc.'}
                      </p>
                    </div>
                    <div className="mt-3 pt-2.5 border-t border-slate-200 flex items-center justify-between text-[11px]">
                      <span className="text-slate-500 font-semibold">5 विकल्प (A-E)</span>
                      <span className="text-amber-800 font-bold bg-amber-100 px-2 py-0.5 rounded-full">शीघ्र उपलब्ध</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Quick CTA to practice available TRE 3.0, 2.0, 1.0 papers */}
              <div className="p-5 rounded-2xl bg-gradient-to-r from-emerald-950 via-teal-950 to-slate-900 text-white flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border border-emerald-800/80">
                <div>
                  <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-bold mb-1.5 border border-emerald-500/30">
                    <ShieldCheck className="w-3 h-3" />
                    <span>सत्यापित विगत प्रश्न पत्र उपलब्ध हैं</span>
                  </div>
                  <h5 className="font-black text-sm sm:text-base text-white">
                    {language === 'hi' ? 'तब तक BPSC TRE 3.0, 2.0 और 1.0 के सत्यापित पेपर्स हल करें' : 'Meanwhile, practice verified BPSC TRE 3.0, 2.0 & 1.0 papers'}
                  </h5>
                  <p className="text-xs text-emerald-200/90 mt-0.5">
                    {language === 'hi' ? 'वास्तविक परीक्षा पैटर्न, टाइमर और 5 विकल्पों (A-E) के साथ तुरंत ऑनलाइन टेस्ट दें।' : 'Solidify your preparation with authentic BPSC 5-option questions, timer, and official answer keys.'}
                  </p>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    onClick={handleResetFilters}
                    className="px-4 py-2.5 bg-emerald-400 hover:bg-emerald-300 text-slate-950 font-black rounded-xl text-xs flex items-center gap-2 shrink-0 shadow-md transition-all cursor-pointer"
                  >
                    <Play className="w-3.5 h-3.5 fill-slate-950" />
                    <span>{language === 'hi' ? 'उपलब्ध TRE पेपर्स हल करें' : 'View Available TRE Papers'}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => setActiveTab('cce')}
                    className="px-3.5 py-2.5 bg-white/10 hover:bg-white/20 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Layers className="w-3.5 h-3.5 text-emerald-300" />
                    <span>CCE 64th-69th PYQs</span>
                  </button>
                </div>
              </div>
            </div>
          ) : filteredTREPapers.length === 0 ? (
            /* Empty Filter Result State */
            <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-slate-100 text-slate-500 flex items-center justify-center mx-auto">
                <Search className="w-6 h-6" />
              </div>
              <h4 className="font-extrabold text-slate-900 text-base">
                {language === 'hi' ? 'चयनित फ़िल्टर के अनुसार कोई प्रश्न पत्र नहीं मिला' : 'No Papers Found for Current Filters'}
              </h4>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                {language === 'hi'
                  ? 'कृपया कक्षा स्तर, विषय या पाली का चयन बदलें या फ़िल्टर रीसेट करें।'
                  : 'Try changing the class level, subject, shift, or search keyword.'}
              </p>
              <button
                onClick={handleResetFilters}
                className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl text-xs inline-flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>{language === 'hi' ? 'सभी फ़िल्टर रीसेट करें' : 'Reset All Filters'}</span>
              </button>
            </div>
          ) : (
            /* Papers Cards Grid */
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredTREPapers.map((paper) => {
                const isUpcoming = paper.isComingSoon || paper.questions.length === 0;

                return (
                  <div
                    key={paper.id}
                    className={`rounded-2xl border p-5 flex flex-col justify-between transition-all ${
                      isUpcoming
                        ? 'bg-amber-50/40 border-amber-200 hover:border-amber-300'
                        : 'bg-white border-slate-200 hover:border-emerald-300 hover:shadow-md'
                    }`}
                  >
                    <div>
                      {/* Header Badges */}
                      <div className="flex flex-wrap items-center justify-between gap-2 mb-2.5">
                        <div className="flex flex-wrap items-center gap-1.5">
                          <span className="px-2.5 py-0.5 rounded-full bg-emerald-700 text-white text-[11px] font-black">
                            {paper.phase}
                          </span>
                          <span className="px-2 py-0.5 rounded-md bg-blue-100 text-blue-900 text-[10px] font-bold">
                            {language === 'hi' ? `कक्षा ${paper.classLevel}` : `Class ${paper.classLevel}`}
                          </span>
                          <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 text-[10px] font-bold">
                            {paper.shift}
                          </span>
                          {paper.examDate && (
                            <span className="text-[10px] text-slate-400 font-medium">
                              • {paper.examDate}
                            </span>
                          )}
                        </div>

                        {isUpcoming ? (
                          <span className="px-2 py-0.5 rounded-full bg-amber-400 text-slate-950 text-[10px] font-black uppercase flex items-center gap-1 shadow-2xs">
                            <Clock className="w-3 h-3" />
                            <span>Coming Soon</span>
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold flex items-center gap-1">
                            <ShieldCheck className="w-3 h-3 text-emerald-600" />
                            <span>BPSC Verified</span>
                          </span>
                        )}
                      </div>

                      {/* Paper Title */}
                      <h3 className="font-extrabold text-slate-900 text-sm sm:text-base leading-snug">
                        {language === 'hi' ? paper.titleHindi : paper.title}
                      </h3>
                      <p className="text-xs text-slate-500 mt-1 font-medium">
                        {language === 'hi' ? `विषय: ${paper.subjectHindi}` : `Subject: ${paper.subject}`}
                      </p>

                      {/* Question Meta Chips */}
                      <div className="flex flex-wrap items-center gap-2 mt-3 text-[11px] font-semibold text-slate-600">
                        <div className="flex items-center gap-1 bg-slate-50 border border-slate-100 px-2 py-1 rounded-lg">
                          <FileText className="w-3.5 h-3.5 text-emerald-700" />
                          <span>{isUpcoming ? '150 प्रश्न (प्रस्तावित)' : `${paper.questions.length} प्रश्न`}</span>
                        </div>
                        <div className="flex items-center gap-1 bg-slate-50 border border-slate-100 px-2 py-1 rounded-lg">
                          <Clock className="w-3.5 h-3.5 text-blue-700" />
                          <span>{paper.durationMinutes} मिनट</span>
                        </div>
                        <div className="flex items-center gap-1 bg-slate-50 border border-slate-100 px-2 py-1 rounded-lg">
                          <span className="font-bold text-rose-700">5 विकल्प:</span>
                          <span>A, B, C, D, E</span>
                        </div>
                      </div>

                      {/* Coming Soon Note if applicable */}
                      {isUpcoming && (
                        <div className="mt-3 p-2.5 rounded-xl bg-amber-100/70 border border-amber-200 text-amber-900 text-xs font-medium flex items-start gap-2">
                          <AlertCircle className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                          <span>
                            {language === 'hi'
                              ? 'BPSC TRE 4.0 परीक्षा एवं आयोग द्वारा उत्तर कुंजी जारी होते ही सत्यापित प्रश्न यहाँ लाइव हो जाएंगे। कोई काल्पनिक प्रश्न नहीं।'
                              : 'This paper will be populated once BPSC TRE 4.0 is officially conducted and verified answer keys are released.'}
                          </span>
                        </div>
                      )}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center gap-2 mt-4 pt-3 border-t border-slate-100">
                      {isUpcoming ? (
                        <button
                          disabled
                          className="flex-1 py-2 bg-slate-200 text-slate-400 font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 cursor-not-allowed"
                        >
                          <Clock className="w-3.5 h-3.5" />
                          <span>{language === 'hi' ? 'शीघ्र उपलब्ध होगा' : 'Coming Soon'}</span>
                        </button>
                      ) : (
                        <>
                          <button
                            onClick={() => handleStartTREPaperTest(paper)}
                            className="flex-1 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-sm transition-all cursor-pointer"
                          >
                            <Play className="w-3.5 h-3.5 fill-white" />
                            <span>{language === 'hi' ? 'ऑनलाइन टेस्ट शुरू करें' : 'Start Online Test'}</span>
                          </button>

                          <button
                            onClick={() => setViewingPdfPaper(paper)}
                            className="px-3.5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold rounded-xl text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                            title="View PDF / Answer Key"
                          >
                            <Eye className="w-3.5 h-3.5 text-slate-600" />
                            <span>{language === 'hi' ? 'PDF देखें' : 'View PDF'}</span>
                          </button>
                        </>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* ===================== VIEW 2: CCE 64TH-69TH PYQS ===================== */}
      {activeTab === 'cce' && (
        <div className="space-y-6">
          <div className="space-y-3 bg-white rounded-2xl border border-slate-200 p-4 shadow-2xs">
            {/* Exam Year Filter */}
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-2">
                {language === 'hi' ? 'BPSC CCE परीक्षा वर्ष चुनें:' : 'Filter by Exam / Year:'}
              </label>
              <div className="flex flex-wrap gap-1.5">
                {availableExams.map((exam) => (
                  <button
                    key={exam.id}
                    onClick={() => setSelectedYear(exam.id)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                      selectedYear === exam.id
                        ? 'bg-emerald-700 text-white shadow-2xs'
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                  >
                    {exam.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Subject Filter Chips */}
            <div className="pt-2 border-t border-slate-100">
              <label className="text-xs font-bold text-slate-700 block mb-2">
                {language === 'hi' ? 'विषय चुनें:' : 'Filter by Subject:'}
              </label>
              <div className="flex flex-wrap gap-1.5">
                <button
                  onClick={() => setSelectedSubject('all')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                    selectedSubject === 'all'
                      ? 'bg-slate-900 text-white shadow-2xs'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  {language === 'hi' ? 'सभी विषय' : 'All Subjects'}
                </button>
                {BPSC_SUBJECTS.map((subj) => (
                  <button
                    key={subj.id}
                    onClick={() => setSelectedSubject(subj.id)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                      selectedSubject === subj.id
                        ? 'bg-slate-900 text-white shadow-2xs'
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                  >
                    {language === 'hi' ? subj.nameHindi : subj.nameEnglish}
                  </button>
                ))}
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                onClick={handleStartPYQTest}
                disabled={filteredPYQs.length === 0}
                className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 cursor-pointer"
              >
                <Play className="w-3.5 h-3.5 fill-white" />
                <span>{language === 'hi' ? 'CCE PYQ टेस्ट शुरू करें' : 'Start CCE Test'}</span>
              </button>
            </div>
          </div>

          {/* CCE Question Cards */}
          <div className="space-y-4">
            {filteredPYQs.map((q, idx) => {
              const isSolOpen = expandedSolutions[q.id];
              const bookmarked = isBookmarked(q.id);
              const subj = BPSC_SUBJECTS.find((s) => s.id === q.subjectId);

              return (
                <div
                  key={q.id}
                  className="bg-white rounded-2xl border border-slate-200 p-5 shadow-2xs space-y-3.5"
                >
                  <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <span className="font-extrabold px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 text-[11px]">
                        {q.source}
                      </span>
                      <span className="font-semibold text-slate-500">
                        {language === 'hi' ? subj?.nameHindi : subj?.nameEnglish} • {q.topic}
                      </span>
                    </div>

                    <button
                      onClick={() => toggleBookmark(q.id)}
                      className={`p-1.5 rounded-lg border transition-colors cursor-pointer ${
                        bookmarked
                          ? 'bg-red-50 text-red-700 border-red-200'
                          : 'bg-slate-50 text-slate-400 border-slate-200 hover:text-slate-600'
                      }`}
                      title={bookmarked ? t('bookmarked') : t('bookmark')}
                    >
                      <Bookmark className={`w-4 h-4 ${bookmarked ? 'fill-red-700' : ''}`} />
                    </button>
                  </div>

                  <p className="font-bold text-slate-900 text-sm sm:text-base leading-relaxed">
                    <span className="font-mono text-emerald-800 mr-1.5">Q{idx + 1}.</span>
                    {q.questionHindi}
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                    {q.optionsHindi.map((opt, oIdx) => {
                      const letter = optionLetters[oIdx];
                      const isCorrect = isSolOpen && letter === q.correctAnswer;

                      return (
                        <div
                          key={letter}
                          className={`p-3 rounded-xl border text-xs sm:text-sm font-medium transition-colors flex items-start gap-2.5 ${
                            isCorrect
                              ? 'bg-emerald-50 border-emerald-300 text-emerald-950 font-bold'
                              : 'bg-slate-50 border-slate-200 text-slate-800'
                          }`}
                        >
                          <span
                            className={`w-6 h-6 rounded-lg text-xs font-black flex items-center justify-center shrink-0 ${
                              isCorrect
                                ? 'bg-emerald-600 text-white'
                                : 'bg-slate-200 text-slate-700'
                            }`}
                          >
                            {letter}
                          </span>
                          <span className="mt-0.5">{opt}</span>
                        </div>
                      );
                    })}
                  </div>

                  <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                    <button
                      onClick={() => toggleSolution(q.id)}
                      className="text-xs font-bold text-emerald-700 hover:text-emerald-900 flex items-center gap-1 cursor-pointer"
                    >
                      <span>{isSolOpen ? t('hideSolution') : t('showSolution')}</span>
                    </button>
                  </div>

                  {isSolOpen && (
                    <div className="p-4 rounded-xl bg-emerald-50/70 border border-emerald-200 space-y-2 text-xs">
                      <div className="flex items-center gap-1.5 text-emerald-900 font-extrabold">
                        <CheckCircle2 className="w-4 h-4 text-emerald-700" />
                        <span>
                          {language === 'hi' ? 'आधिकारिक सही उत्तर' : 'Official Answer'}: विकल्प ({q.correctAnswer})
                        </span>
                      </div>
                      <p className="text-slate-800 leading-relaxed font-serif text-[13px]">
                        {q.explanationHindi}
                      </p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ===================== MODAL: VIEW PDF & QUESTION BOOKLET ===================== */}
      {viewingPdfPaper && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
          <div className="bg-white w-full max-w-3xl rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-auto max-h-[90vh] flex flex-col">
            {/* Modal Header */}
            <div className="bg-gradient-to-r from-emerald-950 via-teal-950 to-slate-900 text-white p-5 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-300 flex items-center justify-center font-black">
                  <FileText className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded-full bg-emerald-500 text-slate-950 text-[10px] font-black uppercase">
                      {viewingPdfPaper.phase}
                    </span>
                    <span className="text-xs text-emerald-300 font-semibold">
                      Class {viewingPdfPaper.classLevel} • {viewingPdfPaper.shift}
                    </span>
                  </div>
                  <h3 className="font-black text-sm sm:text-base text-white mt-0.5 line-clamp-1">
                    {language === 'hi' ? viewingPdfPaper.titleHindi : viewingPdfPaper.title}
                  </h3>
                </div>
              </div>
              <button
                onClick={() => setViewingPdfPaper(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-5 sm:p-6 overflow-y-auto space-y-5 flex-1">
              {/* Official notice box */}
              <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div>
                  <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-900">
                    <ShieldCheck className="w-4 h-4 text-emerald-700" />
                    <span>बिहार लोक सेवा आयोग (BPSC) आधिकारिक प्रश्न पुस्तिका</span>
                  </div>
                  <p className="text-[11px] text-emerald-800 mt-0.5">
                    यह प्रश्न पत्र BPSC द्वारा आयोजित वास्तविक शिक्षक भर्ती परीक्षा (TRE) की सत्यापित प्रश्न पुस्तिका पर आधारित है।
                  </p>
                </div>
                <a
                  href="https://www.bpsc.bih.nic.in"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-3.5 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shrink-0 transition-colors"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>BPSC आधिकारिक पोर्टल</span>
                </a>
              </div>

              {/* Questions Preview List */}
              <div className="space-y-4">
                <h4 className="font-bold text-slate-900 text-xs sm:text-sm flex items-center justify-between">
                  <span>प्रश्न पुस्तिका प्रश्न एवं आधिकारिक उत्तर कुंजी (A-E):</span>
                  <span className="text-slate-500 text-xs">{viewingPdfPaper.questions.length} प्रश्न</span>
                </h4>

                {viewingPdfPaper.questions.map((q, idx) => (
                  <div key={q.id} className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 space-y-2.5 text-xs">
                    <p className="font-bold text-slate-900 text-xs sm:text-sm">
                      <span className="font-mono text-emerald-800 mr-1.5">{idx + 1}.</span>
                      {q.questionHindi}
                    </p>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                      {q.optionsHindi.map((opt, oIdx) => {
                        const letter = optionLetters[oIdx];
                        const isCorrect = letter === q.correctAnswer;

                        return (
                          <div
                            key={letter}
                            className={`p-2 rounded-lg border text-xs flex items-center gap-2 ${
                              isCorrect
                                ? 'bg-emerald-50 border-emerald-300 text-emerald-950 font-bold'
                                : 'bg-white border-slate-200 text-slate-700'
                            }`}
                          >
                            <span className={`w-5 h-5 rounded text-[10px] font-black flex items-center justify-center shrink-0 ${
                              isCorrect ? 'bg-emerald-700 text-white' : 'bg-slate-200 text-slate-700'
                            }`}>
                              {letter}
                            </span>
                            <span className="line-clamp-1">{opt}</span>
                          </div>
                        );
                      })}
                    </div>

                    <div className="p-2.5 rounded-lg bg-emerald-50/60 border border-emerald-200/60 text-[11px] text-slate-800">
                      <span className="font-bold text-emerald-800">व्याख्या:</span> {q.explanationHindi}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between shrink-0">
              <button
                onClick={() => setViewingPdfPaper(null)}
                className="px-4 py-2 border border-slate-300 text-slate-700 font-bold rounded-xl text-xs hover:bg-slate-100 cursor-pointer"
              >
                {language === 'hi' ? 'बंद करें' : 'Close'}
              </button>

              <button
                onClick={() => {
                  const paper = viewingPdfPaper;
                  setViewingPdfPaper(null);
                  handleStartTREPaperTest(paper);
                }}
                className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold rounded-xl text-xs flex items-center gap-1.5 shadow-sm transition-all cursor-pointer"
              >
                <Play className="w-3.5 h-3.5 fill-white" />
                <span>{language === 'hi' ? 'यह टेस्ट अभी हल करें' : 'Take This Paper Now'}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
