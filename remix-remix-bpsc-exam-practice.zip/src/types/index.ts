export type Language = 'hi' | 'en';

export type OptionKey = 'A' | 'B' | 'C' | 'D' | 'E';

export interface Question {
  id: string;
  subjectId: string;
  topic: string;
  questionHindi: string;
  questionEnglish: string;
  optionsHindi: [string, string, string, string, string]; // Exactly 5 options: [A, B, C, D, E]
  optionsEnglish: [string, string, string, string, string]; // [A, B, C, D, E]
  correctAnswer: OptionKey;
  explanationHindi: string;
  explanationEnglish: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  source: string; // e.g., "69th BPSC Prelims 2023", "BPSC 68th CCE"
  year?: number;
  isPYQ: boolean;
  isAIGenerated?: boolean;
  verified?: boolean;
  isImported?: boolean;
  importedAt?: string;
  isDemo?: boolean;
  createdAt?: string;
}

export interface Subject {
  id: string;
  nameHindi: string;
  nameEnglish: string;
  descriptionHindi: string;
  descriptionEnglish: string;
  iconName: string;
  color: string;
  bgColor: string;
  borderColor: string;
  totalQuestionsCount?: number;
}

export type TestMode = 'exam' | 'practice';

export interface TestSettings {
  questionCount: number; // 10, 25, 50, 100
  subjects: string[]; // subjectIds
  mode: TestMode;
  negativeMarking: number; // 0, 0.25, 0.33
  timeLimitMinutes: number; // 0 for untimed, or positive integer
  shuffleQuestions: boolean;
  shuffleOptions: boolean;
  pyqOnly?: boolean;
  topic?: string;
}

export interface UserAnswerRecord {
  questionId: string;
  selectedOption: OptionKey | null;
  isMarkedForReview: boolean;
  timeSpentSeconds: number;
  isCorrect?: boolean;
}

export interface TestResult {
  id: string;
  testTitle: string;
  mode: TestMode;
  totalQuestions: number;
  attempted: number;
  correct: number;
  incorrect: number;
  unanswered: number;
  score: number;
  maxScore: number;
  negativeMarking: number;
  percentage: number;
  timeTakenSeconds: number;
  completedAt: string;
  subjectBreakdown: {
    [subjectId: string]: {
      total: number;
      correct: number;
      incorrect: number;
      unanswered: number;
    };
  };
  answers: Record<string, UserAnswerRecord>;
  questions: Question[];
}

export interface StudentProfile {
  name: string;
  targetExam: string;
  studyStreakDays: number;
  longestStreakDays: number;
  lastQuizCompletionDate: string; // YYYY-MM-DD when user completed at least one quiz
  completedQuizDates: string[]; // YYYY-MM-DD dates of all days with at least one completed quiz
  testsCompleted: number;
  totalQuestionsPracticed: number;
  bookmarks: string[]; // Question IDs
  notes: Record<string, string>; // questionId -> personal note
  incorrectQuestionIds: string[]; // History of missed questions
}

export type UserRole = 'student' | 'admin';

export interface AppUser {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  createdAt: string;
  targetExam?: string;
}

export interface MockTestTemplate {
  id: string;
  title: string;
  titleHindi: string;
  description: string;
  subjectIds: string[];
  questionCount: number;
  timeLimitMinutes: number;
  negativeMarking: number;
  totalMarks: number;
  isFullLength: boolean;
  createdBy?: string;
  createdAt: string;
}

export interface AdminSystemStats {
  totalStudents: number;
  totalQuestions: number;
  totalSubjects: number;
  totalMockTests: number;
  totalTREPapers?: number;
  totalTestsTaken: number;
  averageScore: number;
  recentResults: Array<{
    id: string;
    studentName: string;
    studentEmail: string;
    testTitle: string;
    score: number;
    maxScore: number;
    percentage: number;
    completedAt: string;
  }>;
}

export type TREPhase = 'TRE 1.0' | 'TRE 2.0' | 'TRE 3.0' | 'TRE 4.0';
export type TREClassLevel = '1-5' | '6-8' | '9-10' | '11-12';
export type TREShift = 'Shift 1' | 'Shift 2' | 'General';

export interface TREPaper {
  id: string;
  title: string;
  titleHindi: string;
  phase: TREPhase;
  year: number;
  classLevel: TREClassLevel;
  subject: string;
  subjectHindi: string;
  shift: TREShift;
  examDate?: string;
  totalQuestions: number;
  durationMinutes: number;
  negativeMarking: number;
  pdfUrl?: string;
  answerKeyPdfUrl?: string;
  isVerified: boolean;
  isPublished: boolean;
  isComingSoon?: boolean;
  questions: Question[];
}


