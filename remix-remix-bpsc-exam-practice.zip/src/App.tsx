import React, { useState } from 'react';
import { LanguageProvider, useLanguage } from './context/LanguageContext';
import { QuestionProvider } from './context/QuestionContext';
import { UserProvider, useUser } from './context/UserContext';
import { TestProvider, useTest } from './context/TestContext';

import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { StudentDashboard } from './components/StudentDashboard';
import { SubjectGrid } from './components/SubjectGrid';
import { PYQSection } from './components/PYQSection';
import { MistakesRevision } from './components/MistakesRevision';
import { BookmarksView } from './components/BookmarksView';
import { TestRunner } from './components/TestRunner';
import { TestResults } from './components/TestResults';
import { TestConfigModal } from './components/TestConfigModal';
import { StudentProfileModal } from './components/StudentProfileModal';
import { AdminQuestionBank } from './components/AdminQuestionBank';
import { AuthModal } from './components/AuthModal';

const MainAppContent: React.FC = () => {
  const { language } = useLanguage();
  const { activeTest, lastTestResult, setLastTestResult } = useTest();
  const { userRole, isLoggedIn } = useUser();

  // Navigation tab: 'home' | 'practice' | 'pyq' | 'mistakes' | 'bookmarks' | 'admin'
  const [currentTab, setCurrentTab] = useState<string>('home');

  // Modals state
  const [isConfigModalOpen, setIsConfigModalOpen] = useState<boolean>(false);
  const [configPresetSubjectId, setConfigPresetSubjectId] = useState<string | undefined>(undefined);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState<boolean>(false);
  const [isAdminModalOpen, setIsAdminModalOpen] = useState<boolean>(false);

  const handleOpenConfigModal = (subjectId?: string) => {
    setConfigPresetSubjectId(subjectId);
    setIsConfigModalOpen(true);
  };

  // If in an active test session, show full TestRunner
  if (activeTest) {
    return <TestRunner />;
  }

  // If viewing test results
  if (lastTestResult) {
    return (
      <TestResults
        result={lastTestResult}
        onBackToHome={() => {
          setLastTestResult(null);
          setCurrentTab('home');
        }}
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col antialiased selection:bg-amber-100 selection:text-amber-900 pb-20 md:pb-6 overflow-x-hidden w-full max-w-full">
      {/* Top Header */}
      <Header
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        openProfileModal={() => setIsProfileModalOpen(true)}
        openAdminModal={() => setIsAdminModalOpen(true)}
      />

      {/* Main Page Container */}
      <main className="flex-1 max-w-7xl mx-auto w-full px-3 sm:px-6 py-4 sm:py-6">
        {/* Tab 1: Home / Student Dashboard (or Admin Dashboard if admin prefers) */}
        {currentTab === 'home' && (
          userRole === 'admin' ? (
            <AdminQuestionBank 
              isStandalonePage={true} 
              initialTab="overview" 
              onClose={() => setCurrentTab('home')} 
            />
          ) : (
            <StudentDashboard
              onOpenConfigModal={handleOpenConfigModal}
              onNavigateTab={(tab) => setCurrentTab(tab)}
            />
          )
        )}

        {/* Tab 2: Subject-wise practice */}
        {currentTab === 'practice' && (
          <div className="space-y-6">
            <div className="bg-gradient-to-r from-red-800 to-amber-700 text-white rounded-3xl p-5 sm:p-7 shadow-md">
              <h2 className="text-xl sm:text-2xl font-black mb-1">
                {language === 'hi' ? 'विषयवार एवं अध्यायवार अभ्यास' : 'Subject-wise MCQ Practice'}
              </h2>
              <p className="text-xs sm:text-sm text-red-100 max-w-xl">
                {language === 'hi' 
                  ? 'BPSC पाठ्यक्रम के 11 प्रमुख विषयों का अभ्यास करें। प्रत्येक प्रश्न में 5 विकल्प और देवनागरी में स्पष्ट व्याख्या है।'
                  : 'Practice all 11 core subjects with standard 5-option questions and authentic explanations.'}
              </p>
            </div>
            <SubjectGrid
              onSelectSubject={(subjId) => {
                handleOpenConfigModal(subjId);
              }}
            />
          </div>
        )}

        {/* Tab 3: Previous Year Questions (PYQ) */}
        {currentTab === 'pyq' && <PYQSection />}

        {/* Tab 4: Mistakes Revision */}
        {currentTab === 'mistakes' && <MistakesRevision />}

        {/* Tab 5: Bookmarks */}
        {currentTab === 'bookmarks' && <BookmarksView />}

        {/* Tab 6: Admin Assessment Controller & Question Bank Import */}
        {(currentTab === 'admin' || currentTab === 'import') && (
          <AdminQuestionBank 
            isStandalonePage={true} 
            initialTab={userRole === 'admin' ? 'overview' : 'import'} 
            onClose={() => setCurrentTab('home')} 
          />
        )}
      </main>

      {/* Mobile Bottom Navigation Bar */}
      <BottomNav currentTab={currentTab} setCurrentTab={setCurrentTab} />

      {/* Auth Modal for Student/Admin Login, Registration & Demo */}
      <AuthModal
        onLoginSuccess={(role) => {
          if (role === 'admin') {
            setCurrentTab('admin');
          } else {
            setCurrentTab('home');
          }
        }}
      />

      {/* Test Config Modal */}
      <TestConfigModal
        isOpen={isConfigModalOpen}
        onClose={() => setIsConfigModalOpen(false)}
        presetSubjectId={configPresetSubjectId}
      />

      {/* Student Profile & Settings Modal */}
      <StudentProfileModal
        isOpen={isProfileModalOpen}
        onClose={() => setIsProfileModalOpen(false)}
      />

      {/* Admin Question Bank & Bulk Import Modal */}
      <AdminQuestionBank
        isOpen={isAdminModalOpen}
        initialTab="import"
        onClose={() => setIsAdminModalOpen(false)}
      />
    </div>
  );
};

export default function App() {
  return (
    <LanguageProvider>
      <UserProvider>
        <QuestionProvider>
          <TestProvider>
            <MainAppContent />
          </TestProvider>
        </QuestionProvider>
      </UserProvider>
    </LanguageProvider>
  );
}
