import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Question } from '../types';
import { INITIAL_QUESTIONS } from '../data/initialQuestions';
import { normalizeHindiText, normalizeSubjectId } from '../utils/questionImporter';

interface QuestionContextType {
  questions: Question[];
  isLoading: boolean;
  addQuestion: (question: Omit<Question, 'id'>) => Promise<Question>;
  updateQuestion: (id: string, question: Partial<Question>) => Promise<void>;
  deleteQuestion: (id: string) => Promise<void>;
  bulkImportQuestions: (newQuestions: Question[]) => Promise<number>;
  resetToDefault: () => void;
  getQuestionById: (id: string) => Question | undefined;
  getQuestionsBySubject: (subjectId: string) => Question[];
  getPYQQuestions: () => Question[];
}

const QuestionContext = createContext<QuestionContextType | undefined>(undefined);

const STORAGE_KEY = 'bpsc_question_bank_v2';

const initializeQuestions = (): Question[] => {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed) && parsed.length > 0) {
        // Ensure all verified initial questions exist alongside any imported questions
        const parsedIds = new Set(parsed.map((q: Question) => q.id));
        const parsedTexts = new Set(parsed.map((q: Question) => normalizeHindiText(q.questionHindi)).filter(Boolean));
        const missingInitials = INITIAL_QUESTIONS.filter((q) => !parsedIds.has(q.id) && !parsedTexts.has(normalizeHindiText(q.questionHindi)));
        if (missingInitials.length > 0) {
          const merged = [...parsed, ...missingInitials];
          try {
            localStorage.setItem(STORAGE_KEY, JSON.stringify(merged));
          } catch {
            // ignore
          }
          return merged;
        }
        return parsed;
      }
    }
  } catch {
    // ignore
  }
  return INITIAL_QUESTIONS;
};

export const QuestionProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [questions, setQuestions] = useState<Question[]>(initializeQuestions);

  const [isLoading, setIsLoading] = useState<boolean>(false);

  // Sync with backend API (data/questions.json) if accessible
  useEffect(() => {
    const fetchFromAPI = async () => {
      try {
        const res = await fetch('/api/questions');
        if (res.ok) {
          const data = await res.json();
          if (Array.isArray(data) && data.length > 0) {
            setQuestions((current) => {
              const currentIds = new Set(current.map((q) => q.id));
              const currentTexts = new Set(current.map((q) => normalizeHindiText(q.questionHindi)).filter(Boolean));
              const newFromApi = data.filter((q: Question) => {
                if (currentIds.has(q.id)) return false;
                const norm = normalizeHindiText(q.questionHindi);
                if (norm && currentTexts.has(norm)) return false;
                return true;
              });

              if (newFromApi.length > 0) {
                const combined = [...current, ...newFromApi];
                try {
                  localStorage.setItem(STORAGE_KEY, JSON.stringify(combined));
                } catch {
                  // ignore
                }
                return combined;
              }
              return current;
            });
          }
        }
      } catch {
        // Fallback to local questions
      }
    };
    fetchFromAPI();
  }, []);

  // Save to local storage whenever questions change
  const saveQuestions = (updated: Question[]) => {
    setQuestions(updated);
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    } catch (err) {
      console.error('Failed to save questions to localStorage', err);
    }
  };

  const getAuthHeaders = (): Record<string, string> => {
    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    const token = localStorage.getItem('bpsc_auth_token_v1');
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }
    return headers;
  };

  const addQuestion = async (q: Omit<Question, 'id'>): Promise<Question> => {
    const newQuestion: Question = {
      ...q,
      id: 'custom-' + Date.now() + '-' + Math.random().toString(36).substr(2, 4),
      createdAt: new Date().toISOString(),
      verified: q.verified ?? !q.isAIGenerated,
    };

    const updated = [newQuestion, ...questions];
    saveQuestions(updated);

    // Sync with backend
    try {
      await fetch('/api/questions', {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify(newQuestion),
      });
    } catch {
      // server sync optional in demo
    }

    return newQuestion;
  };

  const updateQuestion = async (id: string, updates: Partial<Question>): Promise<void> => {
    const updated = questions.map((q) => (q.id === id ? { ...q, ...updates } : q));
    saveQuestions(updated);

    try {
      await fetch(`/api/questions/${id}`, {
        method: 'PUT',
        headers: getAuthHeaders(),
        body: JSON.stringify(updates),
      });
    } catch {
      // server sync optional
    }
  };

  const deleteQuestion = async (id: string): Promise<void> => {
    const updated = questions.filter((q) => q.id !== id);
    saveQuestions(updated);

    try {
      await fetch(`/api/questions/${id}`, {
        method: 'DELETE',
        headers: getAuthHeaders(),
      });
    } catch {
      // server sync optional
    }
  };

  const bulkImportQuestions = async (newQuestions: Question[]): Promise<number> => {
    // Validate each question has Hindi text, exactly 5 options, valid answer and explanation
    const valid = newQuestions.filter(
      (q) =>
        q.questionHindi &&
        q.questionHindi.trim().length > 0 &&
        Array.isArray(q.optionsHindi) &&
        q.optionsHindi.length === 5 &&
        q.optionsHindi.every((opt) => String(opt || '').trim().length > 0) &&
        ['A', 'B', 'C', 'D', 'E'].includes(q.correctAnswer) &&
        q.explanationHindi &&
        q.explanationHindi.trim().length > 0
    );

    if (valid.length === 0) return 0;

    // Deduplicate against existing questions in state
    const existingIds = new Set(questions.map((q) => q.id));
    const existingTexts = new Set(questions.map((q) => normalizeHindiText(q.questionHindi)).filter(Boolean));
    const toAdd: Question[] = [];

    for (const q of valid) {
      const norm = normalizeHindiText(q.questionHindi);
      if (existingIds.has(q.id) || (norm && existingTexts.has(norm))) {
        continue; // Skip duplicate question
      }

      const id = q.id && !existingIds.has(q.id) ? q.id : 'imp-' + Date.now() + '-' + Math.random().toString(36).substr(2, 5);
      existingIds.add(id);
      if (norm) existingTexts.add(norm);

      toAdd.push({
        ...q,
        id,
        isImported: true,
        subjectId: normalizeSubjectId(q.subjectId),
        createdAt: q.createdAt || new Date().toISOString(),
      });
    }

    if (toAdd.length === 0) return 0;

    const merged = [...toAdd, ...questions];
    saveQuestions(merged);

    try {
      await fetch('/api/questions/bulk', {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify(toAdd),
      });
    } catch {
      // Local storage already saved as primary persistent copy
    }

    return toAdd.length;
  };

  const resetToDefault = () => {
    saveQuestions(INITIAL_QUESTIONS);
  };

  const getQuestionById = (id: string) => questions.find((q) => q.id === id);

  const getQuestionsBySubject = (subjectId: string) =>
    questions.filter((q) => q.subjectId === subjectId);

  const getPYQQuestions = () => questions.filter((q) => q.isPYQ);

  return (
    <QuestionContext.Provider
      value={{
        questions,
        isLoading,
        addQuestion,
        updateQuestion,
        deleteQuestion,
        bulkImportQuestions,
        resetToDefault,
        getQuestionById,
        getQuestionsBySubject,
        getPYQQuestions,
      }}
    >
      {children}
    </QuestionContext.Provider>
  );
};

export const useQuestions = (): QuestionContextType => {
  const context = useContext(QuestionContext);
  if (!context) {
    throw new Error('useQuestions must be used within a QuestionProvider');
  }
  return context;
};
