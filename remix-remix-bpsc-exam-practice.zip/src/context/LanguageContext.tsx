import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Language } from '../types';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  toggleLanguage: () => void;
  t: (key: string) => string;
}

const translations: Record<Language, Record<string, string>> = {
  hi: {
    // App Branding
    appName: 'BPSC TRE परीक्षा अभ्यास',
    appTagline: 'बिहार लोक सेवा आयोग एवं राज्य स्तरीय प्रतियोगी परीक्षाओं की सर्वोत्तम तैयारी',
    prelimsTarget: '71वीं BPSC संयुक्त प्रारंभिक परीक्षा 2025-26',

    // Nav
    navHome: 'होम',
    navPractice: 'अभ्यास सेट',
    navMockTests: 'मॉक टेस्ट',
    navPYQ: 'पिछले वर्ष के प्रश्न',
    navMistakes: 'गलती सुधार',
    navBookmarks: 'बुकमार्क',
    navAdmin: 'प्रश्न बैंक (Admin)',
    navProfile: 'मेरी प्रगति',

    // Home / Hero
    heroTitle: 'BPSC परीक्षा में सफलता की रणनीति',
    heroSubtitle: 'प्रामाणिक 5-विकल्प आधारित प्रश्न, नकारात्मक अंकन विकल्प, और विस्तृत व्याख्या',
    startQuickQuiz: 'दैनिक 10 प्रश्न क्विज',
    customTest: 'कस्टम टेस्ट बनाएं',
    continuePractice: 'अभ्यास जारी रखें',

    // Stats
    statQuestions: 'कुल उपलब्ध प्रश्न',
    statAttempted: 'अभ्यास किए प्रश्न',
    statAccuracy: 'सटीकता (Accuracy)',
    statStreak: 'अध्ययन स्ट्रीक (दिन)',

    // Subject Section
    subjectHeading: 'विषयवार अभ्यास (Subject-wise Practice)',
    subjectSubtitle: '11 प्रमुख विषयों के उच्चस्तरीय प्रश्न',
    practiceNow: 'अभ्यास करें',
    testNow: 'टेस्ट दें',
    questionsCount: 'प्रश्न',

    // Test Config Modal
    configureTest: 'टेस्ट सेटिंग्स कॉन्फ़िगर करें',
    chooseQuestions: 'प्रश्नों की संख्या चुनें',
    testMode: 'मोड चुनें',
    modeExam: 'परीक्षा मोड (समयबद्ध, परिणाम अंत में)',
    modePractice: 'अभ्यास मोड (तुरंत सही उत्तर व व्याख्या)',
    negativeMarking: 'नकारात्मक अंकन (Negative Marking)',
    negNone: 'कोई कटौती नहीं (0.00)',
    negOneFourth: '1/4 अंक (-0.25)',
    negOneThird: '1/3 अंक (-0.33)',
    timeLimit: 'समय सीमा (मिनट)',
    timeAuto: 'स्वतः (1.2 मिनट प्रति प्रश्न)',
    timeUntimed: 'असीमित समय (Untimed)',
    shuffleOptions: 'विकल्पों को शफल करें',
    shuffleQuestions: 'प्रश्नों का क्रम बदलें',
    pyqOnly: 'केवल BPSC पिछले वर्षों के प्रश्न (PYQ)',
    startTestBtn: 'टेस्ट शुरू करें',
    cancel: 'रद्द करें',

    // Test Runner
    question: 'प्रश्न',
    of: 'का',
    timerRemaining: 'शेष समय',
    submitTest: 'टेस्ट सबमिट करें',
    clearAnswer: 'उत्तर हटाएं',
    markForReview: 'समीक्षा हेतु चिह्नित करें',
    markedForReview: 'समीक्षा हेतु चिह्नित',
    previous: 'पिछला प्रश्न',
    next: 'अगला प्रश्न',
    questionPalette: 'प्रश्न तालिका (Palette)',
    answered: 'उत्तर दिया',
    unanswered: 'उत्तर नहीं दिया',
    notVisited: 'अभी नहीं देखा',
    instantAnswerLabel: 'त्वरित उत्तर जांचें',
    explanationTitle: 'विस्तृत व्याख्या व संदर्भ:',
    confirmSubmitTitle: 'क्या आप टेस्ट सबमिट करना चाहते हैं?',
    confirmSubmitDesc: 'सबमिट करने के बाद आप उत्तरों में बदलाव नहीं कर पाएंगे।',
    answeredCount: 'उत्तर दिए गए प्रश्न:',
    unansweredCount: 'बिना उत्तर वाले प्रश्न:',
    markedCount: 'समीक्षा हेतु शेष:',

    // Results
    resultsTitle: 'टेस्ट परिणाम एवं प्रदर्शन विश्लेषण',
    score: 'प्राप्तांक',
    accuracy: 'सटीकता',
    timeSpent: 'कुल समय',
    correct: 'सही',
    incorrect: 'गलत',
    unattempted: 'छोड़े गए',
    subjectWisePerformance: 'विषयवार प्रदर्शन (Subject Breakdown)',
    retryMistakes: 'गलत प्रश्नों का पुनः अभ्यास करें',
    retakeTest: 'यह टेस्ट पुनः दें',
    backToHome: 'होम पर लौटें',
    reviewQuestions: 'सभी प्रश्नों की विस्तृत समीक्षा',
    filterAll: 'सभी',
    filterCorrect: 'सही प्रश्न',
    filterIncorrect: 'गलत प्रश्न',
    filterUnanswered: 'छूटे प्रश्न',
    filterBookmarked: 'बुकमार्क',
    yourAnswer: 'आपका उत्तर:',
    correctOption: 'सही उत्तर:',
    sourceVerified: 'सत्यापित स्रोत:',

    // Mistake revision
    mistakeNotebookTitle: 'गलती सुधार डायरी (Mistake Notebook)',
    mistakeNotebookSubtitle: 'आपके द्वारा पूर्व टेस्ट में गलत किए गए प्रश्नों का संग्रह ताकि दोबारा गलती न हो।',
    noMistakes: 'शाबाश! वर्तमान में आपके गलत प्रश्नों की सूची रिक्त है।',
    practiceAllMistakes: 'सभी गलत प्रश्नों का टेस्ट लें',

    // Bookmarks
    bookmarksTitle: 'बुकमार्क किए गए प्रश्न',
    noBookmarks: 'आपने अभी तक कोई प्रश्न बुकमार्क नहीं किया है। प्रश्न हल करते समय ⭐ आइकन पर क्लिक करके महत्वपूर्ण प्रश्न सहेजें।',
    practiceBookmarks: 'बुकमार्क प्रश्नों का अभ्यास करें',
    personalNote: 'निजी अध्ययन नोट:',
    addNote: 'नोट जोड़ें...',
    saveNote: 'नोट सहेजें',

    // Admin
    adminTitle: 'प्रश्न बैंक प्रबंधन (Question Bank)',
    addNewQuestion: 'नया 5-विकल्प प्रश्न जोड़ें',
    bulkImport: 'CSV / JSON से थोक आयात',
    exportBank: 'प्रश्न बैंक डाउनलोड (JSON)',
    resetToDefault: 'डिफ़ॉल्ट प्रश्न रीसेट करें',
    aiGeneratedLabel: 'AI जनरेटेड (समीक्षा अपेक्षित)',
    verifiedBadge: 'BPSC सत्यापित',
    searchPlaceholder: 'प्रश्न या विषय खोजें...',

    // Language switcher
    switchLang: 'English में देखें',
    fontSize: 'फ़ॉन्ट आकार',
  },
  en: {
    // App Branding
    appName: 'BPSC TRE Exam Practice',
    appTagline: 'Premier preparation platform for Bihar Public Service Commission & State Exams',
    prelimsTarget: 'Target: 71st BPSC Combined Competitive Prelims',

    // Nav
    navHome: 'Home',
    navPractice: 'Practice Sets',
    navMockTests: 'Mock Tests',
    navPYQ: 'Previous Year Papers',
    navMistakes: 'Revision Notebook',
    navBookmarks: 'Bookmarks',
    navAdmin: 'Question Bank (Admin)',
    navProfile: 'My Progress',

    // Home / Hero
    heroTitle: 'Master the BPSC Prelims Examination',
    heroSubtitle: 'Authentic 5-option MCQs, configurable negative marking, and detailed bilingual solutions',
    startQuickQuiz: 'Daily 10-MCQ Challenge',
    customTest: 'Build Custom Test',
    continuePractice: 'Continue Practice',

    // Stats
    statQuestions: 'Total Questions',
    statAttempted: 'Attempted',
    statAccuracy: 'Accuracy',
    statStreak: 'Study Streak (Days)',

    // Subject Section
    subjectHeading: 'Subject-wise MCQ Practice',
    subjectSubtitle: 'In-depth practice across all 11 core BPSC syllabus domains',
    practiceNow: 'Practice',
    testNow: 'Take Test',
    questionsCount: 'Questions',

    // Test Config Modal
    configureTest: 'Configure Test Settings',
    chooseQuestions: 'Number of Questions',
    testMode: 'Select Test Mode',
    modeExam: 'Exam Mode (Timed, answers revealed at end)',
    modePractice: 'Practice Mode (Instant answer & explanation)',
    negativeMarking: 'Negative Marking Rule',
    negNone: 'No Negative Marking (0.00)',
    negOneFourth: '1/4 Negative (-0.25 marks)',
    negOneThird: '1/3 Negative (-0.33 marks)',
    timeLimit: 'Time Limit (Minutes)',
    timeAuto: 'Auto (1.2 min per question)',
    timeUntimed: 'Untimed',
    shuffleOptions: 'Shuffle Options',
    shuffleQuestions: 'Shuffle Questions Order',
    pyqOnly: 'BPSC Previous Year Questions Only (PYQs)',
    startTestBtn: 'Start Test Now',
    cancel: 'Cancel',

    // Test Runner
    question: 'Question',
    of: 'of',
    timerRemaining: 'Time Left',
    submitTest: 'Submit Test',
    clearAnswer: 'Clear Answer',
    markForReview: 'Mark for Review',
    markedForReview: 'Marked for Review',
    previous: 'Previous Question',
    next: 'Next Question',
    questionPalette: 'Question Palette',
    answered: 'Answered',
    unanswered: 'Unanswered',
    notVisited: 'Not Visited',
    instantAnswerLabel: 'Check Instant Answer',
    explanationTitle: 'Detailed Solution & Context:',
    confirmSubmitTitle: 'Are you sure you want to submit the test?',
    confirmSubmitDesc: 'Once submitted, your answers will be locked and detailed evaluation will be generated.',
    answeredCount: 'Answered Questions:',
    unansweredCount: 'Unanswered Questions:',
    markedCount: 'Marked for Review:',

    // Results
    resultsTitle: 'Test Results & Performance Analytics',
    score: 'Final Score',
    accuracy: 'Accuracy',
    timeSpent: 'Time Taken',
    correct: 'Correct',
    incorrect: 'Incorrect',
    unattempted: 'Unanswered',
    subjectWisePerformance: 'Subject-wise Performance Breakdown',
    retryMistakes: 'Retry Incorrect Questions',
    retakeTest: 'Retake Full Test',
    backToHome: 'Back to Dashboard',
    reviewQuestions: 'Comprehensive Question Review',
    filterAll: 'All Questions',
    filterCorrect: 'Correct Only',
    filterIncorrect: 'Incorrect Only',
    filterUnanswered: 'Unanswered Only',
    filterBookmarked: 'Bookmarked',
    yourAnswer: 'Your Choice:',
    correctOption: 'Correct Option:',
    sourceVerified: 'Verified Source:',

    // Mistake revision
    mistakeNotebookTitle: 'Mistake Revision Notebook',
    mistakeNotebookSubtitle: 'Questions you previously got wrong, curated for revision so you never repeat a mistake.',
    noMistakes: 'Great work! No mistakes recorded in your notebook yet.',
    practiceAllMistakes: 'Test My Mistakes',

    // Bookmarks
    bookmarksTitle: 'Bookmarked Questions',
    noBookmarks: 'You haven\'t bookmarked any questions yet. Tap the ⭐ icon during practice to save challenging questions.',
    practiceBookmarks: 'Practice Bookmarked',
    personalNote: 'Personal Note:',
    addNote: 'Add notes for rapid revision...',
    saveNote: 'Save Note',

    // Admin
    adminTitle: 'Question Bank Management',
    addNewQuestion: 'Add 5-Option Question',
    bulkImport: 'Bulk Import (CSV / JSON)',
    exportBank: 'Export Question Bank (JSON)',
    resetToDefault: 'Reset to Default Questions',
    aiGeneratedLabel: 'AI Generated (Needs Review)',
    verifiedBadge: 'BPSC Verified',
    searchPlaceholder: 'Search by topic, keyword or subject...',

    // Language switcher
    switchLang: 'हिन्दी में बदलें',
    fontSize: 'Font Size',
  },
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>(() => {
    const saved = localStorage.getItem('bpsc_lang');
    return (saved === 'en' || saved === 'hi') ? saved : 'hi';
  });

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem('bpsc_lang', lang);
  };

  const toggleLanguage = () => {
    const next = language === 'hi' ? 'en' : 'hi';
    setLanguage(next);
  };

  const t = (key: string): string => {
    return translations[language][key] || translations['hi'][key] || key;
  };

  useEffect(() => {
    document.documentElement.lang = language;
  }, [language]);

  return (
    <LanguageContext.Provider value={{ language, setLanguage, toggleLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
