import React, { createContext, useContext, useState, useEffect, useRef, ReactNode } from 'react';
import { Question, OptionKey, TestSettings, UserAnswerRecord, TestResult, TestMode } from '../types';
import { useUser } from './UserContext';
import confetti from 'canvas-confetti';

interface ActiveQuestionWrapper {
  original: Question;
  displayOptionsHindi: [string, string, string, string, string];
  displayOptionsEnglish: [string, string, string, string, string];
  correctDisplayAnswer: OptionKey;
}

interface TestContextType {
  activeTest: boolean;
  testTitle: string;
  settings: TestSettings | null;
  questions: ActiveQuestionWrapper[];
  currentIndex: number;
  currentQuestion: ActiveQuestionWrapper | null;
  answers: Record<string, UserAnswerRecord>;
  timeRemainingSeconds: number;
  totalTimeAllocatedSeconds: number;
  isTimerRunning: boolean;
  fontSize: 'normal' | 'large' | 'xlarge';
  setFontSize: (size: 'normal' | 'large' | 'xlarge') => void;
  lastTestResult: TestResult | null;
  setLastTestResult: (result: TestResult | null) => void;
  startTest: (settings: TestSettings, questionPool: Question[], title?: string) => void;
  selectOption: (opt: OptionKey) => void;
  clearAnswer: () => void;
  toggleMarkForReview: () => void;
  goToQuestion: (index: number) => void;
  nextQuestion: () => void;
  prevQuestion: () => void;
  submitTest: () => TestResult;
  abortTest: () => void;
  showSubmitModal: boolean;
  setShowSubmitModal: (show: boolean) => void;
  showPaletteDrawer: boolean;
  setShowPaletteDrawer: (show: boolean) => void;
}

const TestContext = createContext<TestContextType | undefined>(undefined);

export const TestProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const { saveTestResult } = useUser();

  const [activeTest, setActiveTest] = useState<boolean>(false);
  const [testTitle, setTestTitle] = useState<string>('BPSC Practice Test');
  const [settings, setSettings] = useState<TestSettings | null>(null);
  const [questions, setQuestions] = useState<ActiveQuestionWrapper[]>([]);
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [answers, setAnswers] = useState<Record<string, UserAnswerRecord>>({});
  const [timeRemainingSeconds, setTimeRemainingSeconds] = useState<number>(0);
  const [totalTimeAllocatedSeconds, setTotalTimeAllocatedSeconds] = useState<number>(0);
  const [isTimerRunning, setIsTimerRunning] = useState<boolean>(false);
  const [fontSize, setFontSize] = useState<'normal' | 'large' | 'xlarge'>('normal');
  const [lastTestResult, setLastTestResult] = useState<TestResult | null>(null);
  const [showSubmitModal, setShowSubmitModal] = useState<boolean>(false);
  const [showPaletteDrawer, setShowPaletteDrawer] = useState<boolean>(false);

  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const currentQuestionIdRef = useRef<string | null>(null);

  // Timer loop
  useEffect(() => {
    if (activeTest && isTimerRunning) {
      timerRef.current = setInterval(() => {
        setTimeRemainingSeconds((prev) => {
          if (settings?.timeLimitMinutes && settings.timeLimitMinutes > 0) {
            if (prev <= 1) {
              clearInterval(timerRef.current!);
              // Auto submit when time expires
              handleAutoSubmit();
              return 0;
            }
            return prev - 1;
          } else {
            // Count up for untimed
            return prev + 1;
          }
        });

        // Track per-question time
        if (currentQuestionIdRef.current) {
          const qId = currentQuestionIdRef.current;
          setAnswers((prev) => {
            const current = prev[qId];
            if (!current) return prev;
            return {
              ...prev,
              [qId]: {
                ...current,
                timeSpentSeconds: (current.timeSpentSeconds || 0) + 1,
              },
            };
          });
        }
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [activeTest, isTimerRunning, settings]);

  const currentQuestion = questions[currentIndex] || null;

  useEffect(() => {
    if (currentQuestion) {
      currentQuestionIdRef.current = currentQuestion.original.id;
    }
  }, [currentIndex, currentQuestion]);

  const startTest = (newSettings: TestSettings, questionPool: Question[], title = 'BPSC Practice Test') => {
    if (questionPool.length === 0) return;

    let selectedQuestions = [...questionPool];

    // Filter by PYQ if requested
    if (newSettings.pyqOnly) {
      selectedQuestions = selectedQuestions.filter((q) => q.isPYQ);
    }

    // Filter by subjects if specified
    if (newSettings.subjects && newSettings.subjects.length > 0) {
      selectedQuestions = selectedQuestions.filter((q) =>
        newSettings.subjects.includes(q.subjectId)
      );
    }

    // Shuffle questions if required
    if (newSettings.shuffleQuestions) {
      selectedQuestions = [...selectedQuestions].sort(() => Math.random() - 0.5);
    }

    // Slice to question count
    const count = Math.min(newSettings.questionCount, selectedQuestions.length);
    selectedQuestions = selectedQuestions.slice(0, count);

    // Prepare active question wrappers
    const optionLetters: OptionKey[] = ['A', 'B', 'C', 'D', 'E'];
    const preparedQuestions: ActiveQuestionWrapper[] = selectedQuestions.map((q) => {
      if (!newSettings.shuffleOptions) {
        return {
          original: q,
          displayOptionsHindi: [...q.optionsHindi],
          displayOptionsEnglish: [...q.optionsEnglish],
          correctDisplayAnswer: q.correctAnswer,
        };
      }

      // Shuffling 5 options while preserving correct answer mapping
      const correctIdx = optionLetters.indexOf(q.correctAnswer);
      const indices = [0, 1, 2, 3, 4];
      // Keep option E as 'None of above' if it explicitly says so, or shuffle all 5
      const isOptionESpecial =
        q.optionsHindi[4]?.includes('कोई नहीं') || q.optionsHindi[4]?.includes('None');

      let shuffledIndices: number[];
      if (isOptionESpecial) {
        // Shuffle first 4 options, keep 5th
        const firstFour = [0, 1, 2, 3].sort(() => Math.random() - 0.5);
        shuffledIndices = [...firstFour, 4];
      } else {
        shuffledIndices = indices.sort(() => Math.random() - 0.5);
      }

      const newCorrectIdx = shuffledIndices.indexOf(correctIdx);
      const newCorrectLetter = optionLetters[newCorrectIdx] || 'A';

      const dispHindi = shuffledIndices.map((i) => q.optionsHindi[i]) as [
        string,
        string,
        string,
        string,
        string
      ];
      const dispEnglish = shuffledIndices.map((i) => q.optionsEnglish[i]) as [
        string,
        string,
        string,
        string,
        string
      ];

      return {
        original: q,
        displayOptionsHindi: dispHindi,
        displayOptionsEnglish: dispEnglish,
        correctDisplayAnswer: newCorrectLetter,
      };
    });

    // Initial answers map
    const initialAnswers: Record<string, UserAnswerRecord> = {};
    preparedQuestions.forEach((wrapper) => {
      initialAnswers[wrapper.original.id] = {
        questionId: wrapper.original.id,
        selectedOption: null,
        isMarkedForReview: false,
        timeSpentSeconds: 0,
      };
    });

    const allocatedSec =
      newSettings.timeLimitMinutes > 0
        ? newSettings.timeLimitMinutes * 60
        : Math.round(preparedQuestions.length * 72); // 1.2 min per question default

    setSettings(newSettings);
    setTestTitle(title);
    setQuestions(preparedQuestions);
    setAnswers(initialAnswers);
    setCurrentIndex(0);
    setTotalTimeAllocatedSeconds(allocatedSec);
    setTimeRemainingSeconds(newSettings.timeLimitMinutes > 0 ? allocatedSec : 0);
    setIsTimerRunning(true);
    setActiveTest(true);
    setShowSubmitModal(false);
    setShowPaletteDrawer(false);
  };

  const selectOption = (opt: OptionKey) => {
    if (!currentQuestion) return;
    const qId = currentQuestion.original.id;
    const isCorrect = opt === currentQuestion.correctDisplayAnswer;

    setAnswers((prev) => ({
      ...prev,
      [qId]: {
        ...prev[qId],
        selectedOption: opt,
        isCorrect,
      },
    }));
  };

  const clearAnswer = () => {
    if (!currentQuestion) return;
    const qId = currentQuestion.original.id;
    setAnswers((prev) => ({
      ...prev,
      [qId]: {
        ...prev[qId],
        selectedOption: null,
        isCorrect: undefined,
      },
    }));
  };

  const toggleMarkForReview = () => {
    if (!currentQuestion) return;
    const qId = currentQuestion.original.id;
    setAnswers((prev) => ({
      ...prev,
      [qId]: {
        ...prev[qId],
        isMarkedForReview: !prev[qId]?.isMarkedForReview,
      },
    }));
  };

  const goToQuestion = (index: number) => {
    if (index >= 0 && index < questions.length) {
      setCurrentIndex(index);
    }
  };

  const nextQuestion = () => {
    if (currentIndex < questions.length - 1) {
      setCurrentIndex((prev) => prev + 1);
    }
  };

  const prevQuestion = () => {
    if (currentIndex > 0) {
      setCurrentIndex((prev) => prev - 1);
    }
  };

  const calculateResult = (): TestResult => {
    const totalQ = questions.length;
    let attempted = 0;
    let correct = 0;
    let incorrect = 0;
    let unattempted = 0;

    const subjectBreakdown: TestResult['subjectBreakdown'] = {};

    questions.forEach((wrapper) => {
      const q = wrapper.original;
      const ans = answers[q.id];
      const isAttempted = ans && ans.selectedOption !== null;
      const isRight = ans && ans.selectedOption === wrapper.correctDisplayAnswer;

      if (!subjectBreakdown[q.subjectId]) {
        subjectBreakdown[q.subjectId] = { total: 0, correct: 0, incorrect: 0, unanswered: 0 };
      }
      subjectBreakdown[q.subjectId].total += 1;

      if (!isAttempted) {
        unattempted += 1;
        subjectBreakdown[q.subjectId].unanswered += 1;
      } else if (isRight) {
        attempted += 1;
        correct += 1;
        subjectBreakdown[q.subjectId].correct += 1;
      } else {
        attempted += 1;
        incorrect += 1;
        subjectBreakdown[q.subjectId].incorrect += 1;
      }
    });

    const negPenalty = settings?.negativeMarking || 0; // 0, 0.25, 0.33
    // 1 mark per correct answer, minus penalty per incorrect
    const rawScore = correct * 1 - incorrect * negPenalty;
    const score = Math.max(0, +rawScore.toFixed(2));
    const maxScore = totalQ;
    const percentage = totalQ > 0 ? Math.max(0, +((score / maxScore) * 100).toFixed(1)) : 0;

    const timeSpent =
      settings?.timeLimitMinutes && settings.timeLimitMinutes > 0
        ? totalTimeAllocatedSeconds - timeRemainingSeconds
        : timeRemainingSeconds;

    const result: TestResult = {
      id: 'res-' + Date.now(),
      testTitle,
      mode: settings?.mode || 'exam',
      totalQuestions: totalQ,
      attempted,
      correct,
      incorrect,
      unanswered: unattempted,
      score,
      maxScore,
      negativeMarking: negPenalty,
      percentage,
      timeTakenSeconds: Math.max(1, timeSpent),
      completedAt: new Date().toISOString(),
      subjectBreakdown,
      answers,
      questions: questions.map((q) => q.original),
    };

    return result;
  };

  const submitTest = (): TestResult => {
    setIsTimerRunning(false);
    const result = calculateResult();
    saveTestResult(result);
    setLastTestResult(result);
    setActiveTest(false);
    setShowSubmitModal(false);

    // Launch celebratory confetti if score is solid (>= 60%)
    if (result.percentage >= 60) {
      try {
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.6 },
        });
      } catch {
        // ignore
      }
    }

    return result;
  };

  const handleAutoSubmit = () => {
    submitTest();
  };

  const abortTest = () => {
    setIsTimerRunning(false);
    setActiveTest(false);
    setShowSubmitModal(false);
  };

  return (
    <TestContext.Provider
      value={{
        activeTest,
        testTitle,
        settings,
        questions,
        currentIndex,
        currentQuestion,
        answers,
        timeRemainingSeconds,
        totalTimeAllocatedSeconds,
        isTimerRunning,
        fontSize,
        setFontSize,
        lastTestResult,
        setLastTestResult,
        startTest,
        selectOption,
        clearAnswer,
        toggleMarkForReview,
        goToQuestion,
        nextQuestion,
        prevQuestion,
        submitTest,
        abortTest,
        showSubmitModal,
        setShowSubmitModal,
        showPaletteDrawer,
        setShowPaletteDrawer,
      }}
    >
      {children}
    </TestContext.Provider>
  );
};

export const useTest = (): TestContextType => {
  const context = useContext(TestContext);
  if (!context) {
    throw new Error('useTest must be used within a TestProvider');
  }
  return context;
};
