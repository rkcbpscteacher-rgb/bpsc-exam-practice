import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { StudentProfile, TestResult, AppUser, UserRole } from '../types';

interface OverallStats {
  totalTests: number;
  totalAttempted: number;
  totalCorrect: number;
  accuracy: number;
  averageScore: number;
}

export interface DayStreakItem {
  date: string;
  dayName: string;
  dayNumber: number;
  isCompleted: boolean;
  isToday: boolean;
}

interface UserContextType {
  profile: StudentProfile;
  currentUser: AppUser | null;
  userRole: UserRole;
  isLoggedIn: boolean;
  token: string | null;
  testHistory: TestResult[];
  overallStats: OverallStats;
  userEmail: string;
  hasCompletedQuizToday: boolean;
  streakStatus: 'completed_today' | 'pending_today' | 'inactive';
  recentDaysActivity: DayStreakItem[];
  streakJustUpdated: { increased: boolean; newCount: number } | null;
  isAuthModalOpen: boolean;
  authModalMode: 'login' | 'register' | 'forgot' | 'reset';
  setIsAuthModalOpen: (open: boolean) => void;
  setAuthModalMode: (mode: 'login' | 'register' | 'forgot' | 'reset') => void;
  openLoginModal: () => void;
  openRegisterModal: () => void;
  dismissStreakNotice: () => void;
  updateProfileName: (name: string) => void;
  updateTargetExam: (target: string) => void;
  toggleBookmark: (questionId: string) => void;
  isBookmarked: (questionId: string) => boolean;
  saveQuestionNote: (questionId: string, note: string) => void;
  getQuestionNote: (questionId: string) => string;
  addMistakes: (questionIds: string[]) => void;
  removeMistake: (questionId: string) => void;
  clearMistakes: () => void;
  saveTestResult: (result: TestResult) => void;
  deleteTestResult: (testId: string) => void;
  exportUserData: () => string;
  importUserData: (jsonData: string) => boolean;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string; user?: AppUser }>;
  register: (name: string, email: string, password: string, targetExam?: string) => Promise<{ success: boolean; error?: string; user?: AppUser }>;
  logout: () => Promise<void>;
  loginDemo: (role?: 'student' | 'admin') => Promise<void>;
  forgotPassword: (email: string) => Promise<{ success: boolean; resetToken?: string; message: string }>;
  resetPassword: (resetToken: string, newPassword: string) => Promise<{ success: boolean; message: string }>;
}

const PROFILE_STORAGE_KEY = 'bpsc_student_profile_v2';
const HISTORY_STORAGE_KEY = 'bpsc_test_history_v2';
const TOKEN_STORAGE_KEY = 'bpsc_auth_token_v1';
const USER_STORAGE_KEY = 'bpsc_current_user_v1';

export const getTodayString = (): string => {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

export const getYesterdayString = (): string => {
  const yesterday = new Date(Date.now() - 86400000);
  const year = yesterday.getFullYear();
  const month = String(yesterday.getMonth() + 1).padStart(2, '0');
  const day = String(yesterday.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

const defaultProfile: StudentProfile = {
  name: 'BPSC Aspirant',
  targetExam: '71st BPSC Combined Competitive Prelims',
  studyStreakDays: 0,
  longestStreakDays: 0,
  lastQuizCompletionDate: '',
  completedQuizDates: [],
  testsCompleted: 0,
  totalQuestionsPracticed: 0,
  bookmarks: [],
  notes: {},
  incorrectQuestionIds: [],
};

const UserContext = createContext<UserContextType | undefined>(undefined);

export const UserProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [token, setToken] = useState<string | null>(() => {
    return localStorage.getItem(TOKEN_STORAGE_KEY);
  });

  const [currentUser, setCurrentUser] = useState<AppUser | null>(() => {
    try {
      const saved = localStorage.getItem(USER_STORAGE_KEY);
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback
    }
    return null;
  });

  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [authModalMode, setAuthModalMode] = useState<'login' | 'register' | 'forgot' | 'reset'>('login');

  const [profile, setProfile] = useState<StudentProfile>(() => {
    try {
      const savedV2 = localStorage.getItem(PROFILE_STORAGE_KEY);
      if (savedV2) {
        return { ...defaultProfile, ...JSON.parse(savedV2) };
      }
    } catch {
      // fallback
    }
    return defaultProfile;
  });

  const [testHistory, setTestHistory] = useState<TestResult[]>(() => {
    try {
      const saved = localStorage.getItem(HISTORY_STORAGE_KEY);
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback
    }
    return [];
  });

  const [streakJustUpdated, setStreakJustUpdated] = useState<{
    increased: boolean;
    newCount: number;
  } | null>(null);

  // Determine user role and logged in status
  const isLoggedIn = Boolean(token && currentUser);
  const userRole: UserRole = currentUser?.role || 'student';
  const userEmail = currentUser?.email || 'bpsc.candidate@gmail.com';

  // Sync / verify session on app load
  useEffect(() => {
    if (!token) return;

    fetch('/api/auth/me', {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then((res) => {
        if (res.ok) {
          return res.json();
        }
        throw new Error('Session invalid');
      })
      .then((user: AppUser) => {
        setCurrentUser(user);
        localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(user));
      })
      .catch(() => {
        // Clear invalid token
        setToken(null);
        setCurrentUser(null);
        localStorage.removeItem(TOKEN_STORAGE_KEY);
        localStorage.removeItem(USER_STORAGE_KEY);
      });
  }, [token]);

  // Streak verification on load
  useEffect(() => {
    const today = getTodayString();
    const yesterday = getYesterdayString();
    const lastDate = profile.lastQuizCompletionDate;

    if (!lastDate) {
      if (profile.studyStreakDays !== 0) {
        saveProfile({ ...profile, studyStreakDays: 0 });
      }
      return;
    }

    if (lastDate !== today && lastDate !== yesterday) {
      if (profile.studyStreakDays !== 0) {
        saveProfile({ ...profile, studyStreakDays: 0 });
      }
    }
  }, []);

  const saveProfile = (updated: StudentProfile) => {
    setProfile(updated);
    try {
      localStorage.setItem(PROFILE_STORAGE_KEY, JSON.stringify(updated));
    } catch (e) {
      console.error(e);
    }
  };

  const updateProfileName = (name: string) => {
    saveProfile({ ...profile, name });
    if (currentUser) {
      const updatedUser = { ...currentUser, name };
      setCurrentUser(updatedUser);
      localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(updatedUser));
    }
  };

  const updateTargetExam = (targetExam: string) => {
    saveProfile({ ...profile, targetExam });
  };

  const toggleBookmark = (questionId: string) => {
    const exists = profile.bookmarks.includes(questionId);
    const updatedBookmarks = exists
      ? profile.bookmarks.filter((id) => id !== questionId)
      : [...profile.bookmarks, questionId];
    saveProfile({ ...profile, bookmarks: updatedBookmarks });
  };

  const isBookmarked = (questionId: string): boolean => {
    return profile.bookmarks.includes(questionId);
  };

  const saveQuestionNote = (questionId: string, note: string) => {
    const updatedNotes = { ...profile.notes, [questionId]: note };
    saveProfile({ ...profile, notes: updatedNotes });
  };

  const getQuestionNote = (questionId: string): string => {
    return profile.notes[questionId] || '';
  };

  const addMistakes = (questionIds: string[]) => {
    const currentSet = new Set(profile.incorrectQuestionIds);
    questionIds.forEach((id) => currentSet.add(id));
    saveProfile({ ...profile, incorrectQuestionIds: Array.from(currentSet) });
  };

  const removeMistake = (questionId: string) => {
    const updated = profile.incorrectQuestionIds.filter((id) => id !== questionId);
    saveProfile({ ...profile, incorrectQuestionIds: updated });
  };

  const clearMistakes = () => {
    saveProfile({ ...profile, incorrectQuestionIds: [] });
  };

  const saveTestResult = (result: TestResult) => {
    const updatedHistory = [result, ...testHistory];
    setTestHistory(updatedHistory);
    try {
      localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(updatedHistory));
    } catch (e) {
      console.error(e);
    }

    // Sync to backend if authenticated
    if (token) {
      fetch('/api/student/history', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(result),
      }).catch((err) => console.warn('Failed to sync result to server:', err));
    }

    // Mistake tracking
    const wrongIds = Object.values(result.answers)
      .filter((a) => a.isCorrect === false && a.selectedOption !== null)
      .map((a) => a.questionId);

    const correctIds = new Set(
      Object.values(result.answers)
        .filter((a) => a.isCorrect === true)
        .map((a) => a.questionId)
    );

    const currentMistakes = profile.incorrectQuestionIds.filter((id) => !correctIds.has(id));
    const mergedMistakes = Array.from(new Set([...currentMistakes, ...wrongIds]));

    // Daily Streak Logic
    const today = getTodayString();
    const yesterday = getYesterdayString();
    const lastCompleted = profile.lastQuizCompletionDate;
    let newStreak = profile.studyStreakDays;
    let streakIncreased = false;

    if (result.attempted > 0) {
      if (lastCompleted === today) {
        streakIncreased = false;
      } else if (lastCompleted === yesterday) {
        newStreak = (profile.studyStreakDays || 0) + 1;
        streakIncreased = true;
      } else {
        newStreak = 1;
        streakIncreased = true;
      }
    }

    const newLongest = Math.max(newStreak, profile.longestStreakDays || 0);
    const updatedCompletedDates = profile.completedQuizDates.includes(today)
      ? profile.completedQuizDates
      : [...profile.completedQuizDates, today];

    const updatedProfile: StudentProfile = {
      ...profile,
      testsCompleted: (profile.testsCompleted || 0) + 1,
      totalQuestionsPracticed: (profile.totalQuestionsPracticed || 0) + result.attempted,
      studyStreakDays: newStreak,
      longestStreakDays: newLongest,
      lastQuizCompletionDate: today,
      completedQuizDates: updatedCompletedDates,
      incorrectQuestionIds: mergedMistakes,
    };

    saveProfile(updatedProfile);

    setStreakJustUpdated({
      increased: streakIncreased,
      newCount: newStreak,
    });
  };

  const deleteTestResult = (testId: string) => {
    const updated = testHistory.filter((t) => t.id !== testId);
    setTestHistory(updated);
    localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(updated));
  };

  const dismissStreakNotice = () => {
    setStreakJustUpdated(null);
  };

  // --- Real Authentication Operations ---

  const login = async (
    email: string,
    password: string
  ): Promise<{ success: boolean; error?: string; user?: AppUser }> => {
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });

      const data = await res.json();
      if (!res.ok) {
        return { success: false, error: data.error || 'Login failed.' };
      }

      setToken(data.token);
      setCurrentUser(data.user);
      localStorage.setItem(TOKEN_STORAGE_KEY, data.token);
      localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(data.user));

      if (data.user.name) {
        setProfile((prev) => ({ ...prev, name: data.user.name }));
      }

      setIsAuthModalOpen(false);
      return { success: true, user: data.user };
    } catch (err: any) {
      return { success: false, error: err.message || 'Server connection error.' };
    }
  };

  const register = async (
    name: string,
    email: string,
    password: string,
    targetExam?: string
  ): Promise<{ success: boolean; error?: string; user?: AppUser }> => {
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, password, targetExam }),
      });

      const data = await res.json();
      if (!res.ok) {
        return { success: false, error: data.error || 'Registration failed.' };
      }

      setToken(data.token);
      setCurrentUser(data.user);
      localStorage.setItem(TOKEN_STORAGE_KEY, data.token);
      localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(data.user));

      setProfile((prev) => ({
        ...prev,
        name: data.user.name,
        targetExam: data.user.targetExam || prev.targetExam,
      }));

      setIsAuthModalOpen(false);
      return { success: true, user: data.user };
    } catch (err: any) {
      return { success: false, error: err.message || 'Server connection error.' };
    }
  };

  const logout = async () => {
    try {
      if (token) {
        await fetch('/api/auth/logout', {
          method: 'POST',
          headers: { Authorization: `Bearer ${token}` },
        });
      }
    } catch {
      // ignore
    } finally {
      setToken(null);
      setCurrentUser(null);
      localStorage.removeItem(TOKEN_STORAGE_KEY);
      localStorage.removeItem(USER_STORAGE_KEY);
    }
  };

  // Demo 1-Click Quick Login (Supports both Student & Admin)
  const loginDemo = async (role: 'student' | 'admin' = 'student') => {
    if (role === 'admin') {
      await login('admin@bpsc.exam', 'Admin@BPSC2025');
    } else {
      await login('student@bpsc.exam', 'Student@123');
    }
  };

  const forgotPassword = async (
    email: string
  ): Promise<{ success: boolean; resetToken?: string; message: string }> => {
    try {
      const res = await fetch('/api/auth/forgot-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      });
      const data = await res.json();
      return data;
    } catch (err: any) {
      return { success: false, message: 'Server connection error.' };
    }
  };

  const resetPassword = async (
    resetToken: string,
    newPassword: string
  ): Promise<{ success: boolean; message: string }> => {
    try {
      const res = await fetch('/api/auth/reset-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ resetToken, newPassword }),
      });
      const data = await res.json();
      if (res.ok) {
        return { success: true, message: data.message };
      }
      return { success: false, message: data.error || 'Password reset failed.' };
    } catch (err: any) {
      return { success: false, message: 'Server connection error.' };
    }
  };

  const openLoginModal = () => {
    setAuthModalMode('login');
    setIsAuthModalOpen(true);
  };

  const openRegisterModal = () => {
    setAuthModalMode('register');
    setIsAuthModalOpen(true);
  };

  const exportUserData = (): string => {
    const data = {
      version: '2.0',
      exportedAt: new Date().toISOString(),
      user: currentUser,
      profile,
      testHistory,
    };
    return JSON.stringify(data, null, 2);
  };

  const importUserData = (jsonData: string): boolean => {
    try {
      const parsed = JSON.parse(jsonData);
      if (parsed.profile) {
        saveProfile(parsed.profile);
      }
      if (Array.isArray(parsed.testHistory)) {
        setTestHistory(parsed.testHistory);
        localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(parsed.testHistory));
      }
      return true;
    } catch {
      return false;
    }
  };

  // Streak status calculation
  const today = getTodayString();
  const yesterday = getYesterdayString();
  const hasCompletedQuizToday = profile.lastQuizCompletionDate === today;

  let streakStatus: 'completed_today' | 'pending_today' | 'inactive' = 'inactive';
  if (hasCompletedQuizToday) {
    streakStatus = 'completed_today';
  } else if (profile.lastQuizCompletionDate === yesterday) {
    streakStatus = 'pending_today';
  } else {
    streakStatus = 'inactive';
  }

  const recentDaysActivity: DayStreakItem[] = React.useMemo(() => {
    const days: DayStreakItem[] = [];
    const dayNames = ['रवि', 'सोम', 'मंगल', 'बुध', 'गुरु', 'शुक्र', 'शनि'];
    const now = new Date();

    for (let i = 6; i >= 0; i--) {
      const d = new Date(now.getTime() - i * 86400000);
      const y = d.getFullYear();
      const m = String(d.getMonth() + 1).padStart(2, '0');
      const dateStr = `${y}-${m}-${String(d.getDate()).padStart(2, '0')}`;

      days.push({
        date: dateStr,
        dayName: dayNames[d.getDay()],
        dayNumber: d.getDate(),
        isCompleted: profile.completedQuizDates.includes(dateStr),
        isToday: dateStr === today,
      });
    }
    return days;
  }, [profile.completedQuizDates, today]);

  const overallStats: OverallStats = React.useMemo(() => {
    const totalTests = testHistory.length;
    let totalAttempted = 0;
    let totalCorrect = 0;
    let totalScore = 0;

    testHistory.forEach((t) => {
      totalAttempted += t.attempted;
      totalCorrect += t.correct;
      totalScore += t.score;
    });

    const accuracy = totalAttempted > 0 ? Math.round((totalCorrect / totalAttempted) * 100) : 0;
    const averageScore = totalTests > 0 ? +(totalScore / totalTests).toFixed(1) : 0;

    return {
      totalTests,
      totalAttempted,
      totalCorrect,
      accuracy,
      averageScore,
    };
  }, [testHistory]);

  return (
    <UserContext.Provider
      value={{
        profile,
        currentUser,
        userRole,
        isLoggedIn,
        token,
        testHistory,
        overallStats,
        userEmail,
        hasCompletedQuizToday,
        streakStatus,
        recentDaysActivity,
        streakJustUpdated,
        isAuthModalOpen,
        authModalMode,
        setIsAuthModalOpen,
        setAuthModalMode,
        openLoginModal,
        openRegisterModal,
        dismissStreakNotice,
        updateProfileName,
        updateTargetExam,
        toggleBookmark,
        isBookmarked,
        saveQuestionNote,
        getQuestionNote,
        addMistakes,
        removeMistake,
        clearMistakes,
        saveTestResult,
        deleteTestResult,
        exportUserData,
        importUserData,
        login,
        register,
        logout,
        loginDemo,
        forgotPassword,
        resetPassword,
      }}
    >
      {children}
    </UserContext.Provider>
  );
};

export const useUser = (): UserContextType => {
  const context = useContext(UserContext);
  if (!context) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
};
