import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import bcrypt from 'bcryptjs';
import crypto from 'crypto';
import { GoogleGenAI } from '@google/genai';
import { INITIAL_TRE_PAPERS } from './src/data/treInitialPapers.ts';
import { INITIAL_QUESTIONS } from './src/data/initialQuestions.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '15mb' }));

// Ensure data folder exists
const dataDir = path.join(__dirname, 'data');
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

const questionsFilePath = path.join(dataDir, 'questions.json');
const usersFilePath = path.join(dataDir, 'users.json');
const sessionsFilePath = path.join(dataDir, 'sessions.json');
const mockTestsFilePath = path.join(dataDir, 'mock_tests.json');
const testResultsFilePath = path.join(dataDir, 'test_results.json');
const passwordResetsFilePath = path.join(dataDir, 'password_resets.json');
const trePapersFilePath = path.join(dataDir, 'tre_papers.json');

// --- Helper Functions for File Storage ---

const readJsonFile = <T>(filePath: string, defaultValue: T): T => {
  try {
    if (fs.existsSync(filePath)) {
      const data = fs.readFileSync(filePath, 'utf8');
      return JSON.parse(data);
    }
  } catch (err) {
    console.error(`Error reading ${filePath}:`, err);
  }
  return defaultValue;
};

const writeJsonFile = (filePath: string, data: any) => {
  try {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf8');
  } catch (err) {
    console.error(`Error writing ${filePath}:`, err);
  }
};

// Seed initial default Admin and Student accounts if users.json is empty
const seedInitialUsers = () => {
  const users = readJsonFile<any[]>(usersFilePath, []);
  let changed = false;

  // 1. Predefined Admin account (Server-Authoritative Role)
  const adminEmail = 'admin@bpsc.exam';
  if (!users.some((u) => u.email.toLowerCase() === adminEmail.toLowerCase())) {
    const salt = bcrypt.genSaltSync(10);
    const passwordHash = bcrypt.hashSync('Admin@BPSC2025', salt);
    users.push({
      id: 'user-admin-root',
      name: 'BPSC Exam Controller (Admin)',
      email: adminEmail,
      passwordHash,
      role: 'admin',
      targetExam: 'BPSC 71st CCE Administrator',
      createdAt: new Date().toISOString(),
    });
    changed = true;
  }

  // Also grant admin to the applet owner's email if specified
  const teacherEmail = 'rkcbpscteacher@gmail.com';
  if (!users.some((u) => u.email.toLowerCase() === teacherEmail.toLowerCase())) {
    const salt = bcrypt.genSaltSync(10);
    const passwordHash = bcrypt.hashSync('Teacher@BPSC2025', salt);
    users.push({
      id: 'user-admin-teacher',
      name: 'RKC Teacher (Admin)',
      email: teacherEmail,
      passwordHash,
      role: 'admin',
      targetExam: 'BPSC 71st CCE Administrator',
      createdAt: new Date().toISOString(),
    });
    changed = true;
  }

  // 2. Predefined Student demo account
  const studentEmail = 'student@bpsc.exam';
  if (!users.some((u) => u.email.toLowerCase() === studentEmail.toLowerCase())) {
    const salt = bcrypt.genSaltSync(10);
    const passwordHash = bcrypt.hashSync('Student@123', salt);
    users.push({
      id: 'user-student-demo',
      name: 'कुमार राहुल (BPSC Aspirant)',
      email: studentEmail,
      passwordHash,
      role: 'student',
      targetExam: '71st BPSC Combined Competitive Prelims',
      createdAt: new Date().toISOString(),
    });
    changed = true;
  }

  if (changed) {
    writeJsonFile(usersFilePath, users);
    console.log('Seeded initial secure Admin and Student accounts.');
  }
};

seedInitialUsers();

// Seed initial Default Mock Tests if not existing
const seedInitialMockTests = () => {
  const mockTests = readJsonFile<any[]>(mockTestsFilePath, []);
  if (mockTests.length === 0) {
    const defaults = [
      {
        id: 'mock-10-quick',
        title: 'BPSC Prelims 10-Question Rapid Drill',
        titleHindi: 'बीपीएससी 10-प्रश्नोत्तरी रैपिड ड्रिल',
        description: 'BPSC 5-option quick practice set across mixed general studies subjects.',
        subjectIds: ['bihar-gk', 'history', 'polity', 'general-science'],
        questionCount: 10,
        timeLimitMinutes: 12,
        negativeMarking: 0.25,
        totalMarks: 10,
        isFullLength: false,
        createdBy: 'admin@bpsc.exam',
        createdAt: new Date().toISOString(),
      },
      {
        id: 'mock-25-standard',
        title: 'BPSC Prelims Mini Mock Test (25 Qs)',
        titleHindi: 'बीपीएससी मिनी मॉक टेस्ट (25 प्रश्न)',
        description: 'Medium practice mock covering Bihar Special, Modern History, and General Science.',
        subjectIds: ['bihar-gk', 'history', 'geography', 'polity', 'general-science'],
        questionCount: 25,
        timeLimitMinutes: 30,
        negativeMarking: 0.25,
        totalMarks: 25,
        isFullLength: false,
        createdBy: 'admin@bpsc.exam',
        createdAt: new Date().toISOString(),
      },
      {
        id: 'mock-50-half',
        title: 'BPSC Prelims Sectional Mock Test (50 Qs)',
        titleHindi: 'बीपीएससी अनुभागीय मॉक टेस्ट (50 प्रश्न)',
        description: 'Comprehensive sectional test with standard BPSC timing and negative marking.',
        subjectIds: ['bihar-gk', 'history', 'polity', 'economy', 'general-science', 'geography'],
        questionCount: 50,
        timeLimitMinutes: 60,
        negativeMarking: 0.25,
        totalMarks: 50,
        isFullLength: false,
        createdBy: 'admin@bpsc.exam',
        createdAt: new Date().toISOString(),
      },
      {
        id: 'mock-150-full',
        title: '71st BPSC Prelims Full Length Mock Test (150 Qs)',
        titleHindi: '71वीं बीपीएससी प्रारंभिक पूर्ण मॉक टेस्ट (150 प्रश्न)',
        description: 'Official pattern 150 questions, 2 hours, negative marking 0.33, covering entire BPSC syllabus.',
        subjectIds: [
          'bihar-gk',
          'history',
          'geography',
          'polity',
          'economy',
          'general-science',
          'current-affairs',
          'environment',
          'maths-reasoning',
        ],
        questionCount: 150,
        timeLimitMinutes: 120,
        negativeMarking: 0.33,
        totalMarks: 150,
        isFullLength: true,
        createdBy: 'admin@bpsc.exam',
        createdAt: new Date().toISOString(),
      },
    ];
    writeJsonFile(mockTestsFilePath, defaults);
  }
};

seedInitialMockTests();

// Seed Initial BPSC Previous Year TRE Papers if not existing
const seedInitialTREPapers = () => {
  const existing = readJsonFile<any[]>(trePapersFilePath, []);
  if (!existing || existing.length === 0) {
    writeJsonFile(trePapersFilePath, INITIAL_TRE_PAPERS);
  }
};

seedInitialTREPapers();

// Helper to normalize Hindi text for server-side deduplication
const normalizeHindiForServer = (text: string): string => {
  return String(text || '')
    .trim()
    .replace(/[\u200B-\u200D\uFEFF]/g, '')
    .replace(/[।.,?!;:'"“”‘’]/g, '')
    .replace(/\s+/g, ' ')
    .toLowerCase();
};

const normalizeSubjectIdServer = (rawSubject: any): string => {
  if (!rawSubject || typeof rawSubject !== 'string') return 'bihar-gk';
  const clean = rawSubject.trim().toLowerCase();

  if (clean === 'bihar-gk' || clean.includes('bihar') || clean.includes('बिहार')) return 'bihar-gk';
  if (clean === 'national-movement' || clean.includes('movement') || clean.includes('आंदोलन')) return 'national-movement';
  if (clean === 'indian-history' || clean === 'history' || clean.includes('history') || clean.includes('इतिहास')) return 'indian-history';
  if (clean === 'geography' || clean.includes('geography') || clean.includes('भूगोल')) return 'geography';
  if (clean === 'polity' || clean.includes('polity') || clean.includes('constitution') || clean.includes('संविधान') || clean.includes('राजव्यवस्था')) return 'polity';
  if (clean === 'economy' || clean.includes('economy') || clean.includes('अर्थव्यवस्था') || clean.includes('बजट')) return 'economy';
  if (clean === 'general-science' || clean === 'science' || clean.includes('science') || clean.includes('विज्ञान') || clean.includes('भौतिकी') || clean.includes('रसायन') || clean.includes('जीव')) return 'general-science';
  if (clean === 'environment' || clean.includes('environment') || clean.includes('पर्यावरण')) return 'environment';
  if (clean === 'current-affairs' || clean.includes('current') || clean.includes('समसामयिकी') || clean.includes('करेंट')) return 'current-affairs';
  if (clean === 'general-hindi' || clean === 'hindi' || clean.includes('hindi') || clean.includes('हिन्दी')) return 'general-hindi';
  if (clean === 'maths-reasoning' || clean === 'maths' || clean.includes('math') || clean.includes('reasoning') || clean.includes('गणित') || clean.includes('तर्कशक्ति')) return 'maths-reasoning';

  return 'bihar-gk';
};

const validateQuestionServer = (q: any): { isValid: boolean; error?: string; question?: any } => {
  if (!q || typeof q !== 'object') {
    return { isValid: false, error: 'Question must be a valid object' };
  }
  const questionHindi = typeof q.questionHindi === 'string' ? q.questionHindi.trim() : '';
  if (!questionHindi) {
    return { isValid: false, error: 'हिन्दी में प्रश्न (questionHindi) अनिवार्य है' };
  }

  let optionsHindi: string[] = [];
  if (Array.isArray(q.optionsHindi)) {
    optionsHindi = q.optionsHindi.map((o: any) => String(o ?? '').trim());
  } else if (
    q.optionA !== undefined ||
    q.optionB !== undefined ||
    q.optionC !== undefined ||
    q.optionD !== undefined ||
    q.optionE !== undefined
  ) {
    optionsHindi = [
      String(q.optionA ?? '').trim(),
      String(q.optionB ?? '').trim(),
      String(q.optionC ?? '').trim(),
      String(q.optionD ?? '').trim(),
      String(q.optionE ?? '').trim(),
    ];
  }

  if (optionsHindi.length !== 5 || optionsHindi.some((opt) => !opt)) {
    return { isValid: false, error: 'प्रश्न में ठीक 5 विकल्प (A-E) होने चाहिए' };
  }

  const rawAnswer = String(q.correctAnswer ?? '').trim().toUpperCase();
  if (!['A', 'B', 'C', 'D', 'E'].includes(rawAnswer)) {
    return { isValid: false, error: `सही उत्तर केवल 'A', 'B', 'C', 'D' या 'E' होना चाहिए (प्राप्त मान: "${q.correctAnswer ?? ''}")` };
  }

  const explanationHindi = typeof q.explanationHindi === 'string' ? q.explanationHindi.trim() : '';
  if (!explanationHindi) {
    return { isValid: false, error: 'हिन्दी में विस्तृत व्याख्या (explanationHindi) अनिवार्य है' };
  }

  const isDemo = Boolean(q.isDemo) || 
    questionHindi.includes('डेमो') || 
    questionHindi.includes('परीक्षण') || 
    (q.topic && (String(q.topic).includes('डेमो') || String(q.topic).includes('परीक्षण')));

  return {
    isValid: true,
    question: {
      id: q.id && String(q.id).trim().length > 0 ? String(q.id) : `q-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
      subjectId: normalizeSubjectIdServer(q.subjectId),
      topic: q.topic ? String(q.topic).trim() : 'General Studies',
      questionHindi,
      questionEnglish: q.questionEnglish ? String(q.questionEnglish).trim() : questionHindi,
      optionsHindi,
      optionsEnglish: Array.isArray(q.optionsEnglish) && q.optionsEnglish.length === 5 
        ? q.optionsEnglish 
        : [optionsHindi[0], optionsHindi[1], optionsHindi[2], optionsHindi[3], 'None of the above / More than one of the above'],
      correctAnswer: rawAnswer,
      explanationHindi,
      explanationEnglish: q.explanationEnglish ? String(q.explanationEnglish).trim() : explanationHindi,
      difficulty: ['Easy', 'Medium', 'Hard'].includes(q.difficulty) ? q.difficulty : 'Medium',
      source: q.source ? String(q.source).trim() : (isDemo ? 'BPSC Demo/Test Set' : 'Question Bank Import'),
      year: q.year ? Number(q.year) || undefined : undefined,
      isPYQ: Boolean(q.isPYQ),
      isAIGenerated: Boolean(q.isAIGenerated),
      verified: q.verified !== false,
      isImported: q.isImported !== undefined ? Boolean(q.isImported) : true,
      importedAt: q.importedAt || new Date().toISOString(),
      isDemo,
      createdAt: q.createdAt || new Date().toISOString(),
    }
  };
};

const seedInitialQuestions = () => {
  const existing = readJsonFile<any[]>(questionsFilePath, []);
  const existingIdSet = new Set(existing.map((q) => q.id));
  const existingTextSet = new Set(existing.map((q) => normalizeHindiForServer(q.questionHindi)).filter(Boolean));

  for (const q of INITIAL_QUESTIONS) {
    const norm = normalizeHindiForServer(q.questionHindi);
    if (!existingIdSet.has(q.id) && !existingTextSet.has(norm)) {
      existing.push(q);
      existingIdSet.add(q.id);
      if (norm) existingTextSet.add(norm);
    }
  }

  // Deduplicate any duplicates that might already exist
  const uniqueQuestions: any[] = [];
  const seenIds = new Set<string>();
  const seenTexts = new Set<string>();
  for (const q of existing) {
    const norm = normalizeHindiForServer(q.questionHindi);
    if (!seenIds.has(q.id) && (!norm || !seenTexts.has(norm))) {
      uniqueQuestions.push(q);
      seenIds.add(q.id);
      if (norm) seenTexts.add(norm);
    }
  }

  writeJsonFile(questionsFilePath, uniqueQuestions);
  console.log(`Seeded question bank with ${uniqueQuestions.length} unique questions.`);
};

seedInitialQuestions();

// --- Authentication & Session Middleware ---

interface AuthRequest extends Request {
  user?: {
    id: string;
    email: string;
    name: string;
    role: 'student' | 'admin';
  };
}

const getSessionUser = (req: Request) => {
  const authHeader = req.headers.authorization;
  const token = authHeader?.startsWith('Bearer ')
    ? authHeader.substring(7).trim()
    : (req.headers['x-session-token'] as string);

  if (!token) return null;

  const sessions = readJsonFile<Record<string, any>>(sessionsFilePath, {});
  const session = sessions[token];

  if (!session) return null;

  // Check expiration (7 days session)
  if (session.expiresAt && new Date(session.expiresAt).getTime() < Date.now()) {
    delete sessions[token];
    writeJsonFile(sessionsFilePath, sessions);
    return null;
  }

  return session;
};

const authenticate = (req: AuthRequest, res: Response, next: NextFunction) => {
  const session = getSessionUser(req);
  if (!session) {
    return res.status(401).json({ error: 'Authentication required. Please log in.' });
  }
  req.user = session;
  next();
};

const requireAdmin = (req: AuthRequest, res: Response, next: NextFunction) => {
  const session = getSessionUser(req);
  if (!session) {
    return res.status(401).json({ error: 'Authentication required. Please log in as Admin.' });
  }
  if (session.role !== 'admin') {
    return res.status(403).json({
      error: 'Access denied: Admin role required for this action. Students cannot perform administrative modifications.',
    });
  }
  req.user = session;
  next();
};

// --- AUTH API ROUTES ---

// POST /api/auth/register (Student Registration ONLY)
app.post('/api/auth/register', (req: Request, res: Response) => {
  const { name, email, password, targetExam } = req.body;

  if (!name || !email || !password) {
    return res.status(400).json({ error: 'Name, email and password are required.' });
  }

  const cleanEmail = String(email).trim().toLowerCase();
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(cleanEmail)) {
    return res.status(400).json({ error: 'Please enter a valid email address.' });
  }

  if (String(password).length < 6) {
    return res.status(400).json({ error: 'Password must be at least 6 characters long.' });
  }

  const users = readJsonFile<any[]>(usersFilePath, []);
  if (users.some((u) => u.email.toLowerCase() === cleanEmail)) {
    return res.status(409).json({ error: 'An account with this email already exists. Please log in.' });
  }

  // SECURITY ENFORCEMENT: Never accept 'role' from client payload!
  // All public registrations are strictly assigned 'student' role.
  const salt = bcrypt.genSaltSync(10);
  const passwordHash = bcrypt.hashSync(String(password), salt);

  const newUser = {
    id: `user-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
    name: String(name).trim(),
    email: cleanEmail,
    passwordHash,
    role: 'student', // SERVER ENFORCED
    targetExam: targetExam || '71st BPSC Combined Competitive Prelims',
    createdAt: new Date().toISOString(),
  };

  users.push(newUser);
  writeJsonFile(usersFilePath, users);

  // Issue Session Token
  const token = crypto.randomBytes(32).toString('hex');
  const sessions = readJsonFile<Record<string, any>>(sessionsFilePath, {});
  const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString();

  sessions[token] = {
    id: newUser.id,
    name: newUser.name,
    email: newUser.email,
    role: newUser.role,
    expiresAt,
  };
  writeJsonFile(sessionsFilePath, sessions);

  res.status(201).json({
    token,
    user: {
      id: newUser.id,
      name: newUser.name,
      email: newUser.email,
      role: newUser.role,
      targetExam: newUser.targetExam,
    },
  });
});

// POST /api/auth/login (Email & Password Login for Student & Admin)
app.post('/api/auth/login', (req: Request, res: Response) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password are required.' });
  }

  const cleanEmail = String(email).trim().toLowerCase();
  const users = readJsonFile<any[]>(usersFilePath, []);
  const user = users.find((u) => u.email.toLowerCase() === cleanEmail);

  if (!user || !user.passwordHash) {
    return res.status(401).json({ error: 'Invalid email or password.' });
  }

  const isValidPassword = bcrypt.compareSync(String(password), user.passwordHash);
  if (!isValidPassword) {
    return res.status(401).json({ error: 'Invalid email or password.' });
  }

  // Issue Session Token
  const token = crypto.randomBytes(32).toString('hex');
  const sessions = readJsonFile<Record<string, any>>(sessionsFilePath, {});
  const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString();

  sessions[token] = {
    id: user.id,
    name: user.name,
    email: user.email,
    role: user.role, // Server-Authoritative Role
    expiresAt,
  };
  writeJsonFile(sessionsFilePath, sessions);

  res.json({
    token,
    user: {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
      targetExam: user.targetExam || '71st BPSC Combined Competitive Prelims',
    },
  });
});

// GET /api/auth/me (Get logged in user profile)
app.get('/api/auth/me', (req: Request, res: Response) => {
  const session = getSessionUser(req);
  if (!session) {
    return res.status(401).json({ error: 'Not authenticated' });
  }

  const users = readJsonFile<any[]>(usersFilePath, []);
  const user = users.find((u) => u.id === session.id);

  if (!user) {
    return res.status(404).json({ error: 'User record not found' });
  }

  res.json({
    id: user.id,
    name: user.name,
    email: user.email,
    role: user.role,
    targetExam: user.targetExam || '71st BPSC Combined Competitive Prelims',
    createdAt: user.createdAt,
  });
});

// POST /api/auth/logout
app.post('/api/auth/logout', (req: Request, res: Response) => {
  const authHeader = req.headers.authorization;
  const token = authHeader?.startsWith('Bearer ')
    ? authHeader.substring(7).trim()
    : (req.headers['x-session-token'] as string);

  if (token) {
    const sessions = readJsonFile<Record<string, any>>(sessionsFilePath, {});
    delete sessions[token];
    writeJsonFile(sessionsFilePath, sessions);
  }

  res.json({ success: true, message: 'Logged out successfully.' });
});

// POST /api/auth/forgot-password (Generates reset token & simulated safe recovery)
app.post('/api/auth/forgot-password', (req: Request, res: Response) => {
  const { email } = req.body;
  if (!email) {
    return res.status(400).json({ error: 'Email address is required.' });
  }

  const cleanEmail = String(email).trim().toLowerCase();
  const users = readJsonFile<any[]>(usersFilePath, []);
  const user = users.find((u) => u.email.toLowerCase() === cleanEmail);

  if (!user) {
    // Return friendly generic message to prevent email enumeration
    return res.json({
      success: true,
      message: 'यदि यह ईमेल पंजीकृत है, तो पासवर्ड रीसेट निर्देश भेज दिए गए हैं।',
    });
  }

  const resetToken = crypto.randomBytes(16).toString('hex');
  const resets = readJsonFile<Record<string, any>>(passwordResetsFilePath, {});
  resets[resetToken] = {
    userId: user.id,
    email: user.email,
    expiresAt: new Date(Date.now() + 60 * 60 * 1000).toISOString(), // 1 hour
  };
  writeJsonFile(passwordResetsFilePath, resets);

  res.json({
    success: true,
    message: 'पासवर्ड रीसेट लिंक/टोकन जनरेट किया गया।',
    resetToken, // Returned for easy self-serve reset in testing & demo
  });
});

// POST /api/auth/reset-password
app.post('/api/auth/reset-password', (req: Request, res: Response) => {
  const { resetToken, newPassword } = req.body;

  if (!resetToken || !newPassword) {
    return res.status(400).json({ error: 'Reset token and new password are required.' });
  }

  if (String(newPassword).length < 6) {
    return res.status(400).json({ error: 'New password must be at least 6 characters.' });
  }

  const resets = readJsonFile<Record<string, any>>(passwordResetsFilePath, {});
  const record = resets[resetToken];

  if (!record || new Date(record.expiresAt).getTime() < Date.now()) {
    return res.status(400).json({ error: 'Invalid or expired password reset token.' });
  }

  const users = readJsonFile<any[]>(usersFilePath, []);
  const user = users.find((u) => u.id === record.userId);

  if (!user) {
    return res.status(404).json({ error: 'User account not found.' });
  }

  const salt = bcrypt.genSaltSync(10);
  user.passwordHash = bcrypt.hashSync(String(newPassword), salt);
  writeJsonFile(usersFilePath, users);

  delete resets[resetToken];
  writeJsonFile(passwordResetsFilePath, resets);

  res.json({ success: true, message: 'पासवर्ड सफलतापूर्वक बदल दिया गया है। कृपया लॉगिन करें।' });
});

// --- STUDENT TEST HISTORY & STATS API ---

// GET /api/student/history
app.get('/api/student/history', authenticate, (req: AuthRequest, res: Response) => {
  const results = readJsonFile<any[]>(testResultsFilePath, []);
  const studentResults = results.filter((r) => r.userId === req.user?.id);
  res.json(studentResults);
});

// POST /api/student/history
app.post('/api/student/history', authenticate, (req: AuthRequest, res: Response) => {
  const testResult = req.body;
  if (!testResult || typeof testResult !== 'object') {
    return res.status(400).json({ error: 'Invalid test result payload.' });
  }

  const resultId = testResult.id || `result-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`;
  const results = readJsonFile<any[]>(testResultsFilePath, []);
  const enrichedResult = {
    ...testResult,
    id: resultId,
    userId: req.user?.id,
    studentName: req.user?.name,
    studentEmail: req.user?.email,
    savedAt: new Date().toISOString(),
  };

  results.unshift(enrichedResult);
  writeJsonFile(testResultsFilePath, results);

  res.status(201).json(enrichedResult);
});

// --- ADMIN DASHBOARD & SYSTEM STATS ---

// GET /api/admin/stats (Admin Only)
app.get('/api/admin/stats', requireAdmin, (_req: AuthRequest, res: Response) => {
  const users = readJsonFile<any[]>(usersFilePath, []);
  const questions = readJsonFile<any[]>(questionsFilePath, []);
  const mockTests = readJsonFile<any[]>(mockTestsFilePath, []);
  const testResults = readJsonFile<any[]>(testResultsFilePath, []);
  const trePapers = readJsonFile<any[]>(trePapersFilePath, INITIAL_TRE_PAPERS);

  const students = users.filter((u) => u.role === 'student');
  const totalScoreSum = testResults.reduce((acc, t) => acc + (t.score || 0), 0);
  const averageScore = testResults.length > 0 ? +(totalScoreSum / testResults.length).toFixed(1) : 0;

  res.json({
    totalStudents: students.length,
    totalQuestions: questions.length,
    totalSubjects: 11,
    totalMockTests: mockTests.length,
    totalTREPapers: trePapers.length,
    totalTestsTaken: testResults.length,
    averageScore,
    recentResults: testResults.slice(0, 10).map((r) => ({
      id: r.id,
      studentName: r.studentName || 'Student',
      studentEmail: r.studentEmail || 'N/A',
      testTitle: r.testTitle || 'BPSC Test',
      score: r.score,
      maxScore: r.maxScore,
      percentage: r.percentage,
      completedAt: r.completedAt,
    })),
  });
});

// GET /api/admin/students (Admin Only: List all registered students)
app.get('/api/admin/students', requireAdmin, (_req: AuthRequest, res: Response) => {
  const users = readJsonFile<any[]>(usersFilePath, []);
  const testResults = readJsonFile<any[]>(testResultsFilePath, []);

  const students = users
    .filter((u) => u.role === 'student')
    .map((u) => {
      const studentTests = testResults.filter((r) => r.userId === u.id);
      const totalAttempted = studentTests.reduce((acc, t) => acc + (t.attempted || 0), 0);
      const totalCorrect = studentTests.reduce((acc, t) => acc + (t.correct || 0), 0);
      const accuracy = totalAttempted > 0 ? Math.round((totalCorrect / totalAttempted) * 100) : 0;
      const lastTest = studentTests[0];

      return {
        id: u.id,
        name: u.name,
        email: u.email,
        targetExam: u.targetExam,
        createdAt: u.createdAt,
        totalTestsTaken: studentTests.length,
        accuracy,
        lastTestDate: lastTest ? lastTest.completedAt : 'No tests yet',
      };
    });

  res.json(students);
});

// --- MOCK TEST BUILDER ROUTES ---

// GET /api/mock-tests (Public / Authenticated)
app.get('/api/mock-tests', (_req: Request, res: Response) => {
  const tests = readJsonFile<any[]>(mockTestsFilePath, []);
  res.json(tests);
});

// POST /api/mock-tests (Admin Only: Create new practice set / mock test)
app.post('/api/mock-tests', requireAdmin, (req: AuthRequest, res: Response) => {
  const {
    title,
    titleHindi,
    description,
    subjectIds,
    questionCount,
    timeLimitMinutes,
    negativeMarking,
    totalMarks,
    isFullLength,
  } = req.body;

  if (!title || !questionCount) {
    return res.status(400).json({ error: 'Title and questionCount are required.' });
  }

  const newTest = {
    id: `mock-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
    title: String(title).trim(),
    titleHindi: titleHindi ? String(titleHindi).trim() : String(title).trim(),
    description: description ? String(description).trim() : 'BPSC Practice Mock Test',
    subjectIds: Array.isArray(subjectIds) && subjectIds.length > 0 ? subjectIds : ['bihar-gk'],
    questionCount: Number(questionCount) || 10,
    timeLimitMinutes: Number(timeLimitMinutes) || 15,
    negativeMarking: typeof negativeMarking === 'number' ? negativeMarking : 0.25,
    totalMarks: Number(totalMarks) || Number(questionCount) || 10,
    isFullLength: Boolean(isFullLength),
    createdBy: req.user?.email || 'admin@bpsc.exam',
    createdAt: new Date().toISOString(),
  };

  const tests = readJsonFile<any[]>(mockTestsFilePath, []);
  tests.unshift(newTest);
  writeJsonFile(mockTestsFilePath, tests);

  res.status(201).json(newTest);
});

// DELETE /api/mock-tests/:id (Admin Only)
app.delete('/api/mock-tests/:id', requireAdmin, (req: AuthRequest, res: Response) => {
  const { id } = req.params;
  const tests = readJsonFile<any[]>(mockTestsFilePath, []);
  const updated = tests.filter((t) => t.id !== id);
  writeJsonFile(mockTestsFilePath, updated);
  res.json({ success: true, message: 'Mock test deleted successfully.' });
});

// --- PREVIOUS YEAR TRE PAPERS ROUTES ---

// GET /api/tre-papers (Public / Student / Admin)
app.get('/api/tre-papers', (req: Request, res: Response) => {
  const papers = readJsonFile<any[]>(trePapersFilePath, INITIAL_TRE_PAPERS);
  const { phase, classLevel, subject } = req.query;

  let filtered = [...papers];
  if (phase && phase !== 'all') {
    filtered = filtered.filter((p) => p.phase === phase);
  }
  if (classLevel && classLevel !== 'all') {
    filtered = filtered.filter((p) => p.classLevel === classLevel);
  }
  if (subject && subject !== 'all') {
    filtered = filtered.filter((p) => p.subject === subject || p.subjectHindi === subject);
  }

  res.json(filtered);
});

// GET /api/tre-papers/:id (Public)
app.get('/api/tre-papers/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  const papers = readJsonFile<any[]>(trePapersFilePath, INITIAL_TRE_PAPERS);
  const paper = papers.find((p) => p.id === id);
  if (!paper) {
    return res.status(404).json({ error: 'TRE Paper not found.' });
  }
  res.json(paper);
});

// POST /api/tre-papers (Admin Only: Upload/Create new TRE Paper)
app.post('/api/tre-papers', requireAdmin, (req: AuthRequest, res: Response) => {
  const {
    title,
    titleHindi,
    phase,
    year,
    classLevel,
    subject,
    subjectHindi,
    shift,
    examDate,
    totalQuestions,
    durationMinutes,
    negativeMarking,
    pdfUrl,
    answerKeyPdfUrl,
    isVerified,
    isPublished,
    isComingSoon,
    questions,
  } = req.body;

  if (!title || !phase || !classLevel) {
    return res.status(400).json({ error: 'Title, Phase, and Class Level are required.' });
  }

  const newPaper = {
    id: `tre-paper-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
    title: String(title).trim(),
    titleHindi: titleHindi ? String(titleHindi).trim() : String(title).trim(),
    phase: phase || 'TRE 1.0',
    year: Number(year) || 2024,
    classLevel: classLevel || '1-5',
    subject: subject || 'General Studies',
    subjectHindi: subjectHindi || 'सामान्य अध्ययन',
    shift: shift || 'Shift 1',
    examDate: examDate || new Date().toISOString().split('T')[0],
    totalQuestions: Array.isArray(questions) ? questions.length : Number(totalQuestions) || 10,
    durationMinutes: Number(durationMinutes) || 15,
    negativeMarking: typeof negativeMarking === 'number' ? negativeMarking : 0,
    pdfUrl: pdfUrl || 'https://www.bpsc.bih.nic.in',
    answerKeyPdfUrl: answerKeyPdfUrl || 'https://www.bpsc.bih.nic.in',
    isVerified: Boolean(isVerified ?? true),
    isPublished: Boolean(isPublished ?? true),
    isComingSoon: Boolean(isComingSoon ?? false),
    questions: Array.isArray(questions) ? questions : [],
    createdAt: new Date().toISOString(),
  };

  const papers = readJsonFile<any[]>(trePapersFilePath, INITIAL_TRE_PAPERS);
  papers.unshift(newPaper);
  writeJsonFile(trePapersFilePath, papers);

  res.status(201).json(newPaper);
});

// PUT /api/tre-papers/:id (Admin Only: Edit paper, publish/unpublish, add questions)
app.put('/api/tre-papers/:id', requireAdmin, (req: AuthRequest, res: Response) => {
  const { id } = req.params;
  const updates = req.body;

  const papers = readJsonFile<any[]>(trePapersFilePath, INITIAL_TRE_PAPERS);
  const index = papers.findIndex((p) => p.id === id);

  if (index === -1) {
    return res.status(404).json({ error: 'TRE Paper not found.' });
  }

  papers[index] = {
    ...papers[index],
    ...updates,
    updatedAt: new Date().toISOString(),
  };

  writeJsonFile(trePapersFilePath, papers);
  res.json(papers[index]);
});

// DELETE /api/tre-papers/:id (Admin Only)
app.delete('/api/tre-papers/:id', requireAdmin, (req: AuthRequest, res: Response) => {
  const { id } = req.params;
  const papers = readJsonFile<any[]>(trePapersFilePath, INITIAL_TRE_PAPERS);
  const updated = papers.filter((p) => p.id !== id);
  writeJsonFile(trePapersFilePath, updated);
  res.json({ success: true, message: 'TRE Paper deleted successfully.' });
});

// --- QUESTION BANK ROUTES ---

// GET /api/questions (Public)
app.get('/api/questions', (_req: Request, res: Response) => {
  const stored = readJsonFile<any[]>(questionsFilePath, []);
  res.json(stored);
});

// POST /api/questions (Create Single Question)
app.post('/api/questions', (req: Request, res: Response) => {
  const validation = validateQuestionServer(req.body);
  if (!validation.isValid || !validation.question) {
    return res.status(400).json({ error: validation.error || 'Invalid question data.' });
  }

  const existing = readJsonFile<any[]>(questionsFilePath, []);
  const norm = normalizeHindiForServer(validation.question.questionHindi);
  const isDuplicate = existing.some(
    (q) => q.id === validation.question.id || (norm && normalizeHindiForServer(q.questionHindi) === norm)
  );

  if (isDuplicate) {
    return res.status(409).json({ error: 'Duplicate question already exists in question bank.' });
  }

  const updated = [validation.question, ...existing];
  writeJsonFile(questionsFilePath, updated);
  res.status(201).json(validation.question);
});

// PUT /api/questions/:id (Admin Only)
app.put('/api/questions/:id', requireAdmin, (req: AuthRequest, res: Response) => {
  const { id } = req.params;
  const updates = req.body;
  const existing = readJsonFile<any[]>(questionsFilePath, []);
  const updated = existing.map((q: any) => (q.id === id ? { ...q, ...updates } : q));
  writeJsonFile(questionsFilePath, updated);
  res.json({ success: true });
});

// DELETE /api/questions/:id (Admin Only)
app.delete('/api/questions/:id', requireAdmin, (req: AuthRequest, res: Response) => {
  const { id } = req.params;
  const existing = readJsonFile<any[]>(questionsFilePath, []);
  const updated = existing.filter((q: any) => q.id !== id);
  writeJsonFile(questionsFilePath, updated);
  res.json({ success: true });
});

// POST /api/questions/bulk (Bulk Import Questions: Persists to questions.json)
app.post('/api/questions/bulk', (req: Request, res: Response) => {

  const rawQuestions = Array.isArray(req.body) ? req.body : req.body?.questions;
  if (!Array.isArray(rawQuestions)) {
    return res.status(400).json({ error: 'Expected an array of questions: [...]' });
  }

  const existing = readJsonFile<any[]>(questionsFilePath, []);
  const existingIdSet = new Set(existing.map((q) => q.id));
  const existingTextSet = new Set(existing.map((q) => normalizeHindiForServer(q.questionHindi)).filter(Boolean));

  const validToAdd: any[] = [];
  const errors: any[] = [];
  let skippedDuplicates = 0;

  for (let idx = 0; idx < rawQuestions.length; idx++) {
    const item = rawQuestions[idx];
    const validation = validateQuestionServer(item);
    if (!validation.isValid || !validation.question) {
      errors.push({ rowNumber: idx + 1, error: validation.error });
      continue;
    }

    const q = validation.question;
    const norm = normalizeHindiForServer(q.questionHindi);

    if (existingIdSet.has(q.id) || (norm && existingTextSet.has(norm))) {
      skippedDuplicates++;
      continue;
    }

    existingIdSet.add(q.id);
    if (norm) existingTextSet.add(norm);
    validToAdd.push(q);
  }

  const updated = [...validToAdd, ...existing];
  writeJsonFile(questionsFilePath, updated);

  res.json({
    success: true,
    imported: validToAdd.length,
    skippedDuplicates,
    totalExisting: updated.length,
    errors,
  });
});

// AI Helper Route
app.post('/api/ai/generate-question', requireAdmin, async (req: AuthRequest, res: Response) => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return res.status(503).json({
      error: 'Gemini API Key is not configured on server. Please use manual or CSV import.',
    });
  }

  const { subjectName, topic } = req.body;

  try {
    const ai = new GoogleGenAI();
    const prompt = `You are a BPSC (Bihar Public Service Commission) subject expert.
Create exactly ONE authentic, accurate, 5-option multiple-choice question in standard BPSC format on the topic: "${topic || 'Bihar GK'}" for subject "${subjectName || 'General Studies'}".

CRITICAL RULES:
1. Exactly five options: A, B, C, D, and E.
2. In BPSC tradition, Option E is usually: "उपर्युक्त में से कोई नहीं / उपर्युक्त में से एक से अधिक" (None of the above / More than one of the above).
3. Exactly ONE correct answer (A, B, C, D, or E).
4. Strictly verified facts only. Never invent fake historical events, false dates, or unverified claims.
5. Provide high-quality Devanagari Hindi text and clear English text.
6. Return JSON only matching this format:
{
  "questionHindi": "...",
  "questionEnglish": "...",
  "optionsHindi": ["A", "B", "C", "D", "उपर्युक्त में से कोई नहीं / उपर्युक्त में से एक से अधिक"],
  "optionsEnglish": ["A", "B", "C", "D", "None of the above / More than one of the above"],
  "correctAnswer": "A",
  "explanationHindi": "...",
  "explanationEnglish": "...",
  "topic": "...",
  "difficulty": "Medium"
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const text = response.text?.trim() || '{}';
    const parsed = JSON.parse(text);

    const labeledQuestion = {
      ...parsed,
      id: 'ai-gen-' + Date.now(),
      source: 'AI Suggested Practice (Review Needed)',
      isPYQ: false,
      isAIGenerated: true,
      verified: false,
    };

    res.json(labeledQuestion);
  } catch (error: any) {
    console.error('Gemini question generation error:', error);
    res.status(500).json({ error: 'Failed to generate question with AI' });
  }
});

// Setup Vite middleware in dev or serve static in prod
const isProduction = process.env.NODE_ENV === 'production';

async function startServer() {
  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`BPSC Exam Practice full-stack server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
